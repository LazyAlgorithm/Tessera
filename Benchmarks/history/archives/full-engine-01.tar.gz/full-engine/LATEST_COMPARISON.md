# Latest benchmark comparison

[final-comparison-20261028-202825/REPORT.md](/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/final-comparison-20261028-202825/REPORT.md)

Current Tessera snapshot rerun against matching saved Unity baselines; Unity was not executed. Includes default walking NavMesh, explicit grid controls, batched paths, physics, rendering, skinning, animation, audio/image, crowds and tiled updates. Older COMPARISON.md and confirmation reports are historical.
