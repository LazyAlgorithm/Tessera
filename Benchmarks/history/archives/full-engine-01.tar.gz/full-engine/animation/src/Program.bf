using System;
using System.Collections;
using Tessera;
using Bgfx;
namespace Features;
class Program
{
 public static int Main(String[] args)
 {
  if(args.Count<4) return 1;
  let app=scope FeatureBench(); app.Kind.Set(args[0]); app.Count=SceneSerializer.ParseInt(args[1]); app.Warmup=SceneSerializer.ParseInt(args[2]); app.Samples=SceneSerializer.ParseInt(args[3]);
  app.Headless=!app.Kind.StartsWith("render-"); app.Width=1280;app.Height=720;Gfx.ResetFlags=0;
  if(args.Count==5) return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera","--frames",scope $"{app.Warmup+app.Samples+1}","--screenshot",args[4]));
  return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera"));
 }
}
class FeatureBench : Application
{
 public String Kind=new .() ~ delete _;
 public int Count,Warmup,Samples;
 Scene scene=new .() ~ delete _;
 RenderView view ~ delete _;
 Camera camera;
 List<SkinnedMeshRenderer> skins=new .() ~ delete _;
 NavigationSurface navigation;
 List<Animator> animators=new .() ~ delete _;
 List<LimbIK> limbs=new .() ~ delete _;
 List<VoxelObject> voxels=new .() ~ delete _;
 List<BehaviorTreeRunner> brains=new .() ~ delete _;
 List<Vector3> path=new .() ~ delete _;
 UIDocumentData document=new .() ~ delete _;
 String markup=new .() ~ delete _;
 float[] audioBuffer=new .[960] ~ delete _;
 int frame;
 uint64 previous;
 double checksum;
 void Row(int i,StringView metric,double ms) => Console.WriteLine(scope $"BENCH,tessera,{Kind},{Count},{i},{metric},{ms}");
 protected override bool OnInit()
 {
  Assets.ProjectPath.Set("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets");
  Audio.NoDevice=true;
  let start=SDL.SDL_GetTicksNS();
  if(!Headless)
  {
   camera=scene.CreateGameObject("Camera").AddComponent<Camera>();camera.Transform.Position=.(0,8,-30);camera.farClip=1000;
   let sun=scene.CreateGameObject("Sun");sun.Transform.LocalEulerAngles=.(-45,45,0);sun.AddComponent<Light>();
   view=new RenderView(10);view.ToBackbuffer=true;view.DrawShadows=Kind.Contains("shadows");
   if(Kind.Contains("skinning"))
   {
    for(int i=0;i<Count;i++)
    {
     let go=scene.CreateGameObject("Character");go.Transform.Position=.((i%20-9.5f)*1.1f,0,(i/20)*1.1f);
     let skin=go.AddComponent<SkinnedMeshRenderer>();skin.model.Set("crowd.glb");skin.clip.Set("Wave");skin.gpuSkinning=!Kind.Contains("cpu");skin.OnValidate();skins.Add(skin);
    }
   }
  }
  if(Kind=="animation-ik")
  {
   for(int i=0;i<Count;i++){let root=scene.CreateGameObject("Arm");let a=scene.CreateGameObject("Upper",root.Transform).Transform;let b=scene.CreateGameObject("Lower",a).Transform;b.LocalPosition=.(0,-0.3f,0);let c=scene.CreateGameObject("Hand",b).Transform;c.LocalPosition=.(0,-0.3f,0);let target=scene.CreateGameObject("Target").Transform;target.Position=.(0.3f,-0.3f,0.2f);let ik=root.AddComponent<LimbIK>();ik.tip=c;ik.target=target;ik.rotationWeight=0;limbs.Add(ik);}
  }
  if(Kind=="voxel-rebuild" || Kind=="voxel-carve")
  {
   for(int i=0;i<Count;i++){let voxel=scene.CreateGameObject("Voxel").AddComponent<VoxelObject>();voxel.resolution=24;voxel.breakOffPieces=false;voxel.anchored=true;voxel.Fill();voxels.Add(voxel);}
  }
  if(Kind=="ai-behavior-tree")
  {
   let data=scope BehaviorTreeData();let root=data.AddNode(BehaviorLibrary.Find("root"),.Zero);let seq=data.AddNode(BehaviorLibrary.Find("sequence"),.Zero);data.Connect(root.id,seq.id);
   for(int n=0;n<8;n++) {let node=data.AddNode(BehaviorLibrary.Find("bb.set"),.Zero);node.values[0].Set(scope $"flag{n}");node.values[1].Set("true");data.Connect(seq.id,node.id);}
   data.Save("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/benchmark.tbt");
   for(int i=0;i<Count;i++){let brain=scene.CreateGameObject("Brain").AddComponent<BehaviorTreeRunner>();brain.tree.Set("benchmark.tbt");brains.Add(brain);}
  }
  if(Kind.StartsWith("ai-nav"))
  {
   let floor=scene.CreateGameObject("Floor");floor.Transform.Position=.(16,-0.5f,16);floor.AddComponent<BoxCollider>().size=.(32,1,32);
   for(int i=0;i<3;i++){let wall=scene.CreateGameObject("Wall");let z=(i%2)==0 ? 10.0f : 22.0f;wall.Transform.Position=.(8+i*8,1.5f,z);wall.AddComponent<BoxCollider>().size=.(1,3,20);}
   navigation=scene.CreateGameObject("Navigation").AddComponent<NavigationSurface>();navigation.size=.(32,5,32);navigation.cellSize=0.5f;
   if(!navigation.Bake()) return false;
  }
  if(Kind=="ui-layout" || Kind=="ui-parse")
  {
   markup.AppendF("<panel id=\"page\"><panel repeat=\"{}\" class=\"item\"></panel></panel>",Count);
   document.Parse(markup);document.styleText.Set("#page { width: 1280; height: 720; flex-direction: row; flex-wrap: wrap } .item { width: 20; height: 20 }");document.ParseStyles();document.Layout(1280,720);
  }
  if(Kind.StartsWith("audio-"))
  {
   scene.CreateGameObject("Listener").AddComponent<AudioListener>();
   for(int i=0;i<Count;i++) {let source=scene.CreateGameObject("Voice").AddComponent<AudioSource>();source.audioClip.Set("tone.wav");source.loop=true;source.playOnStart=false;source.volume=0.01f;source.occlusion=false;source.airAbsorption=false;source.doppler=0;source.Transform.Position=.((i%10)-5,0,5);source.Play();}
   Audio.Hrtf=Kind.Contains("hrtf");
  }
  if(Kind=="animator-clips" || Kind=="animator-layered") {
   let clip=AnimationClip.Create("animator-bench.tanim","Bench");clip.duration=1;
   for(int b=0;b<32;b++){let track=clip.AddTrack(scope $"Joint{b}");for(int k=0;k<16;k++)track.SetKey(k/15.0f,.Zero,.(0,Math.Sin(k*Math.PI_f*2/15)*45,0),.One);}
   clip.Save("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/animator-bench.tanim");
   let control=scope AnimatorController();control.AddState("Base","animator-bench.tanim");
   if(Kind=="animator-layered"){let upper=control.AddLayer("Upper");upper.weight=0.5f;control.AddState("Upper State","animator-bench.tanim").layer=1;let extra=control.AddLayer("Additive");extra.weight=0.25f;extra.blending=.Additive;control.AddState("Add State","animator-bench.tanim").layer=2;}
   control.Save("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/animator-bench.tcontroller");
   for(int i=0;i<Count;i++){let go=scene.CreateGameObject("Actor");var parent=go.Transform;for(int b=0;b<32;b++){parent=scene.CreateGameObject(scope $"Joint{b}",parent).Transform;parent.LocalPosition=.(0,0.1f,0);}let animator=go.AddComponent<Animator>();animator.controller.Set("animator-bench.tcontroller");animators.Add(animator);}
  }
  scene.StartPlay();Time.DeltaTime=1/60.0f;Time.UnscaledDeltaTime=1/60.0f;scene.Update();
  Console.WriteLine(scope $"CHECK,setup_ms,{(double)(SDL.SDL_GetTicksNS()-start)/1.0e6}");
  Console.WriteLine(scope $"CHECK,objects,{Count}");
  if(Headless)
  {
   for(int i=0;i<Warmup+Samples;i++)
   {
    let begin=SDL.SDL_GetTicksNS();
    if(!Work(i)) return false;
    let ms=(double)(SDL.SDL_GetTicksNS()-begin)/1.0e6;
    if(i>=Warmup) Row(i-Warmup,"feature_batch",ms);
   }
   if(Kind=="ai-nav-path") {double length=0;for(int p=1;p<path.Count;p++)length+=(path[p]-path[p-1]).Length;Console.WriteLine(scope $"CHECK,path_waypoints,{path.Count}");Console.WriteLine(scope $"CHECK,path_length,{length}");}
   Console.WriteLine(scope $"CHECK,checksum,{checksum}");Running=false;
  }
  previous=SDL.SDL_GetTicksNS();return true;
 }
 bool Work(int sample)
 {
  if(Kind.StartsWith("model-"))
  {
   for(int i=0;i<Count;i++)
   {
    var settings=MeshShapes.Settings();settings.size=.(2,3,2);
    let shape=MeshShapes.Create(Kind=="model-primitives" ? (MeshShapes.Kind)(i%MeshShapes.Names.Count) : .Box,settings);defer delete shape;
    int32[6] faces=.(0,1,2,3,4,5);
    switch(Kind)
    {
    case "model-decimate": MeshOps.Subdivide(shape,faces,true);MeshOps.Decimate(shape,0.5f);
    case "model-weld": shape.Weld(0.001f);
    case "model-extrude": MeshOps.ExtrudeFaces(shape,faces,0.2f);
    case "model-inset": MeshOps.InsetFaces(shape,faces,0.1f);
    case "model-subdivide": MeshOps.Subdivide(shape,faces,true);
    case "model-bevel": let edges=scope List<uint64>();shape.Edges(edges);MeshOps.Bevel(shape,edges,0.1f,null,2);
    case "model-uv": shape.UpdateAutoUVs(.One);
    case "model-triangulate": MeshOps.Triangulate(shape,faces);
    default:
    }
    let mesh=scope Mesh();shape.Build(mesh,.One);checksum+=mesh.Vertices.Count;
   }
  }
  else if(Kind=="animator-clips" || Kind=="animator-layered") {Time.DeltaTime=1/60.0f;Time.UnscaledDeltaTime=1/60.0f;scene.Update();for(let animator in animators)checksum+=animator.NormalizedTime;if(checksum<=0)return false;}
  else if(Kind=="animation-ik") {Time.DeltaTime=1/60.0f;IKSystem.Solve(scene);for(let limb in limbs)checksum+=limb.tip.Position.x;}
  else if(Kind=="voxel-rebuild") {for(let voxel in voxels){voxel.Rebuild();checksum+=1;}}
  else if(Kind=="voxel-carve") {for(let voxel in voxels){voxel.Fill();voxel.CarveLocal(.Zero,0.5f);checksum+=1;}}
  else if(Kind=="terrain-noise") {for(int i=0;i<Count;i++)for(int v=0;v<1024;v++)checksum+=Noise.Fbm((v%32)*0.1f,i*0.01f,(v/32)*0.1f,1337,5);}
  else if(Kind=="ai-behavior-tree") {for(let brain in brains) { if(brain.Tick(1/60.0f)!=.Success) return false;checksum+=brain.TickCount;}}
  else if(Kind=="ai-nav-path")
  {
   for(int i=0;i<Count;i++) { if(!navigation.Data.FindPath(.(2,0,2+(i%10)*0.1f),.(30,0,30-(i%10)*0.1f),path)) return false;navigation.Data.Smooth(path);checksum+=path.Count; }
  }
  else if(Kind=="ai-nav-bake") {if(!navigation.Bake()) return false;checksum+=navigation.Data.cells.Count;}
  else if(Kind=="ui-layout") {document.Layout(1280+(sample%2),720);checksum+=document.root.children.Count;}
  else if(Kind=="ui-parse") {document.Parse(markup);checksum+=document.root.children.Count;}
  else if(Kind.StartsWith("audio-")) {Time.DeltaTime=0.01f;Time.UnscaledDeltaTime=0.01f;scene.Update();let got=Audio.Render(audioBuffer);if(got!=480) return false;checksum+=Math.Abs(audioBuffer[0]);}
  else if(Kind=="asset-model-load") {for(int i=0;i<Count;i++){let model=SkinnedModel.Build("crowd.glb",null);defer delete model;if(model==null) return false;checksum+=model.Positions.Count;}}
  else return false;
  return checksum.IsFinite;
 }
 protected override void OnUpdate() {if(!Headless) {Time.DeltaTime=1/60.0f;Time.UnscaledDeltaTime=1/60.0f;for(let skin in skins) {let renderer=skin.GetComponent<MeshRenderer>();if(renderer!=null)renderer.LastDrawnFrame=Time.FrameCount;}scene.Update();}}
 protected override void OnRender()
 {
  let now=SDL.SDL_GetTicksNS();if(frame>Warmup) {Row(frame-Warmup-1,"frame_interval",(double)(now-previous)/1.0e6);let stats=bgfx.get_stats();if(stats!=null && frame%30==0) {Console.WriteLine(scope $"TELEMETRY,{frame-Warmup-1},gpu_ms,{stats.gpuTimerFreq>0 ? (double)(stats.gpuTimeEnd-stats.gpuTimeBegin)*1000/stats.gpuTimerFreq : 0}");Console.WriteLine(scope $"TELEMETRY,{frame-Warmup-1},draws,{stats.numDraw}");Console.WriteLine(scope $"TELEMETRY,{frame-Warmup-1},compute_dispatches,{stats.numCompute}");}}previous=now;
  if(frame++>=Warmup+Samples)
  {
   int gpu=0;for(let skin in skins) if(skin.SkinnedOnGpu)gpu++;
   Console.WriteLine(scope $"CHECK,gpu_skinned_models,{gpu}");Console.WriteLine(scope $"CHECK,skin_models,{skins.Count}");
   if(skins.Count>0) {Console.WriteLine(scope $"CHECK,vertices_per_model,{skins[0].Model.Positions.Count}");Console.WriteLine(scope $"CHECK,joints_per_model,{skins[0].Model.Joints.Count}");}
   Console.WriteLine(scope $"CHECK,framebuffer_width,{Width}");Console.WriteLine(scope $"CHECK,framebuffer_height,{Height}");Running=false;return;
  }
  view.Resize(Width,Height);view.Render(scene,camera.GetCameraData((float)Width/Height));
 }
 protected override void OnShutdown() {scene.StopPlay();Audio.Shutdown();}
}
