# Aligned box overlap results

See the [combined final report](../navigation-20261028c/REPORT.md) for measured gains, generic/analytic comparisons, geometry limitations, simulation controls and validation.
