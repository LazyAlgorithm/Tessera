# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 0.711 ms | 0.710 ms | 0.724 ms | 0.737 ms | 0.858 ms | 0.632 ms |
| CPU main thread | 0.503 ms | 0.501 ms | 0.511 ms | 0.514 ms | 0.632 ms | 0.487 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 0.435 ms
- Other: 0.067 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 0.215 ms | 0.215 ms | 1000 | 0.234 ms | 64/64 |
| Physics.Overlap | Physics | 0.109 ms | 0.400 ms | 1000 | 0.462 ms | 64/64 |
| Frame | Other | 0.067 ms | 0.503 ms | 1 | 0.631 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.044 ms | 0.044 ms | 1000 | 0.052 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.035 ms | 0.035 ms | 1000 | 0.100 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.032 ms | 0.032 ms | 1000 | 0.058 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 0.858 ms, CPU 0.500 ms, GPU -

```
Frame  total 0.500 ms, self 0.067 ms
  Physics.Overlap  total 0.398 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.214 ms, self 0.214 ms, 1000 calls
```

### Frame 14: interval 0.737 ms, CPU 0.507 ms, GPU -

```
Frame  total 0.507 ms, self 0.068 ms
  Physics.Overlap  total 0.405 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.215 ms, self 0.215 ms, 1000 calls
```

### Frame 2: interval 0.727 ms, CPU 0.499 ms, GPU -

```
Frame  total 0.499 ms, self 0.067 ms
  Physics.Overlap  total 0.398 ms, self 0.106 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.213 ms, self 0.213 ms, 1000 calls
```

### Frame 35: interval 0.724 ms, CPU 0.504 ms, GPU -

```
Frame  total 0.504 ms, self 0.072 ms
  Physics.Overlap  total 0.398 ms, self 0.107 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.215 ms, self 0.215 ms, 1000 calls
```

### Frame 47: interval 0.722 ms, CPU 0.504 ms, GPU -

```
Frame  total 0.504 ms, self 0.067 ms
  Physics.Overlap  total 0.403 ms, self 0.113 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.215 ms, self 0.215 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
