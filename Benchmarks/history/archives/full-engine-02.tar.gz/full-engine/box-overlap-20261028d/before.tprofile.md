# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 2.034 ms | 2.033 ms | 2.066 ms | 2.078 ms | 2.170 ms | 1.878 ms |
| CPU main thread | 1.751 ms | 1.746 ms | 1.773 ms | 1.784 ms | 1.878 ms | 1.725 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.682 ms
- Other: 0.068 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.EPA | Physics | 0.956 ms | 0.956 ms | 1000 | 0.982 ms | 64/64 |
| Physics.Overlap.ConvexPair | Physics | 0.306 ms | 1.261 ms | 1000 | 1.292 ms | 64/64 |
| Physics.Overlap.NativeContacts | Physics | 0.184 ms | 1.445 ms | 1000 | 1.493 ms | 64/64 |
| Physics.Overlap | Physics | 0.108 ms | 1.645 ms | 1000 | 1.721 ms | 64/64 |
| Frame | Other | 0.068 ms | 1.751 ms | 1 | 1.878 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.051 ms | 0.051 ms | 1000 | 0.056 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.041 ms | 0.041 ms | 1000 | 0.057 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.037 ms | 0.037 ms | 1000 | 0.086 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 2.170 ms, CPU 1.779 ms, GPU -

```
Frame  total 1.779 ms, self 0.070 ms
  Physics.Overlap  total 1.674 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.473 ms, self 0.192 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 1.281 ms, self 0.308 ms, 1000 calls
        Physics.Overlap.EPA  total 0.973 ms, self 0.973 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.051 ms, self 0.051 ms, 1000 calls
```

### Frame 36: interval 2.078 ms, CPU 1.746 ms, GPU -

```
Frame  total 1.746 ms, self 0.068 ms
  Physics.Overlap  total 1.642 ms, self 0.107 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.441 ms, self 0.183 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 1.258 ms, self 0.305 ms, 1000 calls
        Physics.Overlap.EPA  total 0.953 ms, self 0.953 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.051 ms, self 0.051 ms, 1000 calls
```

### Frame 61: interval 2.066 ms, CPU 1.743 ms, GPU -

```
Frame  total 1.742 ms, self 0.068 ms
  Physics.Overlap  total 1.638 ms, self 0.107 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.442 ms, self 0.183 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 1.259 ms, self 0.303 ms, 1000 calls
        Physics.Overlap.EPA  total 0.956 ms, self 0.956 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.050 ms, self 0.050 ms, 1000 calls
```

### Frame 2: interval 2.066 ms, CPU 1.752 ms, GPU -

```
Frame  total 1.752 ms, self 0.068 ms
  Physics.Overlap  total 1.647 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.447 ms, self 0.184 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 1.263 ms, self 0.305 ms, 1000 calls
        Physics.Overlap.EPA  total 0.958 ms, self 0.958 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.051 ms, self 0.051 ms, 1000 calls
```

### Frame 28: interval 2.059 ms, CPU 1.749 ms, GPU -

```
Frame  total 1.749 ms, self 0.068 ms
  Physics.Overlap  total 1.645 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.449 ms, self 0.183 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 1.266 ms, self 0.310 ms, 1000 calls
        Physics.Overlap.EPA  total 0.956 ms, self 0.956 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
