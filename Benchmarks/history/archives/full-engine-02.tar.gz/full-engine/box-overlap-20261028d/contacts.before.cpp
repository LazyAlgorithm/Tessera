// Query-only fast paths. Simulation and all unsupported configurations keep Jolt's convex solver.
#include <Jolt/Jolt.h>
#include <cmath>
#include <Jolt/Physics/Collision/CollisionDispatch.h>
#include <Jolt/Physics/Collision/CollideShape.h>
#include <Jolt/Physics/Collision/CollisionCollectorImpl.h>
#include <Jolt/Physics/Collision/TransformedShape.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/ScaleHelpers.h>
using namespace JPH;
static thread_local bool overlapContacts = false;
static CollisionDispatch::CollideShape originalSphereBox = nullptr;
static CollisionDispatch::CollideShape originalCapsuleBox = nullptr;
extern "C" bool tn_physics_overlap_contacts(bool enabled) {
    const bool previous = overlapContacts;
    overlapContacts = enabled;
    return previous;
}
static void interiorBox(const Shape* s1, const Shape* s2, Vec3Arg scale1, Vec3Arg scale2,
    Mat44Arg t1, Mat44Arg t2, const SubShapeIDCreator& id1, const SubShapeIDCreator& id2,
    const CollideShapeSettings& settings, CollideShapeCollector& collector, const ShapeFilter& filter) {
    const bool capsule = s1->GetSubType() == EShapeSubType::Capsule;
    const auto fallback = capsule ? originalCapsuleBox : originalSphereBox;
    if (!overlapContacts || settings.mCollectFacesMode != ECollectFacesMode::NoFaces || settings.mMaxSeparationDistance != 0) {
        fallback(s1, s2, scale1, scale2, t1, t2, id1, id2, settings, collector, filter);
        return;
    }
    const auto* box = static_cast<const BoxShape*>(s2);
    const Vec3 half = box->GetHalfExtent() * scale2.Abs();
    const Vec3 center = t2.InversedRotationTranslation() * t1.GetTranslation();
    const Vec3 clearance = half - center.Abs();
    const float margin = ScaleHelpers::ScaleConvexRadius(box->GetConvexRadius(), scale2);
    const Vec3 sphereScale = scale1.Abs();
    // Flat-face sphere contacts and interior aligned capsules have exact contacts. Other features
    // retain Jolt's original convex-radius handling and supporting-face data.
    if (sphereScale.GetX() != sphereScale.GetY() ||
        sphereScale.GetX() != sphereScale.GetZ()) {
        fallback(s1, s2, scale1, scale2, t1, t2, id1, id2, settings, collector, filter);
        return;
    }

    float radius, halfHeight = 0;
    int capsuleAxis = 0;
    if (capsule) {
        if (clearance.GetX() <= margin || clearance.GetY() <= margin || clearance.GetZ() <= margin) {
            fallback(s1, s2, scale1, scale2, t1, t2, id1, id2, settings, collector, filter);
            return;
        }
        const auto* cap = static_cast<const CapsuleShape*>(s1);
        radius = cap->GetRadius() * sphereScale.GetX();
        halfHeight = cap->GetHalfHeightOfCylinder() * sphereScale.GetX();
        const Vec3 axis = t2.Multiply3x3Transposed(t1.GetAxisY());
        if (std::abs(axis.GetY()) > std::abs(axis.GetX())) capsuleAxis = 1;
        if (std::abs(axis.GetZ()) > std::abs(axis[capsuleAxis])) capsuleAxis = 2;
        bool aligned = true;
        for (int i = 0; i < 3; ++i)
            if (i != capsuleAxis && std::abs(axis[i]) * halfHeight > 1.0e-6f) aligned = false;
        if (!aligned) {
            fallback(s1, s2, scale1, scale2, t1, t2, id1, id2, settings, collector, filter);
            return;
        }
    } else {
        radius = static_cast<const SphereShape*>(s1)->GetRadius() * sphereScale.GetX();
        // The full box contains its convex-radius approximation: distance beyond the sphere radius proves
        // separation without a generic convex solve. Contacts near rounded edges/corners still fall back.
        const Vec3 outside = Vec3::sMax(-clearance, Vec3::sZero());
        const float rejectRadius = radius + settings.mCollisionTolerance;
        if (outside.LengthSq() > rejectRadius * rejectRadius) return;
    }
    Vec3 expandedClearance = clearance;
    if (capsule) expandedClearance.SetComponent(capsuleAxis, clearance[capsuleAxis] + halfHeight);
    int axis = 0;
    if (expandedClearance.GetY() < expandedClearance.GetX()) axis = 1;
    if (expandedClearance.GetZ() < expandedClearance[axis]) axis = 2;
    if (!capsule) {
        for (int i = 0; i < 3; ++i)
            if (i != axis && clearance[i] <= margin) {
                fallback(s1, s2, scale1, scale2, t1, t2, id1, id2, settings, collector, filter);
                return;
            }
    }
    Vec3 normal = Vec3::sZero();
    normal.SetComponent(axis, center[axis] < 0 ? -1.0f : 1.0f);
    const Vec3 worldNormal = t2.Multiply3x3(normal);
    const float depth = radius + expandedClearance[axis];
    const float segmentSupport = capsule && axis == capsuleAxis ? halfHeight : 0;
    if (depth <= settings.mCollisionTolerance) {
        // Let the original solver resolve contacts within its collision tolerance at the tangent boundary.
        fallback(s1, s2, scale1, scale2, t1, t2, id1, id2, settings, collector, filter);
        return;
    }
    if (-depth >= collector.GetEarlyOutFraction()) return;
    CollideShapeResult result(t1.GetTranslation() - worldNormal * (radius + segmentSupport),
        t2 * (center + normal * clearance[axis]), -worldNormal, depth, id1.GetID(), id2.GetID(),
        TransformedShape::sGetBodyID(collector.GetContext()));
    collector.AddHit(result);
}
extern "C" void tn_physics_install_query_dispatch() {
    const auto sphere = CollisionDispatch::sGetCollideShape(EShapeSubType::Sphere, EShapeSubType::Box);
    if (sphere != interiorBox) {
        originalSphereBox = sphere;
        CollisionDispatch::sRegisterCollideShape(EShapeSubType::Sphere, EShapeSubType::Box, interiorBox);
    }
    const auto capsule = CollisionDispatch::sGetCollideShape(EShapeSubType::Capsule, EShapeSubType::Box);
    if (capsule != interiorBox) {
        originalCapsuleBox = capsule;
        CollisionDispatch::sRegisterCollideShape(EShapeSubType::Capsule, EShapeSubType::Box, interiorBox);
    }
}
