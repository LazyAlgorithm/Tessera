#!/usr/bin/env python3
"""Compare generic and analytic overlap contacts in interleaved fresh Release processes."""
from pathlib import Path
import subprocess,json,hashlib,csv,statistics,datetime
O=Path(__file__).resolve().parent;B=O.parent/'tessera/build/Release_Linux64/Benchmark/Benchmark'
manifest={'started':datetime.datetime.now().isoformat(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'recording':False,'warmup':120,'samples':300,'processes_per_mode':5,'runs':[]};rows=[]
for case in ['physics-overlap-sphere','physics-overlap-capsule','physics-overlap-box']:
 for repeat in range(5):
  for mode in (['generic','analytic'] if repeat%2==0 else ['analytic','generic']):
   name=f'{case}-{mode}-{repeat}';args=[str(B),case,'1000','120','300']+(['--generic-overlaps'] if mode=='generic' else [])
   print(name,flush=True);p=subprocess.run(args,cwd=O.parent,capture_output=True,text=True,timeout=90);(O/(name+'.log')).write_text(p.stdout+'\n'+p.stderr)
   values=[float(x.rsplit(',',1)[1]) for x in p.stdout.splitlines() if x.startswith('BENCH,tessera,')]
   checks={x.split(',')[1]:x.split(',',2)[2] for x in p.stdout.splitlines() if x.startswith('CHECK,')}
   assert p.returncode==0 and len(values)==300 and checks['hits']=='420000',(name,p.returncode,len(values),checks)
   rows.append([case,mode,repeat,statistics.median(values),statistics.mean(values),sorted(values)[284]])
   manifest['runs'].append({'name':name,'args':args,'exit':p.returncode,'checks':checks});(O/'contact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
manifest['completed']=datetime.datetime.now().isoformat();(O/'contact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (O/'contacts.csv').open('w') as f:w=csv.writer(f);w.writerow(['case','mode','repeat','median_ms','mean_ms','p95_ms']);w.writerows(rows)
