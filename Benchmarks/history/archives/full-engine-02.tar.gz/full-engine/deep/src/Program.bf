using System;
using System.Collections;
using Tessera;
using Bgfx;
using System.IO;
using System.Threading;
namespace Features;
class Program
{
 public static int Main(String[] args)
 {
  if(args.Count<4) return 1;
  let app=scope FeatureBench(); app.Kind.Set(args[0]); app.Count=SceneSerializer.ParseInt(args[1]); app.Warmup=SceneSerializer.ParseInt(args[2]); app.Samples=SceneSerializer.ParseInt(args[3]);
  app.Headless=!app.Kind.StartsWith("render-"); app.Width=args.Count>=6 ? SceneSerializer.ParseInt(args[4]) : 1280;app.Height=args.Count>=6 ? SceneSerializer.ParseInt(args[5]) : 720;Gfx.ResetFlags=0;
  if(args.Count==7) return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera","--frames",scope $"{app.Warmup+app.Samples+1}","--screenshot",args[6]));
  if(args.Count==5) return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera","--frames",scope $"{app.Warmup+app.Samples+1}","--screenshot",args[4]));
  return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera"));
 }
}
class FeatureBench : Application
{
 public String Kind=new .() ~ delete _;
 public int Count,Warmup,Samples;
 Scene scene=new .() ~ delete _;
 RenderView view ~ delete _;
 Camera camera;
 ReflectionProbe probe;
 Blackboard board=new .() ~ delete _;
 SaveNode save=new .(.Object) ~ delete _;
 String dataText=new .() ~ delete _;
 List<uint8> dataBytes=new .() ~ delete _;
 List<GameObject> cubes=new .() ~ delete _;
 SequenceAsset sequence=new .() ~ delete _;
 SequenceEvaluator evaluator=new .() ~ delete _;
 DialogueAsset dialogue=new .() ~ delete _;
 List<SkinnedMeshRenderer> skins=new .() ~ delete _;
 NavigationSurface navigation;
 List<LimbIK> limbs=new .() ~ delete _;
 List<VoxelObject> voxels=new .() ~ delete _;
 List<BehaviorTreeRunner> brains=new .() ~ delete _;
 List<Vector3> path=new .() ~ delete _;
 UIDocumentData document=new .() ~ delete _;
 String markup=new .() ~ delete _;
 float[] audioBuffer=new .[2048] ~ delete _;
 int frame;
 uint64 previous;
 double checksum;
 Rig rig=new .() ~ delete _;
 WeightPainter painter ~ delete _;
 TexturePaint paint=new .() ~ delete _;
 EditMesh paintMesh ~ delete _;
 List<Vector3> posedPositions=new .() ~ delete _;
 List<Vector3> posedNormals=new .() ~ delete _;
 uint8[] imagePixels=new .[512*512*4] ~ delete _;
 ENetTransport host ~ delete _;
 ENetTransport client ~ delete _;
 void* serverPeer;
 uint8[] packet=new .[64] ~ delete _;
 NetCompression compression=new .() ~ delete _;
 List<uint8> networkInput=new .() ~ delete _;
 List<uint8> compressed=new .() ~ delete _;
 List<uint8> decompressed=new .() ~ delete _;
 void* encoder;void* decoder;
 float[] voiceSamples=new .[960] ~ delete _;
 float[] voiceOutput=new .[5760] ~ delete _;
 uint8[] voicePacket=new .[4096] ~ delete _;
 int32 voiceLength;
 [CLink] static extern void* tn_voice_encoder_create(int32 rate);
 [CLink] static extern void tn_voice_encoder_destroy(void* value);
 [CLink] static extern void* tn_voice_decoder_create();
 [CLink] static extern void tn_voice_decoder_destroy(void* value);
 [CLink] static extern int32 tn_voice_encode(void* encoder,float* samples,uint8* output,int32 capacity);
 [CLink] static extern int32 tn_voice_decode(void* decoder,uint8* packet,int32 length,float* output,int32 recover);
 void Row(int i,StringView metric,double ms) => Console.WriteLine(scope $"BENCH,tessera,{Kind},{Count},{i},{metric},{ms}");
 protected override bool LoadsPlayerQuality => false;
    protected override bool OnInit()
 {
  RenderView.Antialias=false;RenderView.RenderScale=1;RenderView.MaxSceneHeight=0;Gfx.SetVsync(false);
  Assets.ProjectPath.Set("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets");
  Audio.NoDevice=true;if(Kind.StartsWith("audio-"))Audio.Disabled=false;
  let start=SDL.SDL_GetTicksNS();
  if(!Headless)
  {
   camera=scene.CreateGameObject("Camera").AddComponent<Camera>();camera.Transform.Position=.(0,8,-30);camera.farClip=1000;
   let sun=scene.CreateGameObject("Sun");sun.Transform.LocalEulerAngles=.(-45,45,0);sun.AddComponent<Light>();
   view=new RenderView(10);view.ToBackbuffer=true;view.DrawShadows=Kind.Contains("shadows");
   if(!Kind.Contains("skinning"))
   {
    for(int i=0;i<Count;i++) {let go=scene.CreateGameObject("Cube");go.Transform.Position=.((i%20-9.5f)*1.1f,1+(i/400)*1.1f,(i/20%20)*1.1f);let mr=go.AddComponent<MeshRenderer>();if(Kind=="render-transparency")mr.color=.(0.3f,0.7f,1,0.35f);if(Kind=="render-bloom") {mr.emissive=.White;mr.emissiveIntensity=5;}if(Kind=="render-decals")go.AddComponent<Decal>().size=.(1.1f,1.1f,1.1f);cubes.Add(go);}
    if(Kind=="render-ao")scene.Environment.ambientOcclusion=1;
    if(Kind=="render-dof")scene.Environment.depthOfField=1;
    if(Kind=="render-motion-blur")scene.Environment.motionBlur=1;
    if(Kind=="render-bloom")scene.Environment.bloom=0.5f;
    if(Kind=="render-grading") {scene.Environment.contrast=1.2f;scene.Environment.saturation=1.3f;scene.Environment.vignette=0.6f;}
    if(Kind=="render-reflections") {probe=scene.CreateGameObject("Probe").AddComponent<ReflectionProbe>();probe.Transform.Position=.(0,3,5);probe.size=.(30,20,30);probe.resolution=128;probe.refreshInterval=0.01f;}
    if(Kind=="render-foliage") {for(let cube in cubes)scene.DestroyImmediate(cube);cubes.Clear();let foliage=scene.CreateGameObject("Grass").AddComponent<Foliage>();foliage.viewDistance=1000;for(int i=0;i<Count;i++)foliage.Add(.((i%100-49.5f)*0.3f,0,(i/100)*0.3f),0,1);}
   }
   if(Kind.Contains("skinning"))
   {
    for(int i=0;i<Count;i++)
    {
     let go=scene.CreateGameObject("Character");go.Transform.Position=.((i%20-9.5f)*1.1f,0,(i/20)*1.1f);
     let skin=go.AddComponent<SkinnedMeshRenderer>();skin.model.Set("crowd.glb");skin.clip.Set("Wave");skin.gpuSkinning=!Kind.Contains("cpu");skin.OnValidate();skins.Add(skin);
    }
   }
  }
  if(Kind=="animation-ik")
  {
   for(int i=0;i<Count;i++){let root=scene.CreateGameObject("Arm");let a=scene.CreateGameObject("Upper",root.Transform).Transform;let b=scene.CreateGameObject("Lower",a).Transform;b.LocalPosition=.(0,-0.3f,0);let c=scene.CreateGameObject("Hand",b).Transform;c.LocalPosition=.(0,-0.3f,0);let target=scene.CreateGameObject("Target").Transform;target.Position=.(0.3f,-0.3f,0.2f);let ik=root.AddComponent<LimbIK>();ik.tip=c;ik.target=target;ik.rotationWeight=0;limbs.Add(ik);}
  }
  if(Kind=="voxel-rebuild" || Kind=="voxel-carve")
  {
   for(int i=0;i<Count;i++){let voxel=scene.CreateGameObject("Voxel").AddComponent<VoxelObject>();voxel.resolution=24;voxel.breakOffPieces=false;voxel.anchored=true;voxel.Fill();voxels.Add(voxel);}
  }
  if(Kind=="ai-behavior-tree")
  {
   let data=scope BehaviorTreeData();let root=data.AddNode(BehaviorLibrary.Find("root"),.Zero);let seq=data.AddNode(BehaviorLibrary.Find("sequence"),.Zero);data.Connect(root.id,seq.id);
   for(int n=0;n<8;n++) {let node=data.AddNode(BehaviorLibrary.Find("bb.set"),.Zero);node.values[0].Set(scope $"flag{n}");node.values[1].Set("true");data.Connect(seq.id,node.id);}
   data.Save("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/benchmark.tbt");
   for(int i=0;i<Count;i++){let brain=scene.CreateGameObject("Brain").AddComponent<BehaviorTreeRunner>();brain.tree.Set("benchmark.tbt");brains.Add(brain);}
  }
  if(Kind.StartsWith("ai-nav"))
  {
   let floor=scene.CreateGameObject("Floor");floor.Transform.Position=.(16,-0.5f,16);floor.AddComponent<BoxCollider>().size=.(32,1,32);
   for(int i=0;i<3;i++){let wall=scene.CreateGameObject("Wall");let z=(i%2)==0 ? 10.0f : 22.0f;wall.Transform.Position=.(8+i*8,1.5f,z);wall.AddComponent<BoxCollider>().size=.(1,3,20);}
   navigation=scene.CreateGameObject("Navigation").AddComponent<NavigationSurface>();navigation.size=.(32,5,32);navigation.cellSize=0.5f;
   if(!navigation.Bake()) return false;
  }
  if(Kind=="ui-layout" || Kind=="ui-parse")
  {
   markup.AppendF("<panel id=\"page\"><panel repeat=\"{}\" class=\"item\"></panel></panel>",Count);
   document.Parse(markup);document.styleText.Set("#page { width: 1280; height: 720; flex-direction: row; flex-wrap: wrap } .item { width: 20; height: 20 }");document.ParseStyles();document.Layout(1280,720);
  }
  if(Kind.StartsWith("audio-"))
  {
   scene.CreateGameObject("Listener").AddComponent<AudioListener>();
   for(int i=0;i<Count;i++) {let source=scene.CreateGameObject("Voice").AddComponent<AudioSource>();source.audioClip.Set("tone.wav");source.loop=true;source.playOnStart=false;source.volume=0.01f;source.occlusion=false;source.airAbsorption=false;source.doppler=0;source.Transform.Position=.((i%10)-5,0,5);source.Play();}
   Audio.Hrtf=Kind.Contains("hrtf");
  }
  if(Kind.StartsWith("save-")) {if(Kind.StartsWith("save-json")){let list=new SaveNode(.List);save.Set("items",list);for(int i=0;i<Count;i++){let item=new SaveNode(.Object);item.Set("name",SaveNode.MakeString(scope $"item{i}"));item.Set("value",SaveNode.MakeFloat(i*0.25));list.items.Add(item);}}else{for(int i=0;i<Count;i++)save.Set(scope $"item{i}",SaveNode.MakeFloat(i*0.25));}save.ToBytes(dataBytes);save.ToText(dataText,false);}
  if(Kind=="graph-blackboard") {for(int i=0;i<64;i++)board.SetNumber(scope $"value{i}",i);}
  if(Kind=="dialogue-condition") {DialogueVariables.Set("courage",3);DialogueVariables.Set("visits",10);}
  if(Kind=="sequence-evaluate" || Kind=="sequence-parse") {dataText.Set("sequence length 2 framerate 60\n");for(int i=0;i<Count;i++){let go=scene.CreateGameObject(scope $"Target{i}");dataText.AppendF("track transform \"Target{}\"\n key 0 position 0 0 0 rotation 0 0 0\n key 2 position 0 4 0 rotation 0 90 0\n",i);}sequence.Parse(dataText);evaluator.Bind(sequence,scene,null);}
  if(Kind=="dialogue-parse") {for(int i=0;i<Count;i++)dataText.AppendF("node node{}\n say - \"Benchmark line\"\n end\n",i);}
  if(Kind=="input-parse") {for(int i=0;i<Count;i++)dataText.AppendF("map Map{}\n action Jump{} button\n bind key Space\n",i,i);}
  if(Kind=="physics-joints") {for(int i=0;i<Count;i++){let anchorObject=scene.CreateGameObject("Anchor");anchorObject.Transform.Position=.((i%20)*3,10,(i/20)*3);anchorObject.AddComponent<BoxCollider>();let anchor=anchorObject.AddComponent<Rigidbody>();anchor.isKinematic=true;anchor.EnsureBody();let go=scene.CreateGameObject("Weight");go.Transform.Position=anchorObject.Transform.Position+.(1,-1,0);go.AddComponent<BoxCollider>();let body=go.AddComponent<Rigidbody>();body.allowSleeping=false;body.EnsureBody();Joint.Connect(body,anchor,anchorObject.Transform.Position,.Down);}}
  if(Kind=="network-loopback") {host=new ENetTransport();client=new ENetTransport();if(!host.Host(39437) || !client.Connect("127.0.0.1",39437,out serverPeer))return false;bool connected=false;let deadline=SDL.SDL_GetTicksNS()+2000000000;while(SDL.SDL_GetTicksNS()<deadline && !connected){client.Flush();host.Flush();while(client.Poll(let event)) {if(event.kind==.Connected)connected=true;}while(host.Poll(let event)) {}}if(!connected)return false;packet[0]=42;}
  if(Kind=="network-compress") {networkInput.Count=65536;for(int i=0;i<networkInput.Count;i++)networkInput[i]=(uint8)(i%23);}
  if(Kind.StartsWith("voice-")) {encoder=tn_voice_encoder_create(24000);decoder=tn_voice_decoder_create();for(int i=0;i<960;i++)voiceSamples[i]=Math.Sin(i*440*2*Math.PI_f/48000)*0.5f;voiceLength=tn_voice_encode(encoder,voiceSamples.Ptr,voicePacket.Ptr,4096);if(encoder==null || decoder==null || voiceLength<=0)return false;}
  if(Kind=="asset-pack-read") {if(!AssetPack.Mount("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/benchmark.tpak","/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets"))return false;}
  if(Kind=="baking-lightmap") {for(int i=0;i<Count;i++){let go=scene.CreateGameObject("Baked Cube");go.Transform.Position=.((i%10)*2,0,(i/10)*2);go.AddComponent<MeshRenderer>().bakedLighting=true;}}
  if(Kind.StartsWith("rig-")) {let problem=scope String();if(!rig.LoadSource("crowd.glb",problem))return false;for(int j=0;j<32;j++)rig.AddBone(scope $"Bone.{j:000}",j-1,.(0,j*3.0f/31,0),.(0,(j+1)*3.0f/31,0));if(!AutoWeights.Make(rig,64))return false;painter=new WeightPainter(rig);}
  if(Kind=="texture-paint") {paint.Create("benchmark-paint.png",512,512,.White);paintMesh=MeshShapes.Create(.Box,.());paintMesh.UpdateAutoUVs(.One);}
  if(Kind.StartsWith("texture-mips")) {for(int i=0;i<imagePixels.Count;i++)imagePixels[i]=(uint8)(i%256);}
  scene.StartPlay();Time.DeltaTime=1/60.0f;Time.UnscaledDeltaTime=1/60.0f;scene.Update();
  Console.WriteLine(scope $"CHECK,setup_ms,{(double)(SDL.SDL_GetTicksNS()-start)/1.0e6}");
  Console.WriteLine(scope $"CHECK,objects,{Count}");
  if(Headless)
  {
   for(int i=0;i<Warmup+Samples;i++)
   {
    let begin=SDL.SDL_GetTicksNS();
    if(!Work(i)) return false;
    let ms=(double)(SDL.SDL_GetTicksNS()-begin)/1.0e6;
    if(i>=Warmup) Row(i-Warmup,"feature_batch",ms);
   }
   if(Kind=="ai-nav-path") {double length=0;for(int p=1;p<path.Count;p++)length+=(path[p]-path[p-1]).Length;Console.WriteLine(scope $"CHECK,path_waypoints,{path.Count}");Console.WriteLine(scope $"CHECK,path_length,{length}");}
   Console.WriteLine(scope $"CHECK,checksum,{checksum}");Running=false;
  }
  previous=SDL.SDL_GetTicksNS();return true;
 }
 bool Work(int sample)
 {
  if(Kind.StartsWith("model-"))
  {
   let operation=scope String(Kind);operation.Replace("model-object-","model-");
   for(int i=0;i<Count;i++)
   {
    var settings=MeshShapes.Settings();settings.size=.(2,3,2);
    let shape=MeshShapes.Create(operation=="model-primitives" ? (MeshShapes.Kind)(i%MeshShapes.Names.Count) : .Box,settings);defer delete shape;
    int32[6] faces=.(0,1,2,3,4,5);
    switch(operation)
    {
    case "model-decimate": MeshOps.Subdivide(shape,faces,false);MeshOps.Decimate(shape,0.5f);
    case "model-weld": shape.Weld(0.001f);
    case "model-extrude": MeshOps.ExtrudeFaces(shape,faces,0.2f,true);
    case "model-inset": MeshOps.InsetFaces(shape,faces,0.1f);
    case "model-subdivide": MeshOps.Subdivide(shape,faces,false);
    case "model-bevel": let edges=scope List<uint64>();shape.Edges(edges);MeshOps.Bevel(shape,edges,0.1f,null,1);
    case "model-uv": shape.UpdateAutoUVs(.One);
    case "model-triangulate": MeshOps.Triangulate(shape,faces);
    default:
    }
    if(Kind.StartsWith("model-object-")){let go=scene.CreateGameObject("Model");go.AddComponent<MeshRenderer>();let model=go.AddComponent<ModelMesh>();model.Set(shape);if(model.DrawnMesh==null)return false;checksum+=model.DrawnMesh.Vertices.Count;scene.DestroyImmediate(go);}
    else {let mesh=scope Mesh();shape.Build(mesh,.One);checksum+=mesh.Vertices.Count;}
   }
  }
  else if(Kind=="rig-autoweights") {for(int i=0;i<Count;i++){if(!AutoWeights.Make(rig,64))return false;checksum+=rig.weights.Count;}}
  else if(Kind=="rig-weight-brush") {for(int i=0;i<Count;i++)checksum+=painter.Dab(.Add,12,.(0,1.2f,0),0.4f,0.1f,0.5f,false,rig.positions);}
  else if(Kind=="rig-pose") {for(int i=0;i<Count;i++){rig.Posed(posedPositions,posedNormals);checksum+=posedPositions.Count;}}
  else if(Kind=="texture-paint") {for(int i=0;i<Count;i++)checksum+=paint.Dab(paintMesh,.(0,0.5f,0.5f),0.6f,.(1,0,0,1),0.5f);}
  else if(Kind.StartsWith("texture-mips")) {for(int i=0;i<Count;i++){let levels=Textures.MakeMips(imagePixels,512,512,Kind.Contains("normal") ? .Normal : .Color,0,let width,let height,let count);checksum+=levels.Count;delete levels;}}
  else if(Kind=="asset-async-cold" || Kind=="asset-async-cache") {let batch=AssetLoader.Preload("crowd.glb","texture.png");let deadline=SDL.SDL_GetTicksNS()+10000000000;while(!batch.IsDone && SDL.SDL_GetTicksNS()<deadline){AssetLoader.Update();Thread.Sleep(0);}if(!batch.IsDone)return false;checksum+=batch.Loaded;delete batch;}
  else if(Kind=="terrain-mesh") {let go=scene.CreateGameObject("Terrain");let terrain=go.AddComponent<VoxelTerrain>();terrain.tileSize=1;terrain.sizeX=(int32)Count;terrain.sizeZ=1;terrain.flatHeight=8;terrain.voxelSize=1;terrain.minChunkY=0;terrain.maxChunkY=0;terrain.generateColliders=false;terrain.lodDistance=0;terrain.OnValidate();let deadline=SDL.SDL_GetTicksNS()+10000000000;int stable=0;while(stable<5 && SDL.SDL_GetTicksNS()<deadline){scene.Update();if(terrain.ChunkCount>0 && terrain.PendingChunks==0)stable++;else stable=0;Thread.Sleep(0);}if(stable<5)return false;let mesh=terrain.ChunkMesh(.(0,0,0));if(mesh==null || mesh.Vertices.Count==0)return false;checksum+=mesh.Vertices.Count;scene.DestroyImmediate(go);}
  else if(Kind=="network-loopback") {for(int i=0;i<Count;i++)client.Send(serverPeer,packet,true);client.Flush();int received=0;let deadline=SDL.SDL_GetTicksNS()+2000000000;while(received<Count && SDL.SDL_GetTicksNS()<deadline) {while(host.Poll(let event)) {if(event.kind==.Data) {received++;checksum+=event.length;}}host.Flush();while(client.Poll(let event)){}client.Flush();}if(received!=Count)return false;}
  else if(Kind=="network-compress") {for(int i=0;i<Count;i++){if(!compression.Encode(networkInput,compressed) || !compression.Decode(compressed,decompressed) || decompressed.Count!=networkInput.Count)return false;checksum+=compressed.Count;}}
  else if(Kind=="network-snapshot-pack") {for(int i=0;i<Count;i++){let packed=NetPack.Pack(.(i*0.1f,2,3),Quaternion.Euler(0,sample%360,0));NetPack.Unpack(packed,let position,let rotation);checksum+=position.x;}}
  else if(Kind=="anti-cheat-guard") {var value=GuardedInt((int32)sample);for(int i=0;i<Count;i++){value.Value=(int32)i;checksum+=value.Value;if(!value.Intact)return false;}}
  else if(Kind=="voice-encode") {for(int i=0;i<Count;i++){let bytes=tn_voice_encode(encoder,voiceSamples.Ptr,voicePacket.Ptr,4096);if(bytes<=0)return false;checksum+=bytes;}}
  else if(Kind=="voice-decode") {for(int i=0;i<Count;i++){let frames=tn_voice_decode(decoder,voicePacket.Ptr,voiceLength,voiceOutput.Ptr,0);if(frames<=0)return false;checksum+=frames;}}
  else if(Kind=="asset-pack-read") {for(int i=0;i<Count;i++){dataBytes.Clear();if(AssetPack.ReadAll("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/Data/blob.bin",dataBytes) case .Err)return false;if(dataBytes.Count!=65536)return false;checksum+=dataBytes.Count;}}
  else if(Kind=="baking-lightmap") {let settings=scope BakeSettings();settings.texelsPerMetre=2;settings.atlasSize=64;settings.samples=8;settings.bounces=1;settings.probes=false;let baker=scope LightBaker(scene,settings);baker.Run();checksum+=baker.Atlases.Count;}
  else if(Kind=="asset-image-decode") {for(int i=0;i<Count;i++){int32 width=0,height=0;let pixels=Native.tn_image_load("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets/texture.png",&width,&height);if(pixels==null || width!=512 || height!=512)return false;checksum+=width*height;Native.tn_image_free(pixels);}}
  else if(Kind=="save-binary-encode") {dataBytes.Clear();save.ToBytes(dataBytes);checksum+=dataBytes.Count;}
  else if(Kind=="save-binary-decode") {let loaded=SaveNode.FromBytes(dataBytes);if(loaded==null || loaded.Count!=Count)return false;checksum+=loaded.Count;delete loaded;}
  else if(Kind=="save-json-encode") {dataText.Clear();save.ToText(dataText,false);checksum+=dataText.Length;}
  else if(Kind=="save-json-decode") {let loaded=SaveNode.FromText(dataText);if(loaded==null || loaded["items"]==null || loaded["items"].Count!=Count)return false;checksum+=loaded["items"].Count;delete loaded;}
  else if(Kind=="graph-blackboard") {for(int i=0;i<Count;i++){let key=scope $"value{i%64}";board.SetNumber(key,(float)sample);checksum+=board.GetNumber(key);}}
  else if(Kind=="dialogue-condition") {for(int i=0;i<Count;i++)if(DialogueVariables.Evaluate("courage >= 2 and visits > 1"))checksum++;}
  else if(Kind=="dialogue-parse") {dialogue.Parse(dataText);checksum+=dialogue.nodes.Count;}
  else if(Kind=="sequence-parse") {sequence.Parse(dataText);checksum+=sequence.tracks.Count;}
  else if(Kind=="sequence-evaluate") {evaluator.Apply((sample%120)/60.0f,0,false);checksum+=sequence.tracks.Count;}
  else if(Kind=="input-parse") {InputActions.LoadText(dataText);checksum+=InputActions.Maps.Count;}
  else if(Kind=="physics-joints") {scene.FixedUpdate();scene.Update();checksum+=scene.Objects.Count;}
  else if(Kind=="baking-uv") {for(int i=0;i<Count;i++){let mesh=Primitives.CreateSphere();LightmapUV.Ensure(mesh);checksum+=mesh.Vertices.Count;delete mesh;}}
  else if(Kind=="animation-ik") {Time.DeltaTime=1/60.0f;IKSystem.Solve(scene);for(let limb in limbs)checksum+=limb.tip.Position.x;}
  else if(Kind=="voxel-rebuild") {for(let voxel in voxels){voxel.Rebuild();checksum+=1;}}
  else if(Kind=="voxel-carve") {for(let voxel in voxels){voxel.Fill();voxel.CarveLocal(.Zero,0.5f);checksum+=1;}}
  else if(Kind=="terrain-noise") {for(int i=0;i<Count;i++)for(int v=0;v<1024;v++)checksum+=Noise.Fbm((v%32)*0.1f,i*0.01f,(v/32)*0.1f,1337,5);}
  else if(Kind=="ai-behavior-tree") {for(let brain in brains) { if(brain.Tick(1/60.0f)!=.Success) return false;checksum+=brain.TickCount;}}
  else if(Kind=="ai-nav-path")
  {
   for(int i=0;i<Count;i++) { if(!navigation.Data.FindPath(.(2,0,2+(i%10)*0.1f),.(30,0,30-(i%10)*0.1f),path)) return false;navigation.Data.Smooth(path);checksum+=path.Count; }
  }
  else if(Kind=="ai-nav-bake") {if(!navigation.Bake()) return false;checksum+=navigation.Data.cells.Count;}
  else if(Kind=="ui-layout") {document.Layout(1280+(sample%2),720);checksum+=document.root.children.Count;}
  else if(Kind=="ui-parse") {document.Parse(markup);checksum+=document.root.children.Count;}
  else if(Kind.StartsWith("audio-")) {Time.DeltaTime=1024/48000.0f;Time.UnscaledDeltaTime=1024/48000.0f;scene.Update();let got=Audio.Render(audioBuffer);if(got!=1024) return false;checksum+=Math.Abs(audioBuffer[0]);}
  else if(Kind=="asset-model-load") {for(int i=0;i<Count;i++){let model=SkinnedModel.Build("crowd.glb",null);defer delete model;if(model==null) return false;checksum+=model.Positions.Count;}}
  else return false;
  return checksum.IsFinite;
 }
 protected override void OnUpdate() {if(!Headless) {Time.DeltaTime=1/60.0f;Time.UnscaledDeltaTime=1/60.0f;if(Kind=="render-motion-blur")camera.Transform.Position=.(Math.Sin(frame*0.01f)*2,8,-30);for(let skin in skins) {let renderer=skin.GetComponent<MeshRenderer>();if(renderer!=null)renderer.LastDrawnFrame=Time.FrameCount;}scene.Update();}}
 protected override void OnRender()
 {
  let now=SDL.SDL_GetTicksNS();if(frame>Warmup) {Row(frame-Warmup-1,"frame_interval",(double)(now-previous)/1.0e6);let stats=bgfx.get_stats();if(stats!=null && frame%30==0) {Console.WriteLine(scope $"TELEMETRY,{frame-Warmup-1},gpu_ms,{stats.gpuTimerFreq>0 ? (double)(stats.gpuTimeEnd-stats.gpuTimeBegin)*1000/stats.gpuTimerFreq : 0}");Console.WriteLine(scope $"TELEMETRY,{frame-Warmup-1},draws,{stats.numDraw}");Console.WriteLine(scope $"TELEMETRY,{frame-Warmup-1},compute_dispatches,{stats.numCompute}");}}previous=now;
  if(frame++>=Warmup+Samples)
  {
   int gpu=0;for(let skin in skins) if(skin.SkinnedOnGpu)gpu++;
   Console.WriteLine(scope $"CHECK,gpu_skinned_models,{gpu}");Console.WriteLine(scope $"CHECK,skin_models,{skins.Count}");
   if(skins.Count>0) {Console.WriteLine(scope $"CHECK,vertices_per_model,{skins[0].Model.Positions.Count}");Console.WriteLine(scope $"CHECK,joints_per_model,{skins[0].Model.Joints.Count}");}
   Console.WriteLine(scope $"CHECK,antialias,{RenderView.Antialias}");Console.WriteLine(scope $"CHECK,render_scale,{RenderView.RenderScale}");Console.WriteLine(scope $"CHECK,framebuffer_width,{Width}");Console.WriteLine(scope $"CHECK,framebuffer_height,{Height}");Running=false;return;
  }
  view.Resize(Width,Height);view.Render(scene,camera.GetCameraData((float)Width/Height));
 }
 protected override void OnShutdown() {scene.StopPlay();Audio.Shutdown();if(encoder!=null)tn_voice_encoder_destroy(encoder);if(decoder!=null)tn_voice_decoder_destroy(decoder);AssetPack.UnmountAll();AssetLoader.Shutdown();}
}
