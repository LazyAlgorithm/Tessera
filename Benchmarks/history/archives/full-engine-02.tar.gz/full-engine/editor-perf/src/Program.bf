using System;
using System.Collections;
using Tessera;
using Tessera.Editor;
namespace EditorPerformance;
class Program
{
 public static int Main(String[] args)
 {
  if(args.Count!=4)return 1;
  let kind=args[0];let count=SceneSerializer.ParseInt(args[1]);let warmup=SceneSerializer.ParseInt(args[2]);let samples=SceneSerializer.ParseInt(args[3]);
  Assets.ProjectPath.Set("/home/zerker24/BeefProjects/Tessera/Benchmarks/full-engine/assets");
  ApiIndex.Build("/home/zerker24/BeefProjects/Tessera","");
  let graph=scope NodeGraph();let variable=graph.AddVariable("value",.Float);var last=graph.AddNode(NodeLibrary.Find("event.update"),.Zero);
  for(int i=0;i<count;i++){let node=graph.AddVariableNode(variable,true,.Zero);node.values[2].Set("1");graph.Connect(last.id,0,node.id,0);last=node;}
  let theme=scope Theme();let problems=scope String();let text=scope String();let built=EditorTheme.Build("Benchmark",EditorTheme.Dark());EditorTheme.Write(built,text);delete built;
  let source=scope String();for(int i=0;i<count;i++)source.AppendF("class Actor{} : Component\n{{\n public float speed;\n public Vector3 offset;\n public void Walk(float dt) {{}}\n}}\n",i);
  double checksum=0;
  for(int sample=0;sample<warmup+samples;sample++)
  {
   let start=SDL.SDL_GetTicksNS();
   if(kind=="editor-api-index") {ApiIndex.Build("/home/zerker24/BeefProjects/Tessera","");checksum+=ApiIndex.TypeCount;}
   else if(kind=="editor-graph-generate") {let code=scope String();graph.Compile("Benchmark","Generated","benchmark.tgraph",code);if(code.Length<100)return 1;checksum+=code.Length;}
   else if(kind=="editor-graph-validate") {graph.Validate();checksum+=graph.nodes.Count;}
   else if(kind=="editor-code-index") {let entries=new Dictionary<String,ApiIndex.TypeEntry>();defer { DeleteDictionaryAndValues!(entries); }ApiIndex.ScanText(source,entries,false);checksum+=entries.Count;}
   else if(kind=="editor-code-completion") {for(int i=0;i<count;i++){let output=scope String();ApiIndex.Complete("Transform.P",output);checksum+=output.Length;}}
   else if(kind=="editor-theme-parse") {for(int i=0;i<count;i++){problems.Clear();if(!EditorTheme.Parse(text,theme,problems))return 1;checksum+=theme.colors.Count;}}
   else return 1;
   let ms=(double)(SDL.SDL_GetTicksNS()-start)/1.0e6;
   if(sample>=warmup)Console.WriteLine(scope $"BENCH,tessera,{kind},{count},{sample-warmup},editor_algorithm_batch,{ms}");
  }
  Console.WriteLine(scope $"CHECK,checksum,{checksum}");Console.WriteLine(scope $"CHECK,indexed_types,{ApiIndex.TypeCount}");return checksum>0 ? 0 : 1;
 }
}
