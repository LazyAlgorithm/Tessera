#!/usr/bin/env python3
from pathlib import Path
import subprocess,json,csv,collections,hashlib,datetime,sys,statistics,shutil,os
O=Path(__file__).resolve().parent;B=O.parent;R=B.parents[1]
manifest={'started':datetime.datetime.now().isoformat(),'unity_policy':'Reuse complete saved Unity measurements only; Unity is not executed or rebuilt. Workload definitions/settings retained.','jobs':[]}
# Freeze Unity inputs before creating any new result folders.
baselines={}
for folder in sorted((B/'results').iterdir()):
 if not(folder/'summary.csv').exists() or not(folder/'environment.json').exists() or (folder/'EXCLUDED.md').exists():continue
 env=json.loads((folder/'environment.json').read_text());args=env['arguments']
 if args['samples']<100 or args.get('screenshots'):continue
 grouped=collections.defaultdict(list)
 for row in csv.DictReader((folder/'summary.csv').open()):
  if row['engine']=='unity':grouped[(row['scenario'],int(row['count']),args.get('width',1280),args.get('height',720),args.get('fullscreen',False))].append(row)
 for key,rows in grouped.items():
  if len(rows)!=args['repeats']:continue
  baselines['|'.join(map(str,key))]={'folder':str(folder),'rows':rows,'arguments':args,'source_hashes':env.get('sources',{}),'binary_sha256':env.get('binary_sha256',{})}
(O/'unity-baselines.json').write_text(json.dumps(baselines,indent=2)+'\n')
projects=['tessera','features','navigation-load','extended','animation']
S=O/'snapshot'
source_hashes={str(f.relative_to(S)):hashlib.sha256(f.read_bytes()).hexdigest() for f in S.rglob('*') if f.is_file() and 'build' not in f.relative_to(S).parts}
(O/'snapshot-sha256.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
builds=[]
for project in projects:
 binary=S/project/'build/Release_Linux64/Benchmark/Benchmark'
 with (O/(project+'-build.log')).open('w') as f:p=subprocess.run(['BeefBuild','-workspace='+str(S/project),'-config=Release'],stdout=f,stderr=subprocess.STDOUT)
 builds.append({'project':project,'exit':p.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None});(O/'builds.json').write_text(json.dumps(builds,indent=2)+'\n')
 if p.returncode:raise RuntimeError('Build failed: '+project)
 print('BUILT '+project,flush=True)
jobs=[
 ('core',['--suite','all','--counts','100','1000']),
 ('scale',['--scenarios','render-shared','render-materials','render-culling','render-moving','render-shadows','render-lights','render-particles','scene-transforms','scene-hierarchy','--counts','10000']),
 ('navigation',['--features','--scenarios','ai-navmesh-path','ai-navmesh-path-batch','--counts','1','10','100','1000','--repeats','5']),
 ('grid-control',['--features','--scenarios','ai-nav-path','--counts','100']),
 ('baking',['--features','--scenarios','ai-navmesh-bake','ai-nav-bake','--counts','1','--warmup','10','--samples','100']),
 ('skinning',['--features','--scenarios','render-skinning-cpu','render-skinning-gpu','--counts','100']),
 ('skinning-1080',['--features','--native-project','extended','--fullscreen','--width','1920','--height','1080','--scenarios','render-skinning-gpu','--counts','1000']),
 ('transparency',['--features','--native-project','extended','--scenarios','render-transparency','--counts','1000']),
 ('animation',['--features','--native-project','animation','--scenarios','animator-clips','animator-layered','--counts','100','1000']),
 ('audio-image',['--features','--native-project','extended','--scenarios','audio-mix','asset-image-decode','--counts','100','--warmup','30','--samples','100']),
]
for name,extra in jobs:
 print('START '+name,flush=True)
 original_project=extra[extra.index('--native-project')+1] if '--native-project' in extra else ('features' if '--features' in extra else 'tessera')
 if '--native-project' in extra:
  offset=extra.index('--native-project');extra=extra[:offset]+extra[offset+2:]
 extra=[*extra,'--native-project',str(S/original_project)]
 args=[sys.executable,str(B/'run.py'),'--engines','tessera','--repeats','3','--warmup','120','--samples','300','--timeout','240',*extra]
 with (O/(name+'-run.log')).open('w') as f:proc=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 lines=(O/(name+'-run.log')).read_text().splitlines();result=next((x.split('Results: ',1)[1] for x in lines if x.startswith('Results: ')),None)
 failures=json.loads((Path(result)/'failures.json').read_text()) if result and (Path(result)/'failures.json').exists() else [{'error':'runner did not finish'}]
 # Capacity failures invalidate simulation results; inspect even if the benchmark process exited successfully.
 if result:
  for log in Path(result).glob('tessera-*.log'):
   if log.name.endswith('.process.log'):continue
   content=log.read_text(errors='replace').lower()
   if '[physics] solver capacity exceeded' in content:failures.append({'run':log.stem,'error':'solver capacity overflow; invalid measurement'})
 entry={'name':name,'command':args,'exit':proc.returncode,'results':result,'failures':failures};manifest['jobs'].append(entry);(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('DONE '+name+' failures='+str(len(failures)),flush=True)
# Supplemental moving-carve and moving-crowd workloads have no frozen Unity counterpart.
rows=[];supplement=[]
for case,n in [('nav-dynamic',1),('nav-dynamic',100),('nav-crowd',100),('nav-crowd',1000),('nav-crowd',2000)]:
 for backend,flags in [('grid',[]),('navmesh',['--navmesh'])]:
  for repeat in range(3):
   binary=S/'navigation-load/build/Release_Linux64/Benchmark/Benchmark';args=[str(binary),case,str(n),'40','120',*flags];p=subprocess.run(args,capture_output=True,text=True,timeout=180);name=f'{case}-{n}-{backend}-{repeat}';(O/(name+'.log')).write_text(p.stdout+'\n'+p.stderr)
   vals=[float(x.rsplit(',',1)[1]) for x in p.stdout.splitlines() if x.startswith('BENCH,tessera,')];assert p.returncode==0 and len(vals)==120,(name,p.returncode,len(vals))
   checks={x.split(',')[1]:x.split(',',2)[2] for x in p.stdout.splitlines() if x.startswith('CHECK,')}
   rows.append([case,n,backend,repeat,statistics.median(vals),statistics.mean(vals),sorted(vals)[113]])
   supplement.append({'name':name,'args':args,'exit':p.returncode,'checks':checks})
  print('DONE supplemental '+case+' '+str(n)+' '+backend,flush=True)
with (O/'supplemental.csv').open('w') as f:w=csv.writer(f);w.writerow(['case','count','backend','repeat','median_ms','mean_ms','p95_ms']);w.writerows(rows)
(O/'supplemental-manifest.json').write_text(json.dumps(supplement,indent=2)+'\n')
manifest['finished']=datetime.datetime.now().isoformat();(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('COMPLETE '+str(O),flush=True)
