using System;
using System.Collections;

namespace Tessera;

/// Scene-owned point quadtree. Transform notifications keep positions exact even for parent motion/teleports.
/// Public radius/baseOffset fields can change without a transform notification, so their cheap scalar scan is
/// deliberately retained before each query. Only nearby candidates pay active/surface/world-position checks.
class NavigationCrowdIndex
{
	class Entry
	{
		public NavigationAgent agent;
		public Vector3 position, offset;
		public int32 leaf = -1;
		public bool dirty;
	}

	class Quad
	{
		public float x0, z0, x1, z1;
		public int32[4] children = .(-1, -1, -1, -1);
		public List<int32> members = new .() ~ delete _;
	}

	List<Entry> mEntries = new .() ~ DeleteContainerAndItems!(_);
	Dictionary<NavigationAgent, int32> mIds = new .() ~ delete _;
	List<int32> mFree = new .() ~ delete _;
	List<int32> mDirty = new .() ~ delete _;
	List<Quad> mNodes = new .() ~ DeleteContainerAndItems!(_);
	List<int32> mStack = new .() ~ delete _;
	List<NavigationAgent> mResult = new .() ~ delete _;
	public void Register(NavigationAgent agent)
	{
		if (mIds.ContainsKey(agent)) return;
		int32 id;
		if (mFree.IsEmpty)
		{
			id = (int32)mEntries.Count;
			mEntries.Add(new .());
		}
		else
			id = mFree.PopBack();
		let e = mEntries[id];
		e.agent = agent;
		e.leaf = -1;
		e.dirty = false;
		mIds[agent] = id;
		Dirty(agent);
	}

	public void Unregister(NavigationAgent agent)
	{
		if (!mIds.TryGetValue(agent, let id)) return;
		let e = mEntries[id];
		if (e.leaf >= 0)
			mNodes[e.leaf].members.Remove(id);
		e.agent = null;
		e.leaf = -1;
		mIds.Remove(agent);
		mFree.Add(id);
	}

	public void Dirty(NavigationAgent agent)
	{
		if (!mIds.TryGetValue(agent, let id)) return;
		let e = mEntries[id];
		if (e.dirty) return;
		e.dirty = true;
		mDirty.Add(id);
	}

	void Read(Entry e)
	{
		e.offset = e.agent.baseOffset;
		e.position = e.agent.Transform.Position + e.offset;
		e.dirty = false;
	}

	bool Finite(Vector3 p) => p.x.IsFinite && p.y.IsFinite && p.z.IsFinite;
	void Rebuild()
	{
		ClearAndDeleteItems!(mNodes);
		float x0 = float.MaxValue, z0 = float.MaxValue, x1 = -float.MaxValue, z1 = -float.MaxValue;
		for (let e in mEntries)
		{
			e.leaf = -1;
			if (e.agent == null) continue;
			Read(e);
			if (!Finite(e.position)) continue;
			x0 = Math.Min(x0, e.position.x);
			z0 = Math.Min(z0, e.position.z);
			x1 = Math.Max(x1, e.position.x);
			z1 = Math.Max(z1, e.position.z);
		}
		mDirty.Clear();
		if (x0 == float.MaxValue) return;
		let size = Math.Max(Math.Max(x1 - x0, z1 - z0) + 2, 2);
		mNodes.Add(new .() { x0 = x0 - 1, z0 = z0 - 1, x1 = x0 - 1 + size, z1 = z0 - 1 + size });
		for (int32 id < (int32)mEntries.Count)
		{
			if (mEntries[id].agent != null && Finite(mEntries[id].position))
				Insert(id, 0, 0);
		}
	}

	void Insert(int32 id, int32 at, int depth)
	{
		let q = mNodes[at];
		let p = mEntries[id].position;
		if (q.children[0] >= 0)
		{
			let side = (p.x >= (q.x0 + q.x1) * 0.5f ? 1 : 0) + (p.z >= (q.z0 + q.z1) * 0.5f ? 2 : 0);
			Insert(id, q.children[side], depth + 1);
			return;
		}
		q.members.Add(id);
		mEntries[id].leaf = at;
		if (q.members.Count <= 8 || depth >= 8 || q.x1 - q.x0 <= 0.01f) return;
		let mx = (q.x0 + q.x1) * 0.5f, mz = (q.z0 + q.z1) * 0.5f;
		for (int i < 4)
		{
			q.children[i] = (int32)mNodes.Count;
			mNodes.Add(new .() { x0 = (i & 1) == 0 ? q.x0 : mx, x1 = (i & 1) == 0 ? mx : q.x1, z0 = (i & 2) == 0 ? q.z0 : mz, z1 = (i & 2) == 0 ? mz : q.z1 });
		}
		let old = scope List<int32>();
		old.AddRange(q.members);
		q.members.Clear();
		for (let member in old)
			Insert(member, at, depth);
	}

	void Refresh()
	{
		if (mNodes.IsEmpty || mNodes.Count > mIds.Count * 8 + 64)
		{
			Rebuild();
			return;
		}
		let root = mNodes[0];
		for (int i < mDirty.Count)
		{
			let id = mDirty[i];
			let e = mEntries[id];
			if (e.agent == null)
			{
				e.dirty = false;
				continue;
			}
			if (e.leaf >= 0)
				mNodes[e.leaf].members.Remove(id);
			e.leaf = -1;
			Read(e);
			if (!Finite(e.position)) continue;
			if (e.position.x < root.x0 || e.position.x > root.x1 || e.position.z < root.z0 || e.position.z > root.z1)
			{
				Rebuild();
				return;
			}
			Insert(id, 0, 0);
		}
		mDirty.Clear();
	}
	   /// Borrowed result, valid until the next query on this scene. Includes conservative extra candidates.
	public List<NavigationAgent> Query(Vector3 center, float distance)
	{
		float maxRadius = 0;
		for (let e in mEntries)
		{
			if (e.agent == null) continue;
			maxRadius = Math.Max(maxRadius, e.agent.radius);
			if (e.offset != e.agent.baseOffset)
				Dirty(e.agent);
		}
		Refresh();
		mResult.Clear();
		mStack.Clear();
		if (mNodes.IsEmpty) return mResult;
		let reach = distance + maxRadius;
		if (reach < 0) return mResult;
		mStack.Add(0);
		while (!mStack.IsEmpty)
		{
			let q = mNodes[mStack.PopBack()];
			if (q.x1 < center.x - reach || q.x0 > center.x + reach || q.z1 < center.z - reach || q.z0 > center.z + reach) continue;
			if (q.children[0] >= 0)
			{
				for (let child in q.children)
					mStack.Add(child);
			}
			else for (let id in q.members)
					if (mEntries[id].agent != null) mResult.Add(mEntries[id].agent);
		}
		return mResult;
	}
}
