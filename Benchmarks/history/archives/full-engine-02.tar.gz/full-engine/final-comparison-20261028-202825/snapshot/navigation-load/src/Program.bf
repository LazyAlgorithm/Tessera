using System;
using System.Collections;
using Tessera;

namespace NavigationLoad;

class Program
{
	public static int Main(String[] args)
	{
		if (args.Count < 4) return 1;
		let app = scope LoadBench();
		app.Kind.Set(args[0]);
		app.Count = SceneSerializer.ParseInt(args[1]);
		app.Warmup = SceneSerializer.ParseInt(args[2]);
		app.Samples = SceneSerializer.ParseInt(args[3]);
		if (args.Count == 6 && args[4] == "--capture")
			app.Capture.Set(args[5]);
		app.Uncached = args.Count == 5 && args[4] == "--uncached";
		app.UseNavMesh = args.Count == 5 && args[4] == "--navmesh";
		app.Headless = true;
		return app.Run(scope String[]("--engine-root", "/home/zerker24/BeefProjects/Tessera"));
	}
}
class LoadBench : Application
{
	public String Kind = new .() ~ delete _;
	public String Capture = new .() ~ delete _;
	public int Count, Warmup, Samples;
	public bool Uncached, UseNavMesh;
	Scene scene = new .() ~ delete _;
	NavigationSurface surface;
	NavigationObstacle obstacle;
	List<NavigationAgent> agents = new .() ~ delete _;
	List<Vector3> path = new .() ~ delete _;
	double checksum;
	void Solid(Vector3 at, Vector3 size)
	{
		let go = scene.CreateGameObject("Solid");
		go.Transform.Position = at;
		go.AddComponent<BoxCollider>().size = size;
	}

	protected override bool LoadsPlayerQuality => false;
	protected override bool OnInit()
	{
		Time.DeltaTime = 1 / 60.0f;
		Time.UnscaledDeltaTime = 1 / 60.0f;
		let crowd = Kind == "nav-crowd";
		let extent = crowd ? 384.0f : Kind == "nav-dynamic" ? 128.0f : 32.0f;
		Solid(.(extent / 2, -0.5f, extent / 2), .(extent, 1, extent));
		if (Kind == "nav-path-repeated" || Kind == "nav-path-fresh")
		{
			for (int i < 3)
				Solid(.(8 + i * 8, 1.5f, (i % 2) == 0 ? 10 : 22), .(1, 3, 20));
		}
		surface = scene.CreateGameObject("Navigation").AddComponent<NavigationSurface>();
		surface.backend = UseNavMesh ? .NavMesh : .Grid;
		surface.size = .(extent, 5, extent);
		surface.cellSize = crowd ? 2 : 0.5f;
		surface.includeRenderMeshes = false;
		if (!surface.Bake()) return false;
		if (Uncached)
			surface.Data.routeCacheCapacity = 0;
		if (Kind == "nav-dynamic")
		{
			obstacle = scene.CreateGameObject("Moving carve").AddComponent<NavigationObstacle>();
			obstacle.Transform.Position = .(60, 0, 64);
			obstacle.size = .(4, 2, 4);
			obstacle.carveOnlyStationary = false;
		}
		if (crowd)
		{
			let columns = (int)Math.Ceiling(Math.Sqrt((float)Count));
			for (int i < Count)
			{
				let go = scene.CreateGameObject("Walker");
				go.Transform.Position = .(65 + (i % columns) * 4, 0, 65 + (i / columns) * 4);
				let agent = go.AddComponent<NavigationAgent>();
				agent.surface = surface;
				agent.faceMovement = false;
				agent.radius = 0.4f;
				agents.Add(agent);
			}
		}
		scene.StartPlay();
		scene.Update();
		if (crowd)
		{
			for (int i < Count)
				agents[i].SetDestination(agents[i].Transform.Position + Vector3((i % 2) == 0 ? 32 : -32, 0, 0), 1.5f, 0.1f);
		}
		Profiler.ComponentSamples = false;
		Profiler.NameThread("Load Benchmark");
		Profiler.Local.limit = (int32)Samples;
		for (int s = 0; s < Warmup + Samples; s++)
		{
			Time.FrameCount = s;
			if (!Capture.IsEmpty && s >= Warmup)
			{
				Profiler.Enabled = true;
				Profiler.BeginFrame();
			}
			let begin = SDL.SDL_GetTicksNS();
			if (!Work(s)) return false;
			let ms = (double)(SDL.SDL_GetTicksNS() - begin) / 1.0e6;
			if (!Capture.IsEmpty && s >= Warmup)
				Profiler.EndFrame();
			if (s >= Warmup)
				Console.WriteLine(scope $"BENCH,tessera,{Kind},{Count},{s-Warmup},navigation_batch,{ms}");
		}
		if (!Capture.IsEmpty)
		{
			Profiler.Enabled = false;
			if (!Profiler.Local.Save(Capture) || !Profiler.Local.SaveReport(scope $"{Capture}.md")) return false;
		}
		Console.WriteLine(scope $"CHECK,checksum,{checksum}");
		Console.WriteLine(scope $"CHECK,path_points,{path.Count}");
		if (surface.Data.IsNavMesh)
		{
			Console.WriteLine(scope $"CHECK,tiles,{surface.Data.Mesh.TileCount}");
			Console.WriteLine(scope $"CHECK,rebuilt_tiles,{surface.Data.Mesh.LastRebuiltTiles}");
		}
		Console.WriteLine(scope $"CHECK,node_count,{surface.Data.NodeCount}");
		Console.WriteLine(scope $"CHECK,rebuilt_chunks,{surface.Data.LastRebuiltChunks}");
		Running = false;
		return true;
	}

	static uint32 Next(ref uint32 v)
	{
		v ^= v << 13;
		v ^= v >> 17;
		v ^= v << 5;
		return v;
	}

	bool Work(int sample)
	{
		if (Kind == "nav-crowd")
		{
			scene.Update();
			for (let agent in agents)
			{
				let p = agent.Transform.Position;
				if (!p.x.IsFinite || !p.z.IsFinite || agent.PathFailed) return false;
				checksum += p.x + p.z;
			}
			return checksum.IsFinite;
		}
		if (Kind == "nav-dynamic")
		{
			obstacle.Transform.Position = .(60 + (sample % 2) * 8, 0, 64);
			obstacle.Update();
			surface.RefreshOverlay();
		}
		for (int i < Count)
		{
			var from = Vector3(2, 0, 2 + (i % 10) * 0.1f), to = Vector3(30, 0, 30 - (i % 10) * 0.1f);
			if (Kind == "nav-dynamic")
			{
				from = .(4, 0, 4);
				to = .(124, 0, 124);
			}
			if (Kind == "nav-path-fresh")
			{
				uint32 v = (uint32)(sample * Count + i) * 747796405u + 2891336453u;
				from = .(1 + (Next(ref v) % 60) * 0.5f, 0, 1 + (Next(ref v) % 60) * 0.5f);
				to = .(1 + (Next(ref v) % 60) * 0.5f, 0, 1 + (Next(ref v) % 60) * 0.5f);
			}
			if (!surface.Data.FindPath(from, to, path, null, 2, true, true)) return false;
			checksum += path.Count;
		}
		return checksum.IsFinite;
	}

	protected override void OnShutdown()
	{
		scene.StopPlay();
	}
}
