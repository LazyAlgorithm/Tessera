using System;
using System.Collections;
using Tessera;
namespace Bench;
class Program
{
    public static int Main(String[] args)
    {
        if (args.Count != 4 && args.Count != 5 && args.Count != 6) { Console.WriteLine("Usage: Benchmark SCENARIO COUNT WARMUP SAMPLES [--capture FILE]"); return 1; }
        let app = scope Benchmark();
        app.Kind.Set(args[0]);
        app.Count = SceneSerializer.ParseInt(args[1]);
        app.Warmup = SceneSerializer.ParseInt(args[2]);
        app.Samples = SceneSerializer.ParseInt(args[3]);
        app.GenericOverlaps = args.Count==5 && args[4]=="--generic-overlaps";
        if(args.Count==6 && args[4]=="--capture") app.ProfilePath.Set(args[5]);
        if (app.Count < 1 || app.Warmup < 0 || app.Samples < 1) return 1;
        if (!app.Kind.StartsWith("scene-") && app.Kind != "render-particles" && app.Kind != "render-shared" && app.Kind != "render-materials" && app.Kind != "render-moving" && app.Kind != "render-culling" && app.Kind != "render-shadows" && app.Kind != "physics-free" && app.Kind != "physics-pile" && app.Kind != "physics-raycast" && app.Kind != "physics-mesh" && app.Kind != "physics-mesh-raycast" && app.Kind != "physics-ccd" && app.Kind != "physics-discrete" && app.Kind != "physics-mixed-shapes" && app.Kind != "physics-characters-flat" && app.Kind != "physics-characters-steps" && app.Kind != "physics-spherecast" && app.Kind != "physics-capsulecast" && app.Kind != "physics-boxcast" && app.Kind != "physics-overlap-sphere" && app.Kind != "physics-overlap-capsule" && app.Kind != "physics-overlap-box" && app.Kind != "render-spheres" && app.Kind != "render-lights" && app.Kind != "render-physics") return 1;
        app.Headless = app.Kind.StartsWith("physics") || app.Kind.StartsWith("scene-");
        Gfx.ResetFlags = 0;
        app.Width=1280; app.Height=720;
        if(args.Count==5 && !app.GenericOverlaps) return app.Run(scope String[]("--engine-root", "/home/zerker24/BeefProjects/Tessera", "--frames", scope $"{app.Warmup+app.Samples+1}", "--screenshot", args[4]));
        return app.Run(scope String[]("--engine-root", "/home/zerker24/BeefProjects/Tessera"));
    }
}
class Benchmark : Application
{
    public String Kind = new .() ~ delete _;
    public String ProfilePath=new .() ~ delete _;
 public int Count, Warmup, Samples;
    public bool GenericOverlaps;
    Scene mScene ~ delete _;
    RenderView mView ~ delete _;
    Camera mCamera;
    List<GameObject> mCubes = new .() ~ delete _;
    ParticleSystem mParticles;
    String mSerialized=new .() ~ delete _;
    AnimationClip.Track mTrack=new .() ~ delete _;
    NetWriter mWriter=new .() ~ delete _;
    List<Rigidbody> mBodies = new .() ~ delete _;
    Mesh mTerrainMesh ~ delete _;
    bool Characters => Kind.StartsWith("physics-characters");
    bool Fast => Kind=="physics-ccd" || Kind=="physics-discrete";
    bool Query => Kind.Contains("cast") || Kind.Contains("overlap");
    bool Gravity => Kind=="physics-pile" || Kind=="physics-mesh" || Kind=="physics-mixed-shapes" || Kind=="render-physics" || Characters;
    int mFrame;
    uint64 mPrevious;
    void Row(int sample, StringView metric, double ms)
    {
        Console.WriteLine(scope $"BENCH,tessera,{Kind},{Count},{sample},{metric},{ms}");
    }
    protected override bool LoadsPlayerQuality => false;
    protected override bool OnInit()
    {
        RenderView.Antialias=false;RenderView.RenderScale=1;RenderView.MaxSceneHeight=0;Gfx.SetVsync(false);
        Console.WriteLine("BENCH,engine,scenario,count,sample,metric,ms");
        let setupStart=SDL.SDL_GetTicksNS();
        mScene = new Scene();
        mScene.Physics.useAnalyticOverlapContacts = !GenericOverlaps;
        if (!Headless)
        {
            let cam=mScene.CreateGameObject("Camera");
            cam.Transform.Position=.(0,8,-30);
            mCamera=cam.AddComponent<Camera>(); mCamera.farClip=1000;
            let sun=mScene.CreateGameObject("Sun");
            sun.Transform.LocalEulerAngles=.(-45,45,0);
            sun.AddComponent<Light>();
            if(Kind=="render-lights") for(int i=0;i<16;i++)
            {
                let go=mScene.CreateGameObject("Point Light"); go.Transform.Position=.((i%4-1.5f)*6,5,(i/4)*6);
                let light=go.AddComponent<Light>(); light.type=.Point;
            }
            mView=new RenderView(10); mView.ToBackbuffer=true;
            mView.DrawShadows=Kind=="render-shadows";
        }
        if(Kind.StartsWith("physics") || Kind=="render-physics")
        {
            let ground=mScene.CreateGameObject("Ground");
            if(Kind=="physics-mesh" || Kind=="physics-mesh-raycast")
            {
                mTerrainMesh=TerrainMesh(); ground.AddComponent<MeshRenderer>().RuntimeMesh=mTerrainMesh;
                ground.AddComponent<MeshCollider>();
            }
            else
            {
                ground.Transform.Position=.(0,Fast ? 0 : -1,0);
                ground.AddComponent<BoxCollider>().size=.(1000,Fast ? 0.1f : 1,1000);
            }
            if(Characters && Kind.EndsWith("steps")) for(int lane=0;lane<20;lane++)
            {
                let step=mScene.CreateGameObject("Step"); step.Transform.Position=.((lane-9.5f)*3,-0.4f,4);
                step.AddComponent<BoxCollider>().size=.(2,0.2f,2);
            }
        }
        for(int i=0;i<Count;i++)
        {
            let go=mScene.CreateGameObject("Cube");
            go.Transform.Position=.((i%20-9.5f)*1.1f,1+(i/400)*1.1f,(i/20%20)*1.1f);
            if(Kind=="render-culling" && i%10!=0) go.Transform.Position+=.(0,0,-1000);
            if(!Headless && Kind!="render-particles")
            {
                let mr=go.AddComponent<MeshRenderer>();
                if(Kind=="render-spheres") mr.mesh.Set("builtin:sphere");
                if(Kind=="render-materials") { mr.metallic=(i%256)/255.0f; mr.roughness=(i/256%256)/255.0f; }
            }
            if(Kind.StartsWith("physics") || Kind=="render-physics")
            {
                if(Characters) { go.Transform.Position=.((i%20-9.5f)*3,0.52f,-(i/20)*3); go.AddComponent<CapsuleCollider>().height=2; }
                else if(Kind=="physics-mixed-shapes" && i%3==1) go.AddComponent<SphereCollider>().radius=0.5f;
                else if(Kind=="physics-mixed-shapes" && i%3==2) go.AddComponent<CapsuleCollider>().height=2;
                else go.AddComponent<BoxCollider>().size=.One;
                if(Kind=="physics-mixed-shapes") go.Transform.Position=.((i%20-9.5f)*2.2f,2+(i/400)*2.2f,(i/20%20)*2.2f);
                let rb=go.AddComponent<Rigidbody>();
                rb.useGravity=Gravity; rb.continuousCollision=Kind=="physics-ccd";
                rb.freezeRotation=Characters;
                if(Characters) go.AddComponent<DrivenMotor>();
                mBodies.Add(rb);
                rb.allowSleeping=false;
                rb.friction=0.5f; rb.bounciness=0;
                rb.linearDamping=0.05f; rb.angularDamping=0.05f;
            }
            if(Kind=="scene-scripts") go.AddComponent<BenchScript>();
            if(Kind=="scene-hierarchy" && i%8!=0) go.Transform.SetParent(mCubes[i-1].Transform,false);
            mCubes.Add(go);
        }
        if(Kind=="render-particles") { mParticles=mScene.CreateGameObject("Particles").AddComponent<ParticleSystem>(); mParticles.maxParticles=(int32)Count; mParticles.burst=(int32)Count; mParticles.rate=0; mParticles.lifetime=10000; mParticles.speed=0; mParticles.gravity=.Zero; mParticles.emitRadius=8; }
        for(int key=0;key<16;key++) mTrack.SetKey(key/15.0f,.(key/15.0f,0,0),.(0,key*10.0f,0),.One);
        mScene.StartPlay(); mScene.Update();
        if(Kind=="scene-deserialize") SceneSerializer.Save(mScene,mSerialized);
        // Initialize and optimize the query tree before stationary raycast measurements.
        if(Kind.StartsWith("physics")) { mScene.FixedUpdate(); mScene.Update(); }
        Console.WriteLine(scope $"CHECK,setup_ms,{(double)(SDL.SDL_GetTicksNS()-setupStart)/1.0e6}");
        if(Headless)
        {
            int hits=0; int tunnels=0;
            List<ShapeCastHit> overlapHits=scope .();
            if(!ProfilePath.IsEmpty) { Profiler.NameThread("Benchmark Main"); Profiler.Local.Clear(); Profiler.Local.limit=(int32)Samples; Profiler.ComponentSamples=false; }
            for(int i=0;i<Warmup+Samples;i++)
            {
                if(Fast) for(int j=0;j<Count;j++)
                {
                    var state=mBodies[j].State; state.position=.((j%20-9.5f)*1.1f,4,(j/20)*1.1f);
                    state.rotation=.Identity; state.linearVelocity=.(0,-300,0); state.angularVelocity=.Zero;
                    mBodies[j].SetState(state);
                }
             if(!ProfilePath.IsEmpty && i>=Warmup) { Profiler.Enabled=true; Time.FrameCount=i-Warmup; Profiler.BeginFrame(); }
                let start=SDL.SDL_GetTicksNS();
                if(Kind.StartsWith("scene-"))
                {
                    if(Kind=="scene-serialize") { mSerialized.Clear(); SceneSerializer.Save(mScene,mSerialized); if(mSerialized.Length==0) return false; }
                    else if(Kind=="scene-deserialize") { let loaded=scope Scene(); SceneSerializer.Load(loaded,mSerialized); if(loaded.Objects.Count!=Count) return false; }
                    else if(Kind=="scene-animation-sample") { double checksum=0; for(int j=0;j<Count;j++) for(int bone=0;bone<32;bone++) { mTrack.Sample(((i+bone)%60)/60.0f,let pos,let rot,let scale); checksum+=pos.x; } if(!checksum.IsFinite) return false; }
                    else if(Kind=="scene-network-codec") { mWriter.Clear(); for(int j=0;j<Count;j++) { mWriter.WriteVarUInt((uint32)j); mWriter.Write<Vector3>(.(j,2,3)); mWriter.Write<Quaternion>(.Identity); mWriter.Write<uint32>(123); } var reader=NetReader(mWriter.Data.Ptr,mWriter.Data.Count); for(int j=0;j<Count;j++) { if(reader.ReadVarUInt()!=(uint32)j) return false; let pos=reader.Read<Vector3>(); reader.Read<Quaternion>(); if(reader.Read<uint32>()!=123 || pos.x!=j || !reader.Ok) return false; } }
                    else if(Kind=="scene-transforms" || Kind=="scene-hierarchy") { for(let go in mCubes) go.Transform.LocalPosition+=.(0.001f,0,0); double checksum=0; for(let go in mCubes) checksum+=go.Transform.Position.x; if(!checksum.IsFinite) return false; }
                    else if(Kind=="scene-churn") { for(int j=0;j<Count;j++) { let go=mScene.CreateGameObject("Transient"); go.AddComponent<BenchScript>(); mScene.DestroyImmediate(go); } }
                    mScene.Update();
                }
                else if(Query)
                {
                    for(int q=0;q<1000;q++)
                    {
                        var from=Vector3((q%20-9.5f)*1.1f,100,(q/20%20)*1.1f);
                        if(Kind=="physics-mesh-raycast") from+=.(0.013f,0,0.017f);
                        bool found=false;
                        ShapeCastHit shapeHit;
                        switch(Kind)
                        {
                        case "physics-spherecast": found=mScene.Physics.SphereCast(from,0.5f,.Down,200,out shapeHit);
                        case "physics-capsulecast": found=mScene.Physics.CapsuleCast(from-Vector3.Up*0.5f,from+Vector3.Up*0.5f,0.5f,.Down,200,out shapeHit);
                        case "physics-boxcast": found=mScene.Physics.BoxCast(from,.One,.Identity,.Down,200,out shapeHit);
                        case "physics-overlap-sphere": found=mScene.Physics.OverlapSphere(.(from.x,1,from.z),0.75f,overlapHits)>0;
                        case "physics-overlap-capsule": found=mScene.Physics.OverlapCapsule(.(from.x,0.5f,from.z),.(from.x,1.5f,from.z),0.5f,overlapHits)>0;
                        case "physics-overlap-box": found=mScene.Physics.OverlapBox(.(from.x,1,from.z),.One,.Identity,overlapHits)>0;
                        default: found=mScene.Physics.Raycast(from,.Down,200,let rayHit);
                        }
                        if(found) hits++;
                    }
                }
                else { mScene.FixedUpdate(); mScene.Update(); }
                let ms=(double)(SDL.SDL_GetTicksNS()-start)/1.0e6;
             if(!ProfilePath.IsEmpty && i>=Warmup) Profiler.EndFrame();
                if(i>=Warmup)
                {
                    Row(i-Warmup,Kind.StartsWith("scene-") ? "scene_batch" : Query ? "query_batch_1000" : "physics_tick",ms);
                    if(Fast) for(let go in mCubes) if(go.Transform.Position.y < -0.55f) tunnels++;
                }
            }
            if(!ProfilePath.IsEmpty) { Profiler.Enabled=false; if(!Profiler.Local.Save(ProfilePath) || !Profiler.Local.SaveReport(scope $"{ProfilePath}.md")) return false; }
            for(let go in mCubes) if(!go.Transform.Position.y.IsFinite) { Log.Error("Non-finite body position"); return false; }
            if(Kind.Contains("raycast") && hits!=(Warmup+Samples)*1000) { Log.Error("Raycast hit validation failed"); return false; }
            Console.WriteLine(scope $"CHECK,serialized_bytes,{mSerialized.Length}");
            Console.WriteLine(scope $"CHECK,network_bytes,{mWriter.Data.Count}");
            Console.WriteLine(scope $"CHECK,scene_objects,{mScene.Objects.Count}");
            Console.WriteLine(scope $"CHECK,script_calls,{BenchScript.Calls}");
            Console.WriteLine(scope $"CHECK,hits,{hits}"); Console.WriteLine(scope $"CHECK,objects,{Count}");
            Console.WriteLine(scope $"CHECK,tunnels,{tunnels}"); Console.WriteLine(scope $"CHECK,projectile_trials,{Fast ? Count*Samples : 0}");
            if(Characters) Console.WriteLine(scope $"CHECK,first_character_z,{mCubes[0].Transform.Position.z}");
            if(Kind=="physics-mesh") { int fallen=0; for(let go in mCubes) if(go.Transform.Position.y < -2) fallen++; Console.WriteLine(scope $"CHECK,fallen_below_mesh,{fallen}"); }
            Running=false;
        }
        mPrevious=SDL.SDL_GetTicksNS();
        return true;
    }
    protected override void OnFixedUpdate() { if(Kind=="render-physics") mScene.FixedUpdate(); }
    protected override void OnUpdate()
    {
        if(Kind=="render-physics" || Kind=="render-particles") mScene.Update();
        if(Kind=="render-moving")
            for(let go in mCubes) go.Transform.LocalEulerAngles=.(0,mFrame*0.5f,0);
    }
    protected override void OnRender()
    {
        let now=SDL.SDL_GetTicksNS();
        if(mFrame>Warmup) Row(mFrame-Warmup-1,"frame_interval",(double)(now-mPrevious)/1.0e6);
        mPrevious=now;
        if(mFrame++>=Warmup+Samples) { if(mParticles!=null) Console.WriteLine(scope $"CHECK,alive_particles,{mParticles.AliveCount}"); Console.WriteLine(scope $"CHECK,antialias,{RenderView.Antialias}");Console.WriteLine(scope $"CHECK,render_scale,{RenderView.RenderScale}");Console.WriteLine(scope $"CHECK,framebuffer_width,{Width}"); Console.WriteLine(scope $"CHECK,framebuffer_height,{Height}"); Running=false; return; }
        mView.Resize(Width,Height);
        mView.Render(mScene,mCamera.GetCameraData((float)Width/Height));
    }
    static Mesh TerrainMesh()
    {
        const int side=64;
        let mesh=new Mesh();
        for(int z=0;z<=side;z++) for(int x=0;x<=side;x++)
            mesh.AddVertex(.(x-32,Math.Sin(x*0.3f)*Math.Cos(z*0.3f)*0.25f-0.5f,z-16),.Up,.White);
        for(int z=0;z<side;z++) for(int x=0;x<side;x++)
        {
            let a=(uint32)(z*(side+1)+x); let b=a+1; let c=a+side+1; let d=c+1;
            mesh.AddTriangle(a,c,b); mesh.AddTriangle(b,c,d);
        }
        mesh.RecalculateBounds(); return mesh;
    }
    protected override void OnShutdown() { mScene.StopPlay(); }
}

[Component]
class DrivenMotor : CharacterMotor
{
    public override void GatherInput(ref NetInput input) { input=default; input.moveZ=1; }
}

[Component]
class BenchScript : Component
{
    public static int64 Calls;
    public override void Update() { Calls++; Transform.LocalPosition+=.(0.001f,0,0); }
}
