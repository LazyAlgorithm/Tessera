#!/usr/bin/env python3
from pathlib import Path
import csv,json,statistics as st,hashlib,datetime,shutil
O=Path(__file__).resolve().parent;B=O.parent;R=B.parents[1]
M=json.loads((O/'manifest.json').read_text());U=json.loads((O/'unity-baselines.json').read_text())
assert len(M['jobs'])==10 and all(j['exit']==0 and not j['failures'] for j in M['jobs']) and M.get('finished')
rows=[];total=0;checks={};definitions=[]
for job in M['jobs']:
 folder=Path(job['results']);env=json.loads((folder/'environment.json').read_text());args=env['arguments'];groups={}
 for row in csv.DictReader((folder/'summary.csv').open()):groups.setdefault((row['scenario'],int(row['count'])),[]).append(row)
 for row in csv.DictReader((folder/'checks.csv').open()):checks.setdefault((row['scenario'],int(row['count']),int(row['repeat'])),{})[row['check']]=row['value']
 for (case,n),values in groups.items():
  assert len(values)==args['repeats'];total+=len(values)
  native=st.median(float(v['median_ms']) for v in values);tail=st.median(float(v['p95_ms']) for v in values)
  alias={'ai-navmesh-path':'ai-nav-path','ai-navmesh-bake':'ai-nav-bake'}.get(case,case)
  w,h=args.get('width',1280),args.get('height',720);full=args.get('fullscreen',False)
  baseline=U.get('|'.join(map(str,(alias,n,w,h,full))))
  unity=st.median(float(x['median_ms']) for x in baseline['rows']) if baseline else None
  same=baseline and all(args[k]==baseline['arguments'][k] for k in ['warmup','samples'])
  if baseline:assert same,(case,n,'warmup/sample mismatch')
  caveat=''
  if case in ['scene-empty','scene-scripts']:caveat='Different traversal/callback operations; no ranked ratio.'
  if 'characters' in case:caveat='Different character motor behavior; no ranked ratio.'
  if case=='render-physics':caveat='Different simulation-time advance per rendered second; no ranked ratio.'
  if case.startswith('render-') and not caveat:caveat='Native rendering pipelines/image quality differ; frame intervals, not GPU-only cost.'
  if 'overlap-' in case:caveat='Tessera contact collection versus Unity collider-list NonAlloc query.'
  if case.startswith('ai-navmesh-path') and '-batch' not in case:caveat='Same maze/endpoints; polygon outputs and clearance differ.'
  if case.endswith('-batch'):caveat='16-thread Tessera batch; no equivalent saved Unity parallel workload.'
  if case=='ai-nav-path':caveat='Explicit walking-grid control; the gameplay default is NavMesh.'
  if case=='ai-navmesh-bake':caveat='Native bake integrations differ; static scene/clearance/voxel inputs retained.'
  if case=='render-spheres':caveat='Historical Unity sphere winding/normals changed; historical timing only, no ranked ratio.'
  ranked=unity is not None and not any(x in caveat for x in ['no ranked ratio'])
  rows.append({'group':job['name'],'case':case,'count':n,'width':w,'height':h,'fullscreen':full,'tessera_ms':native,'unity_ms':unity,'ratio':native/unity if ranked else None,'tessera_p95_ms':tail,'unity_p95_ms':st.median(float(x['p95_ms']) for x in baseline['rows']) if baseline else None,'processes':len(values),'range_min_ms':min(float(v['median_ms']) for v in values),'range_max_ms':max(float(v['median_ms']) for v in values),'native_results':str(folder),'unity_results':baseline['folder'] if baseline else None,'caveat':caveat})
  if case.startswith('ai-navmesh'):
   for rep in range(len(values)):assert int(checks[(case,n,rep)]['nav_polygons'])>0
  if baseline:
   files=['unity/Assets/EngineBenchmark.cs']
   if case.startswith('ai-nav') or 'skinning' in case:files.append('unity/Assets/FeatureWorkloads.cs')
   for name in files:
    old=baseline['source_hashes'].get(name);current=hashlib.sha256((B/name).read_bytes()).hexdigest() if (B/name).exists() else None
    definitions.append({'case':case,'count':n,'file':name,'saved_sha256':old,'current_sha256':current,'identical':old==current if old else None})
with (O/'comparison.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(O/'definition-checks.json').write_text(json.dumps(definitions,indent=2)+'\n')
def get(case,n=1000,w=1280,h=720):return next(x for x in rows if x['case']==case and x['count']==n and x['width']==w and x['height']==h)
def fmt(x):return '—' if x is None else f'{x:.4f}'
def ratio(x):return '—' if x is None else f'{x:.2f}×'
nav=get('ai-navmesh-path',100);grid=get('ai-nav-path',100)
supp=list(csv.DictReader((O/'supplemental.csv').open()));sgrp={}
for x in supp:sgrp.setdefault((x['case'],int(x['count']),x['backend']),[]).append(float(x['median_ms']))
sm=lambda c,n,b:st.median(sgrp[(c,n,b)])
suppmanifest=json.loads((O/'supplemental-manifest.json').read_text());assert len(suppmanifest)==30 and all(x['exit']==0 for x in suppmanifest)
for x in suppmanifest:
 if x['name'].startswith('nav-dynamic') and '--navmesh' in x['args']:assert x['checks']['tiles']=='144' and x['checks']['rebuilt_tiles']=='4'
matched=sum(r['unity_ms'] is not None for r in rows)
lines=['# Rebuilt Tessera versus saved Unity baselines','','Completed '+M['finished']+'. **Unity was not rebuilt or executed**, as requested. All current measurements use a fixed engine/native-archive snapshot so concurrent edits in the shared workspace cannot mix implementations between runs. Benchmark inputs/settings are retained; serial NavMesh uses the existing maze/endpoints of the Unity path workload.','','## Main results','','Milliseconds per listed batch/frame/tick; lower is better. The ratio is Tessera / saved Unity: above 1 takes longer, below 1 takes less time. These are workload comparisons, with the limits below, rather than an overall engine score.','','| Workload | Population / batch | Rebuilt Tessera ms | Saved Unity ms | Tessera / Unity |','|---|---:|---:|---:|---:|']
selected=[('ai-navmesh-path',100),('physics-free',1000),('physics-pile',1000),('physics-raycast',1000),('physics-overlap-sphere',1000),('physics-overlap-capsule',1000),('physics-overlap-box',1000),('render-shared',1000),('render-materials',1000),('render-culling',10000),('render-skinning-cpu',100),('render-skinning-gpu',100),('animator-clips',1000),('animator-layered',1000),('audio-mix',100),('asset-image-decode',100)]
for case,n in selected:
 r=get(case,n);label='Fresh serial NavMesh paths' if case=='ai-navmesh-path' else case
 lines.append(f'| {label} | {n} | {fmt(r["tessera_ms"])} | {fmt(r["unity_ms"])} | {ratio(r["ratio"])} |')
lines+=['',f'Fresh serial walking navigation takes **{nav["ratio"]:.2f}× the saved Unity timing** ({(nav["ratio"]-1)*100:.1f}% more time), versus {grid["ratio"]:.2f}× for the explicit grid control. That is {grid["tessera_ms"]/nav["tessera_ms"]:.2f}× less time than the grid in this maze. The final previous NavMesh measurement was 0.183590 ms / 100; this rerun is {nav["tessera_ms"]:.6f} ms. It does not restore the initial prototype’s 0.127 ms claim.','','## Navigation throughput and updates','','| Mode | Requests | Tessera ms | Saved Unity ms |','|---|---:|---:|---:|']
for case in ['ai-navmesh-path','ai-navmesh-path-batch']:
 for n in [1,10,100,1000]:
  r=get(case,n);lines.append(f'| {"Serial" if case=="ai-navmesh-path" else "CPU batch"} | {n} | {r["tessera_ms"]:.6f} | {fmt(r["unity_ms"])} |')
lines+=['','There is no matching Unity parallel dataset; batch timings are not assigned a cross-engine ratio. Every NavMesh request searches afresh. The historical grid path harness explicitly disables its route cache. All paths must succeed; serial and batched checks retain path-point counts and lengths, which can differ from Unity’s polygon output.','','Supplemental cases retain the previous 40 warmup / 120 samples, three processes each. They have no Unity comparison:','','| Workload | Count | Grid ms | NavMesh ms |','|---|---:|---:|---:|']
for c,n in [('nav-dynamic',1),('nav-dynamic',100),('nav-crowd',100),('nav-crowd',1000),('nav-crowd',2000)]:lines.append(f'| {c} | {n} | {sm(c,n,"grid"):.6f} | {sm(c,n,"navmesh"):.6f} |')
lines+=['','The moving-carve case rebuilds **4 of 144 tiles** per measured move on a 128 m floor, then finds the specified paths. The grid can reuse repeated routes within an iteration; the mesh does not use that route cache. Crowd timing measures moving agents/local avoidance without rigidbody simulation or rendering. It is not a whole-game frame. Carving remains synchronous, and the grid remains faster in this stress case.','','## Full measured inventory','','The table includes all rerun workload/population combinations. Physics query rows are batches of 1,000 queries against N bodies; simulation rows are per tick. Rendering uses whole-frame intervals. N is characters for skinning/animation, voices for audio, and image decodes for image loading. Baking N=1 means one bake per iteration. Dashes mean no equivalent saved baseline or an intentionally unranked comparison.','']
for group in dict.fromkeys(r['group'] for r in rows):
 lines+=['### '+group,'','| Workload | N | Dimensions | Tessera median ms | Unity median ms | Ratio | Tessera p95 ms | Native process-median range ms |','|---|---:|---|---:|---:|---:|---:|---:|']
 for r in rows:
  if r['group']!=group:continue
  dimensions=f'{r["width"]}×{r["height"]}'+(' fullscreen' if r['fullscreen'] else '') if r['case'].startswith('render-') else '—'
  lines.append(f'| {r["case"]} | {r["count"]} | {dimensions} | {fmt(r["tessera_ms"])} | {fmt(r["unity_ms"])} | {ratio(r["ratio"])} | {fmt(r["tessera_p95_ms"])} | {r["range_min_ms"]:.4f}–{r["range_max_ms"]:.4f} |')
 lines+=['']
lines+=['## Comparability and provenance','','- Unity inputs are the newest complete saved sets for the exact scenario, population, resolution and fullscreen setting. Warmup/sample counts match every paired row. Unity is 6000.3.27f1 nondevelopment Mono standalone; CPU/GPU skinning remain separate baseline builds. The original saved environment/source/binary hashes, where recorded, are frozen in unity-baselines.json. Repetition counts may differ (five current navigation processes versus three saved Unity processes); table values always use the median of process medians.','- Core runs use 120 warmup / 300 samples, three processes. Navigation uses five processes at those same sample counts. Baking uses 10 / 100 and audio/image uses 30 / 100 to match their saved datasets. No profiler recording or screenshots are enabled. Native archives are Release -O3; Beef Release uses GNU linking with ThinLTO unavailable.','- All binaries were rebuilt from snapshot/Engine and the captured native archive. The shared workspace was undergoing navigation API refactoring. Four snapshot-only call sites were adapted from struct arguments to the captured parameter API, preserving the same field values/flags. See snapshot-adapters.patch. Those adaptations did not change live engine files or workload geometry/settings. This measures the captured build, not edits made after the snapshot.','- Whole-file source hashes are recorded in definition-checks.json; differences include added unrelated workloads and do not prove equivalent definitions by themselves. The relevant branch audit is documented in workload-audit.md. Historical render-spheres timings are retained for reference but their ratios are excluded because sphere winding/normals changed. NavMesh serial/bake scenario aliases map to Unity’s existing ai-nav-path/ai-nav-bake definitions. Representation, contour construction and native bake integration differ even with matching geometry/agent inputs.','- Rendering pipelines and image quality differ, so lower whole-frame intervals are not an equal-image-quality engine ranking. Rendering includes synchronization/pacing rather than isolated GPU timestamps. Render-physics advances differing simulated time per rendered frame; its ratio is omitted. Character motor behavior and empty/script scene traversal differ; those ratios are omitted as well.','- Overlap contact detail differs: Tessera collects contacts, Unity returns colliders through NonAlloc APIs. Sphere/capsule/box sweep and ray settings retain their existing workload definitions. Native solver capacity logs were checked and no invalid overflow measurements were accepted. Solver defaults/quality still differ.','- Frozen Unity results were measured earlier. Scheduling, desktop/GPU load, temperature and clocks were not controlled across sessions. Current processes ran sequentially, were not CPU-pinned, and kept desktop applications open. Ranges show process variation, not confidence intervals. No universal engine score is calculated.','','## Completion and artifacts','',f'**{total} primary processes across {len(rows)} workload/population/settings cases, plus {len(suppmanifest)} supplemental processes, completed successfully.** {matched} cases have saved Unity timings. All ten job groups have zero failed runs. The positive NavMesh polygon count, path successes, ray hits, nonfinite-body checks and framebuffer checks confirm the timed work ran. Previous game/engine regression results are separate from this performance-only rerun.','','- [Comparison CSV](comparison.csv), [job manifest](manifest.json), [build hashes](builds.json), [frozen Unity inputs](unity-baselines.json), [definition checks](definition-checks.json), [workload audit](workload-audit.md).','- [Supplemental data](supplemental.csv), [supplemental commands/checks](supplemental-manifest.json), [runner](run_all.py), [source hashes](snapshot-sha256.json), [snapshot adapters](snapshot-adapters.patch).','- Every job links its raw samples, checks, environment and logs below. Archived logs from the initial build attempts are not treated as measurements. No Unity process, user game scene, or shipping build was changed for this rerun.','']
for job in M['jobs']:
 f=Path(job['results']);lines.append(f'- {job["name"]}: [report]({f}/report.md), [samples]({f}/samples.csv), [checks]({f}/checks.csv), [environment]({f}/environment.json).')
lines+=['']
(O/'REPORT.md').write_text('\n'.join(lines))
p=Path('/home/zerker24/Desktop/Tessera Benchmark Results.md');s=p.read_text();start='<!-- final-comparison-20261028:start -->';end='<!-- final-comparison-20261028:end -->'
if start in s:s=s.split(end,1)[1].lstrip()
intro=[start,'# Rebuilt Tessera comparison — 28 October 2026','',f'{total+len(suppmanifest)} processes completed with no failed measurements. Tessera rebuilt from a fixed snapshot; saved Unity workloads/settings reused, Unity not rerun.','',f'100 fresh serial NavMesh paths: {nav["tessera_ms"]:.6f} ms vs saved Unity {nav["unity_ms"]:.6f} ms ({nav["ratio"]:.2f}×). CPU batch 100: {get("ai-navmesh-path-batch",100)["tessera_ms"]:.6f} ms; 1000: {get("ai-navmesh-path-batch",1000)["tessera_ms"]:.6f} ms. No equivalent Unity parallel baseline.','', '| Workload (N=1000) | Tessera ms | Saved Unity ms | Ratio |','|---|---:|---:|---:|']
for c in ['physics-free','physics-pile','physics-overlap-sphere','physics-overlap-capsule','physics-overlap-box','render-shared','render-materials']:
 r=get(c);intro.append(f'| {c} | {fmt(r["tessera_ms"])} | {fmt(r["unity_ms"])} | {ratio(r["ratio"])} |')
intro+=['',f'Full report, complete inventory, raw data and comparability limits: {O}/REPORT.md',end,'','']
p.write_text('\n'.join(intro)+s)
(B/'LATEST_COMPARISON.md').write_text(f'# Latest benchmark comparison\n\n[{O.name}/REPORT.md]({O}/REPORT.md)\n\nCurrent Tessera snapshot rerun against matching saved Unity baselines; Unity was not executed. Includes default walking NavMesh, explicit grid controls, batched paths, physics, rendering, skinning, animation, audio/image, crowds and tiled updates. Older COMPARISON.md and confirmation reports are historical.\n')
print('primary processes',total,'cases',len(rows),'paired',matched,'supplemental',len(suppmanifest))
for case,n in selected:
 r=get(case,n);print(case,n,fmt(r['tessera_ms']),fmt(r['unity_ms']),ratio(r['ratio']))
print('Definition hash changes:',sum(x['identical'] is False for x in definitions),'missing:',sum(x['identical'] is None for x in definitions))
