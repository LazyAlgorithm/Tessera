#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler,HTTPServer
class Handler(BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def do_GET(self):
  body=b'X'*1024
  self.send_response(200);self.send_header('Content-Type','text/plain');self.send_header('Content-Length',str(len(body)));self.send_header('Connection','close');self.end_headers();self.wfile.write(body)
 def log_message(self,*args):pass
class BenchServer(HTTPServer):allow_reuse_address=True
BenchServer(('127.0.0.1',39439),Handler).serve_forever()
