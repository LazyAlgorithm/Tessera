using System;
using System.Collections;
using System.IO;

namespace Tessera;

/// Chunk-addressable surface grid, or a volume grid for flying agents.
/// Positions are agent feet for walking, and centers for flying.
class NavigationData
{
	static ProfilerMarker sRegionsProfile = .("Navigation.Regions", .AI);
	static ProfilerMarker sNodesProfile = .("Navigation.Nodes", .AI);
	static ProfilerMarker sNearestProfile = .("Navigation.Nearest", .AI);
	static ProfilerMarker sSearchProfile = .("Navigation.Search", .AI);
	static ProfilerMarker sCorridorProfile = .("Navigation.Corridor", .AI);
	static ProfilerMarker sLineClearProfile = .("Navigation.LineClear", .AI);
	static ProfilerMarker sSmoothProfile = .("Navigation.Smooth", .AI);

	public struct Cell { public bool walkable; public Vector3 position; public uint32 links; }
	/// Link directions: 0-5 are the axes, 6-9 the horizontal diagonals, 10-25 every offset that also moves up or down.
	public const int32 DirectionCount = 26;
	public Vector3 origin;
	public float cellSize = 1, agentRadius = 0.3f, agentHeight = 1.8f, maxStep = 0.5f, maxSlope = 45;
	public int32 width = 32, height = 1, depth = 32, chunkSize = 16;
	public bool flying;
	/// Unique across every NavigationData, so an agent notices a rebake that replaced the object as well as an in-place rebuild.
	public int32 Revision;
	static int32 sRevisions;
	public void Touch()
	{
		Revision = ++sRevisions;
	}

	/// True when the last FindPath stopped at its visit budget instead of proving the goal unreachable.
	public bool BudgetExceeded;
	/// How many nodes (or cells, with useNodes off) the last FindPath took from its open list (for profiling).
	public int32 LastVisited;
	/// A search's scratch, kept between searches (a stamp marks the entries the current search has written). FindPath
	/// uses the grid's own; searches running at the same time (FindPaths) each have one.
	public class Search
	{
		public List<float> cost = new .() ~ delete _;
		public List<int32> parent = new .() ~ delete _;
		public List<int32> parentLink = new .() ~ delete _;
		public List<int32> seen = new .() ~ delete _;
		public List<int32> closed = new .() ~ delete _;
		/// For the node search (NavigationNodes.bf): each node's cost plus estimate, and the cells it was entered by and
		/// its parent left by.
		public List<float> score = new .() ~ delete _;
		public List<int32> entry = new .() ~ delete _;
		public List<int32> exit = new .() ~ delete _;
		List<HeapItem> open = new .() ~ delete _;
		/// For the node search: the nodes one step made cheaper.
		List<int32> touched = new .() ~ delete _;
		public int32 stamp;
		/// True when the last search stopped at its visit budget instead of proving the goal unreachable.
		public bool budgetExceeded;
		/// How many cells the last search took from its open list.
		public int32 visited;
	}

	Search mSearch = new .() ~ delete _;
	List<Search> mThreadSearches = new .() ~ DeleteContainerAndItems!(_);
	// Connected-region label per cell, rebuilt lazily after the grid changes.
	List<int32> mRegions = new .() ~ delete _;
	int32 mRegionRevision = -1;
	public List<Cell> cells = new .() ~ delete _;

	/// A way across that the grid does not have (a jump, a ladder, a teleporter): from one cell to another, at a
	/// cost. Set from Navigation Link components by the surface; not saved with the grid.
	public struct Link
	{
		public int32 from, to;
		public float cost;
		public bool twoWay;
		/// Which link it is, for the agent crossing it (the surface's index of its Navigation Link).
		public int32 id;
	}

	public List<Link> links = new .() ~ delete _;
	// Cell -> the links that start (or, two-way, end) there, rebuilt with SetLinks.
	Dictionary<int32, List<int32>> mLinksAt = new .() ~ DeleteDictionaryAndValues!(_);
	// Runtime overlays, not saved: how many obstacles block each cell, and each cell's cost multiplier (areas).
	// Empty until something uses them.
	List<uint16> mBlocked = new .() ~ delete _;
	List<float> mCostScale = new .() ~ delete _;

	/// A cell an agent may use now: walkable in the bake and not blocked by an obstacle.
	public bool Usable(int32 index) => index >= 0 && index < cells.Count && cells[index].walkable && (mBlocked.Count != cells.Count || mBlocked[index] == 0);
	public bool Blocked(int32 index) => mBlocked.Count == cells.Count && index >= 0 && index < cells.Count && mBlocked[index] > 0;
	/// How much more a step into a cell costs than its length (1 normally; more in a costly area).
	public float CostScale(int32 index) => mCostScale.Count == cells.Count && index >= 0 && index < cells.Count ? mCostScale[index] : 1;

	/// Forgets every obstacle and area (before the surface marks them again).
	public void ClearOverlay()
	{
		mBlocked.Clear();
		mCostScale.Clear();
		// The quadtree (NavigationNodes.bf) rebuilds what changed when the revision moves.
		Touch();
	}

	/// The cells whose floor (or centre, flying) lies inside a box, turned by a rotation about its centre, with the
	/// agent's radius added around it. Calls the function with each one's index.
	public void CellsInBox(Vector3 center, Quaternion rotation, Vector3 halfExtents, bool cylinder, delegate void(int32) each)
	{
		if (cells.Count != width * height * depth)
			return;
		let grow = agentRadius;
		let inverse = rotation.Normalized.Conjugate;
		// The box's reach in the world, to know which cells to look at.
		var reach = Vector3.Zero;
		for (int corner < 8)
		{
			let local = Vector3((corner & 1) != 0 ? halfExtents.x : -halfExtents.x, (corner & 2) != 0 ? halfExtents.y : -halfExtents.y, (corner & 4) != 0 ? halfExtents.z : -halfExtents.z);
			let world = rotation * local;
			reach = .(Math.Max(reach.x, Math.Abs(world.x)), Math.Max(reach.y, Math.Abs(world.y)), Math.Max(reach.z, Math.Abs(world.z)));
		}
		reach += .(grow, grow, grow);
		// Nothing to do for a box wholly outside the grid.
		let extent = Vector3(width * cellSize, flying ? height * cellSize : float.MaxValue, depth * cellSize);
		if (center.x + reach.x < origin.x || center.x - reach.x > origin.x + extent.x || center.z + reach.z < origin.z || center.z - reach.z > origin.z + extent.z)
			return;
		if (flying && (center.y + reach.y < origin.y || center.y - reach.y > origin.y + extent.y))
			return;
		int32 Bound(float p, int32 limit) => (int32)Mathf.Clamp(Math.Floor(p / cellSize), 0, limit - 1);
		let x0 = Bound(center.x - reach.x - origin.x, width);
		let x1 = Bound(center.x + reach.x - origin.x, width);
		let z0 = Bound(center.z - reach.z - origin.z, depth);
		let z1 = Bound(center.z + reach.z - origin.z, depth);
		let y0 = flying ? Bound(center.y - reach.y - origin.y, height) : 0;
		let y1 = flying ? Bound(center.y + reach.y - origin.y, height) : 0;
		// Walking: an agent standing on the cell is in the box when its body (feet to head) overlaps it.
		let headroom = flying ? 0 : agentHeight;
		for (int32 y = y0; y <= y1; y++)
		{
			for (int32 z = z0; z <= z1; z++)
			{
				for (int32 x = x0; x <= x1; x++)
				{
					let index = Index(x, y, z);
					if (!cells[index].walkable)
						continue;
					let local = inverse * (cells[index].position - center);
					if (flying)
					{
						if (Math.Abs(local.y) > halfExtents.y + grow)
							continue;
					}
					// Walking: the agent standing there (feet up to head) overlaps the box.
					else if (local.y > halfExtents.y || local.y + headroom < -halfExtents.y)
						continue;
					if (cylinder)
					{
						if (local.x * local.x + local.z * local.z > (halfExtents.x + grow) * (halfExtents.x + grow))
							continue;
					}
					else if (Math.Abs(local.x) > halfExtents.x + grow || Math.Abs(local.z) > halfExtents.z + grow)
						continue;
					each(index);
				}
			}
		}
	}

	/// Blocks the cells an obstacle covers (Navigation Obstacle with Carve). Undone by ClearOverlay.
	public void Block(Vector3 center, Quaternion rotation, Vector3 halfExtents, bool cylinder)
	{
		if (mBlocked.Count != cells.Count)
		{
			mBlocked.Clear();
			mBlocked.Resize(cells.Count);
		}
		CellsInBox(center, rotation, halfExtents, cylinder, scope [&] (index) =>
			{
				if (mBlocked[index] < uint16.MaxValue)
					mBlocked[index]++;
			});
		Touch();
	}

	/// Makes the cells in a box cost more to cross (a Navigation Area): agents go round unless the way round is
	/// longer than the extra. The highest multiplier of the areas over a cell counts.
	public void SetCost(Vector3 center, Quaternion rotation, Vector3 halfExtents, float multiplier)
	{
		if (mCostScale.Count != cells.Count)
		{
			mCostScale.Clear();
			mCostScale.Resize(cells.Count);
			for (int i < mCostScale.Count)
				mCostScale[i] = 1;
		}
		let scale = Math.Clamp(multiplier, 1, 1000);
		// Areas mark where agents stand, not their whole body.
		let radius = agentRadius;
		agentRadius = 0;
		CellsInBox(center, rotation, halfExtents, false, scope [&] (index) =>
			{
				mCostScale[index] = Math.Max(mCostScale[index], scale);
			});
		agentRadius = radius;
		Touch();
	}

	/// Sets the off-grid links (replacing those before). Their ends are cell indices.
	public void SetLinks(Span<Link> newLinks)
	{
		links.Clear();
		for (let link in newLinks)
		{
			if (link.from >= 0 && link.to >= 0 && link.from < cells.Count && link.to < cells.Count && link.from != link.to && link.cost.IsFinite)
				links.Add(link);
		}
		for (let (key, value) in mLinksAt)
			delete value;
		mLinksAt.Clear();
		for (int32 i < (int32)links.Count)
		{
			void At(int32 cell, int32 link)
			{
				List<int32> list;
				if (!mLinksAt.TryGetValue(cell, out list))
				{
					list = new .();
					mLinksAt[cell] = list;
				}
				list.Add(link);
			}
			At(links[i].from, i);
			if (links[i].twoWay)
				At(links[i].to, i);
		}
		// Regions are joined across links, and nodes list where links start.
		mRegionRevision = -1;
		Touch();
	}

	/// The cell a point is in (walking: the column it stands over), or -1 outside the grid.
	public int32 CellAt(Vector3 point)
	{
		let x = (int32)Math.Floor((point.x - origin.x) / cellSize);
		let z = (int32)Math.Floor((point.z - origin.z) / cellSize);
		let y = flying ? (int32)Math.Floor((point.y - origin.y) / cellSize) : 0;
		return Inside(x, y, z) ? Index(x, y, z) : -1;
	}

	/// Each direction's step on each axis, and the direction of each step ((dx + 1) + (dy + 1) * 3 + (dz + 1) * 9), worked
	/// out once: searches look them up for every cell instead of working them out.
	static int32[DirectionCount] sStepX, sStepY, sStepZ;
	static int32[27] sDirectionOf;

	static this()
	{
		for (int i < 27)
			sDirectionOf[i] = -1;
		for (int32 direction < DirectionCount)
		{
			Offset(direction, let x, let y, let z);
			sStepX[direction] = x;
			sStepY[direction] = y;
			sStepZ[direction] = z;
			sDirectionOf[(x + 1) + (y + 1) * 3 + (z + 1) * 9] = direction;
		}
	}

	/// The link direction for a step of (-1..1) cells on each axis, or -1.
	public static int32 DirectionOf(int32 dx, int32 dy, int32 dz)
	{
		if (dx < -1 || dx > 1 || dy < -1 || dy > 1 || dz < -1 || dz > 1)
			return -1;
		return sDirectionOf[(dx + 1) + (dy + 1) * 3 + (dz + 1) * 9];
	}

	/// The directions a search may step in, as bits.
	uint32 UsedDirections => flying ? (1u << DirectionCount) - 1 : 0x3CFu;

	/// True when an agent can go straight from a to b: every cell the line crosses is usable and linked to the one
	/// before it (so the agent's shape fits all the way), and, walking, the floor stays close to the line's height.
	/// The point where the line stops is `reached`.
	public bool LineClear(Vector3 a, Vector3 b, out Vector3 reached)
	{
		using (sLineClearProfile.Sample())
		{
			if (!flying) return WalkingLineClear(a, b, out reached);
			reached = a;
			var previous = CellAt(a);
			if (!Usable(previous))
				return false;
			int32 lastSquare = -1;
			var delta = b - a;
			if (!flying)
				delta.y = 0;
			let length = delta.Length;
			let steps = (int)Math.Ceiling(length / (cellSize * 0.25f));
			let tolerance = Math.Max(maxStep * 0.6f, cellSize * 0.2f);
			for (int s = 1; s <= steps; s++)
			{
				let t = (float)s / steps;
				let point = Vector3.Lerp(a, b, t);
				// Between cell centres the line can pass nearer a wall than any centre does: it must lie among usable
				// cells that are all linked to each other, whose swept links cover the space between them.
				if (!Among(point, ref lastSquare))
					return false;
				let cell = CellAt(point);
				if (cell == previous)
					continue;
				if (!Usable(cell))
					return false;
				let px = previous % width, pz = (previous / width) % depth, py = previous / (width * depth);
				let cx = cell % width, cz = (cell / width) % depth, cy = cell / (width * depth);
				let dx = cx - px, dy = cy - py, dz = cz - pz;
				if (Math.Abs(dx) > 1 || Math.Abs(dy) > 1 || Math.Abs(dz) > 1)
					return false;
				let direction = DirectionOf(dx, dy, dz);
				if (direction < 0 || !Uses(direction) || (cells[previous].links & (1u << direction)) == 0)
					return false;
				// A long straight leg over a hill would cut through it (or float over a dip).
				if (!flying && Math.Abs(cells[cell].position.y - point.y) > tolerance)
					return false;
				reached = point;
				previous = cell;
			}
			reached = b;
			return true;

		}
	}

	/// Visit intervals bounded by cell edges AND centre lines. CellAt and Among are constant inside each interval,
	/// so one clearance check covers it; no fixed-distance oversampling or skipped thin corner intervals.
	bool WalkingLineClear(Vector3 a, Vector3 b, out Vector3 reached)
	{
		reached = a;
		if (!a.x.IsFinite || !a.y.IsFinite || !a.z.IsFinite || !b.x.IsFinite || !b.y.IsFinite || !b.z.IsFinite) return false;
		var previous = CellAt(a);
		if (!Usable(previous)) return false;
		let delta = b - a;
		if (!delta.x.IsFinite || !delta.y.IsFinite || !delta.z.IsFinite) return false;
		let spacing = (double)cellSize * 0.5;
		double Next(float start, float movement, float minimum)
		{
			if (movement == 0) return double.MaxValue;
			let coordinate = ((double)start - minimum) / spacing;
			let plane = movement > 0 ? Math.Floor(coordinate) + 1 : Math.Ceiling(coordinate) - 1;
			return (plane * spacing + minimum - start) / movement;
		}
		var tx = Next(a.x, delta.x, origin.x), tz = Next(a.z, delta.z, origin.z);
		let stepX = delta.x == 0 ? double.MaxValue : spacing / Math.Abs((double)delta.x);
		let stepZ = delta.z == 0 ? double.MaxValue : spacing / Math.Abs((double)delta.z);
		int32 lastSquare = -1;
		double t = 0;
		let tolerance = Math.Max(maxStep * 0.6f, cellSize * 0.2f);
		while (t < 1)
		{
			let end = Math.Min(1.0, Math.Min(tx, tz));
			let middle = (t + end) * 0.5;
			let point = Vector3.Lerp(a, b, (float)middle);
			let x = a.x + (double)delta.x * middle, z = a.z + (double)delta.z * middle;
			if (!WalkingAmong(x, z, delta.x != 0, delta.z != 0, ref lastSquare)) return false;
			let cx = (int32)Math.Floor((x - origin.x) / cellSize), cz = (int32)Math.Floor((z - origin.z) / cellSize);
			let cell = Inside(cx, 0, cz) ? Index(cx, 0, cz) : -1;
			if (!Usable(cell)) return false;
			if (cell != previous)
			{
				let dx = cell % width - previous % width;
				let dz = cell / width - previous / width;
				let direction = DirectionOf(dx, 0, dz);
				if (direction < 0 || !Uses(direction) || (cells[previous].links & (1u << direction)) == 0)
					return false;
			}
			// Height varies linearly within a cell, so the interval's ends bound its full deviation from the floor.
			let floor = cells[cell].position.y;
			if (Math.Abs(floor - (a.y + delta.y * (float)t)) > tolerance || Math.Abs(floor - (a.y + delta.y * (float)end)) > tolerance)
				return false;
			previous = cell;
			reached = point;
			t = end;
			if (tx <= end) tx += stepX;
			if (tz <= end) tz += stepZ;
		}
		// An endpoint on an edge belongs to a definite cell, even when the preceding open interval did not.
		let goal = CellAt(b);
		if (!Usable(goal) || Math.Abs(cells[goal].position.y - b.y) > tolerance || !Among(b, ref lastSquare)) return false;
		if (goal != previous)
		{
			let direction = DirectionOf(goal % width - previous % width, 0, goal / width - previous / width);
			if (direction < 0 || (cells[previous].links & (1u << direction)) == 0) return false;
		}
		reached = b;
		return true;
	}

	bool WalkingSquare(int32 bx, int32 bz, int32 spanX, int32 spanZ)
	{
		// Walking has at most four corners and six pairs. Avoid building generic 3D corner arrays and
		// looking up directions for every pair during every smoothing line check.
		let a = Index(bx, 0, bz), b = a + 1, c = a + width, d = c + 1;
		bool Linked(int32 first, int32 second, int32 direction, int32 reverse) =>
			(cells[first].links & (1u << direction)) != 0 || (cells[second].links & (1u << reverse)) != 0;
		if (!Usable(a)) return false;
		if (spanX == 2 && (!Usable(b) || !Linked(a, b, 0, 1))) return false;
		if (spanZ == 2 && (!Usable(c) || !Linked(a, c, 2, 3))) return false;
		if (spanX == 2 && spanZ == 2 && (!Usable(d) || !Linked(b, d, 2, 3) || !Linked(c, d, 0, 1) || !Linked(a, d, 6, 9) || !Linked(b, c, 8, 7))) return false;
		return true;
	}

	bool WalkingAmong(double x, double z, bool movingX, bool movingZ, ref int32 last)
	{
		void Span(double along, bool moving, out int32 first, out int32 span)
		{
			let f = along / cellSize - 0.5;
			first = (int32)Math.Floor(f);
			let part = f - first;
			span = 2;
			// A stationary axis on a centre line stays in its row. A moving axis must cover the whole
			// interval, even if its midpoint is extremely close to that line.
			if (!moving && part < 0.001) span = 1;
			else if (!moving && part > 0.999) { first++; span = 1; }
		}
		Span(x - origin.x, movingX, let bx, let spanX);
		Span(z - origin.z, movingZ, let bz, let spanZ);
		if (!Inside(bx, 0, bz) || !Inside(bx + spanX - 1, 0, bz + spanZ - 1)) return true;
		let square = Index(bx, 0, bz) * 8 + (spanX - 1) + (spanZ - 1) * 2;
		if (square == last) return true;
		last = square;
		return WalkingSquare(bx, bz, spanX, spanZ);
	}

	/// Whether a point lies in a square (flying: a cube) of usable cells whose centres surround it, each linked to the
	/// others along the square's sides and across it. `last` skips a square already checked.
	bool Among(Vector3 point, ref int32 last)
	{
		// The cells whose centres surround the point on each axis: two, or one when the point lies on their row (a
		// line along the last row of cells beside a wall stays among that row, not the wall's).
		void Span(float along, out int32 first, out int32 span)
		{
			let f = along / cellSize - 0.5f;
			first = (int32)Math.Floor(f);
			let part = f - first;
			span = 2;
			if (part < 0.001f)
				span = 1;
			else if (part > 0.999f)
			{
				first++;
				span = 1;
			}
		}
		Span(point.x - origin.x, var bx, var spanX);
		Span(point.z - origin.z, var bz, var spanZ);
		int32 by = 0, layers = 1;
		if (flying)
			Span(point.y - origin.y, out by, out layers);
		// At the grid's edge there is no full square; the cell itself is checked by the caller.
		if (!Inside(bx, by, bz) || !Inside(bx + spanX - 1, by + layers - 1, bz + spanZ - 1))
			return true;
		let square = Index(bx, by, bz) * 8 + (spanX - 1) + (spanZ - 1) * 2 + (layers - 1) * 4;
		if (square == last)
			return true;
		last = square;
		if (!flying) return WalkingSquare(bx, bz, spanX, spanZ);

		int32[8] corners = default;
		int32[8] cornerX = default, cornerY = default, cornerZ = default;
		int count = 0;
		for (int32 y < layers)
		{
			for (int32 z < spanZ)
			{
				for (int32 x < spanX)
				{
					let index = Index(bx + x, by + y, bz + z);
					if (!Usable(index))
						return false;
					cornerX[count] = x;
					cornerY[count] = y;
					cornerZ[count] = z;
					corners[count++] = index;
				}
			}
		}
		// Every pair of corners that are grid neighbours must be linked (one way is enough: links are symmetric).
		for (int i < count)
		{
			for (int j = i + 1; j < count; j++)
			{
				let a = corners[i], b = corners[j];
				let direction = DirectionOf(cornerX[j] - cornerX[i], cornerY[j] - cornerY[i], cornerZ[j] - cornerZ[i]);
				if (direction < 0 || !Uses(direction))
					continue;
				if ((cells[a].links & (1u << direction)) == 0 && (cells[b].links & (1u << Opposite(direction))) == 0)
					return false;
			}
		}
		return true;
	}

	/// Straightens a path of cell centres where the agent can go directly: each point is joined to the farthest one
	/// after it with a clear line. Points where a link starts or ends are kept (legLinks, from FindPath, says which
	/// legs are links; it is kept in step).
	public void Smooth(List<Vector3> path, List<int32> legLinks = null)
	{
		using (sSmoothProfile.Sample())
		{
			if (path.Count < 3)
				return;
			let points = scope List<Vector3>();
			let kept = scope List<int32>();
			points.Add(path[0]);
			kept.Add(-1);
			int i = 0;
			while (i < path.Count - 1)
			{
				// A link is crossed as it is.
				if (legLinks != null && legLinks[i] >= 0)
				{
					kept[kept.Count - 1] = legLinks[i];
					points.Add(path[i + 1]);
					kept.Add(-1);
					i++;
					continue;
				}
				// Not past the start of a link.
				var last = path.Count - 1;
				if (legLinks != null)
				{
					for (int j = i + 1; j < path.Count; j++)
					{
						if (legLinks[j - 1] >= 0)
						{
							last = j - 1;
							break;
						}
					}
				}
				// The farthest point in a clear line: longer and longer jumps until one is blocked, then halving the gap
				// (a few line checks per leg rather than one for every point along it).
				var best = i + 1;
				var step = 1;
				var blocked = last + 1;
				while (best < last)
				{
					let j = Math.Min(best + step, last);
					if (!LineClear(path[i], path[j], ?))
					{
						blocked = j;
						break;
					}
					best = j;
					step *= 2;
				}
				while (blocked - best > 1)
				{
					let j = (best + blocked) / 2;
					if (LineClear(path[i], path[j], ?))
						best = j;
					else
						blocked = j;
				}
				points.Add(path[best]);
				kept.Add(-1);
				i = best;
			}
			path.Clear();
			path.AddRange(points);
			if (legLinks != null)
			{
				legLinks.Clear();
				legLinks.AddRange(kept);
			}

		}
	}

	public int32 Index(int32 x, int32 y, int32 z) => x + width * (z + depth * y);
	public bool Inside(int32 x, int32 y, int32 z) => x >= 0 && x < width && y >= 0 && y < height && z >= 0 && z < depth;
	public Vector3 Center(int32 x, int32 y, int32 z) => origin + .((x + 0.5f) * cellSize, (y + 0.5f) * cellSize, (z + 0.5f) * cellSize);
	public static void Offset(int32 direction, out int32 x, out int32 y, out int32 z)
	{
		x = 0;
		y = 0;
		z = 0;
		switch (direction)
		{
		case 0:
			x = 1;
		case 1: x = -1;
		case 2: z = 1;
		case 3: z = -1;
		case 4: y = 1;
		case 5: y = -1;
		case 6,7,8,9:
			x = direction < 8 ? 1 : -1;
			z = (direction & 1) == 0 ? 1 : -1;
		default:
			// Eight horizontal offsets one layer up, then the same eight one layer down.
			let k = (direction - 10) % 8;
			Offset(k < 4 ? k : k + 2, out x, out y, out z);
			y = direction < 18 ? 1 : -1;
		}
	}

	public static int32 Opposite(int32 direction)
	{
		if (direction < 6) return direction ^ 1;
		if (direction < 10) return 15 - direction;
		let k = (direction - 10) % 8;
		return 10 + (direction < 18 ? 8 : 0) + (k < 4 ? k ^ 1 : 11 - k);
	}

	/// Walking surfaces link along X/Z only, diagonals included.
	public bool Uses(int32 direction) => flying || direction < 4 || (direction >= 6 && direction < 10);
	/// Shortest possible travel between two cells over this grid's link directions; never more than the real cost.
	float Estimate(int32 a, int32 b) => Estimate(a % width - b % width, a / (width * depth) - b / (width * depth), (a / width) % depth - (b / width) % depth);

	/// The same for a step of so many cells on each axis.
	float Estimate(int32 stepX, int32 stepY, int32 stepZ)
	{
		var dx = (float)Math.Abs(stepX);
		var dz = (float)Math.Abs(stepZ);
		var dy = (float)Math.Abs(stepY);
		if (dx < dy)
			Swap!(dx, dy);
		if (dx < dz)
			Swap!(dx, dz);
		if (dy < dz)
			Swap!(dy, dz);
		return (dx + 0.41421356f * dy + 0.31783725f * dz) * cellSize;
	}

	public int32 Neighbor(int32 index, int32 direction)
	{
		let x = index % width;
		let z = (index / width) % depth;
		let y = index / (width * depth);
		Offset(direction, let dx, let dy, let dz);
		return Inside(x + dx, y + dy, z + dz) ? Index(x + dx, y + dy, z + dz) : -1;
	}

	public bool Configure(Vector3 minimum, Vector3 size, float spacing, bool flight, int32 chunk, String error)
	{
		if (!minimum.x.IsFinite || !minimum.y.IsFinite || !minimum.z.IsFinite || !spacing.IsFinite || spacing < 0.05f || !size.x.IsFinite || !size.y.IsFinite || !size.z.IsFinite || size.x <= 0 || size.y <= 0 || size.z <= 0)
		{
			error.Set("Navigation size and cell spacing must be finite and positive.");
			return false;
		}
		let w = Math.Ceiling(size.x / spacing);
		let h = flight ? Math.Ceiling(size.y / spacing) : 1;
		let d = Math.Ceiling(size.z / spacing);
		if (w * h * d > 1000000 || w > 4096 || h > 4096 || d > 4096)
		{
			error.Set("Navigation grid exceeds one million cells. Increase cell size or reduce bounds.");
			return false;
		}
		origin = minimum;
		cellSize = spacing;
		flying = flight;
		chunkSize = Math.Max(chunk, 1);
		width = (int32)w;
		height = (int32)h;
		depth = (int32)d;
		cells.Clear();
		cells.Resize(width * height * depth);
		return true;
	}

	/// Closest usable cell within maxDistance. The cell the point is in wins when it is usable, so a point beside a thin
	/// wall is not moved across it. A region limits the answer to cells connected to that region.
	public int32 Nearest(Vector3 point, float maxDistance, int32 region = -1)
	{
		using (sNearestProfile.Sample())
		{
			if (!maxDistance.IsFinite || maxDistance < 0 || !point.x.IsFinite || !point.y.IsFinite || !point.z.IsFinite || cells.Count != width * height * depth) return -1;
			if (region >= 0)
				EnsureRegions();
			int32 best = -1;
			float distance = maxDistance * maxDistance;
			int32 Bound(float p, int32 limit) => (int32)Mathf.Clamp(Math.Floor(p / cellSize), 0, limit - 1);
			let cx = (int32)Math.Floor((point.x - origin.x) / cellSize);
			let cz = (int32)Math.Floor((point.z - origin.z) / cellSize);
			let cy = flying ? (int32)Math.Floor((point.y - origin.y) / cellSize) : 0;
			if (Inside(cx, cy, cz))
			{
				let i = Index(cx, cy, cz);
				if (Usable(i) && (region < 0 || mRegions[i] == region) && (cells[i].position - point).LengthSquared <= distance) return i;
			}
			let x0 = Bound(point.x - origin.x - maxDistance, width);
			let x1 = Bound(point.x - origin.x + maxDistance, width);
			let z0 = Bound(point.z - origin.z - maxDistance, depth);
			let z1 = Bound(point.z - origin.z + maxDistance, depth);
			let y0 = flying ? Bound(point.y - origin.y - maxDistance, height) : 0;
			let y1 = flying ? Bound(point.y - origin.y + maxDistance, height) : 0;
			for (int32 y = y0; y <= y1; y++)
			{
				for (int32 z = z0; z <= z1; z++)
				{
					for (int32 x = x0; x <= x1; x++)
					{
						let i = Index(x, y, z);
						if (!Usable(i) || (region >= 0 && mRegions[i] != region)) continue;
						let d = (cells[i].position - point).LengthSquared;
						if (d <= distance)
						{
							distance = d;
							best = i;
						}
					}
				}
			}
			return best;

		}
	}

	struct HeapItem
	{
		public int32 id;
		public float priority;
		public this(int32 id, float priority)
		{
			this.id = id;
			this.priority = priority;
		}
	}

	static void Push(List<HeapItem> heap, HeapItem item)
	{
		heap.Add(item);
		int index = heap.Count - 1;
		while (index > 0)
		{
			let parent = (index - 1) / 2;
			if (heap[parent].priority <= item.priority) break;
			heap[index] = heap[parent];
			index = parent;
		}
		heap[index] = item;
	}

	static HeapItem Pop(List<HeapItem> heap)
	{
		let result = heap[0];
		let tail = heap.Back;
		heap.RemoveAt(heap.Count - 1);
		if (heap.Count > 0)
		{
			int index = 0;
			while (index * 2 + 1 < heap.Count)
			{
				var child = index * 2 + 1;
				if (child + 1 < heap.Count && heap[child + 1].priority < heap[child].priority)
					child++;
				if (tail.priority <= heap[child].priority) break;
				heap[index] = heap[child];
				index = child;
			}
			heap[index] = tail;
		}
		return result;
	}

	/// Labels cells so two cells with different labels can never reach each other. Links are treated as two-way here, so
	/// equal labels do not promise a route; they only make the common unreachable case free.
	void EnsureRegions()
	{
		using (sRegionsProfile.Sample())
		{
			if (mRegionRevision == Revision && mRegions.Count == cells.Count) return;
			mRegions.Clear();
			mRegions.Resize(cells.Count);
			for (int i < cells.Count)
				mRegions[i] = -1;
			List<int32> stack = scope .();
			int32 next = 0;
			for (int32 seed = 0; seed < (int32)cells.Count; seed++)
			{
				if (!cells[seed].walkable || mRegions[seed] >= 0) continue;
				mRegions[seed] = next;
				stack.Add(seed);
				while (stack.Count > 0)
				{
					let id = stack.PopBack();
					for (int32 direction = 0; direction < DirectionCount; direction++)
					{
						if (!Uses(direction)) continue;
						let other = Neighbor(id, direction);
						if (other < 0 || !cells[other].walkable || mRegions[other] >= 0) continue;
						if ((cells[id].links & (1u << direction)) == 0 && (cells[other].links & (1u << Opposite(direction))) == 0) continue;
						mRegions[other] = next;
						stack.Add(other);
					}
				}
				next++;
			}
			// Links join the regions at their ends: relabel each to the smallest it is joined to.
			if (!links.IsEmpty)
			{
				let joined = scope List<int32>();
				for (int32 r < next)
					joined.Add(r);
				int32 Root(int32 r)
				{
					var at = r;
					while (joined[at] != at)
						at = joined[at];
					return at;
				}
				for (let link in links)
				{
					let a = mRegions[link.from], b = mRegions[link.to];
					if (a < 0 || b < 0)
						continue;
					let ra = Root(a), rb = Root(b);
					if (ra != rb)
						joined[Math.Max(ra, rb)] = Math.Min(ra, rb);
				}
				for (int i < mRegions.Count)
				{
					if (mRegions[i] >= 0)
						mRegions[i] = Root(mRegions[i]);
				}
			}
			mRegionRevision = Revision;

		}
	}

	public int32 Region(int32 cell)
	{
		EnsureRegions();
		return cell >= 0 && cell < mRegions.Count ? mRegions[cell] : -1;
	}

	/// A path from the cell nearest `from` to the cell nearest `to`: over the nodes, pulled straight through them (useNodes,
	/// on by default; NavigationNodes.bf), or else one point per cell. The goal snaps to a cell connected to the start
	/// when one is in range, and a goal in another region fails without searching. maxVisited counts nodes, or cells.
	public bool FindPath(Vector3 from, Vector3 to, List<Vector3> path, float snapDistance = 2, int32 maxVisited = 200000) => FindPath(from, to, path, null, snapDistance, maxVisited);

	/// FindPath that also says, for each leg (point i to i + 1), which link it crosses (its id), or -1 for a step
	/// across the grid.
	public bool FindPath(Vector3 from, Vector3 to, List<Vector3> path, List<int32> legLinks, float snapDistance = 2, int32 maxVisited = 200000)
	{
		EnsureRegions();
		EnsureNodes();
		let found = FindPath(from, to, path, legLinks, snapDistance, maxVisited, mSearch, true);
		BudgetExceeded = mSearch.budgetExceeded;
		LastVisited = mSearch.visited;
		return found;
	}

	/// FindPath without the links when withLinks is false (for an agent that may not use them).
	public bool FindPath(Vector3 from, Vector3 to, List<Vector3> path, List<int32> legLinks, float snapDistance, bool withLinks)
	{
		EnsureRegions();
		EnsureNodes();
		let found = FindPath(from, to, path, legLinks, snapDistance, 200000, mSearch, withLinks);
		BudgetExceeded = mSearch.budgetExceeded;
		LastVisited = mSearch.visited;
		return found;
	}

	/// FindPath with its own scratch, and without the links when withLinks is false. It only reads the grid, so
	/// searches with different scratch can run at the same time (FindPaths), once EnsureRegions has run.
	bool FindPath(Vector3 from, Vector3 to, List<Vector3> path, List<int32> legLinks, float snapDistance, int32 maxVisited, Search search, bool withLinks)
	{
		path.Clear();
		legLinks?.Clear();
		search.budgetExceeded = false;
		search.visited = 0;
		ProfilerModules.Paths.Add(1);
		defer
		{
			ProfilerModules.PathVisits.Add(search.visited);
		}
		if (cells.Count != width * height * depth) return false;
		let start = Nearest(from, snapDistance);
		if (start < 0) return false;
		let goal = Nearest(to, snapDistance, mRegions[start]);
		if (goal < 0) return false;
		if (search.seen.Count != cells.Count)
		{
			search.score.Clear();
			search.score.Resize(cells.Count);
			search.entry.Clear();
			search.entry.Resize(cells.Count);
			search.exit.Clear();
			search.exit.Resize(cells.Count);
			search.cost.Clear();
			search.cost.Resize(cells.Count);
			search.parent.Clear();
			search.parent.Resize(cells.Count);
			search.seen.Clear();
			search.seen.Resize(cells.Count);
			search.closed.Clear();
			search.closed.Resize(cells.Count);
			search.parentLink.Clear();
			search.parentLink.Resize(cells.Count);
			for (int i < cells.Count)
			{
				search.seen[i] = 0;
				search.closed[i] = 0;
			}
			search.stamp = 0;
		}
		// Nodes number no more than cells, so the same scratch serves.
		if (useNodes && mNodeOf.Count == cells.Count)
			return FindNodePath(start, goal, path, legLinks, maxVisited, search, withLinks);
		search.stamp++;
		search.[Friend]open.Clear();
		search.cost[start] = 0;
		search.parent[start] = -1;
		search.parentLink[start] = -1;
		search.seen[start] = search.stamp;
		Push(search.[Friend]open, .(start, 0));
		int visited = 0;
		// Straight at the lists' memory in the loop below, and the goal's place on the grid once.
		let cellData = cells.Ptr;
		let closed = search.closed.Ptr;
		let seen = search.seen.Ptr;
		let blocked = mBlocked.Count == cells.Count ? mBlocked.Ptr : null;
		let scale = mCostScale.Count == cells.Count ? mCostScale.Ptr : null;
		let used = UsedDirections;
		let gx = goal % width, gz = (goal / width) % depth, gy = goal / (width * depth);
		while (search.[Friend]open.Count > 0)
		{
			let id = Pop(search.[Friend]open).id;
			if (search.closed[id] == search.stamp) continue;
			if (visited >= maxVisited)
			{
				search.budgetExceeded = true;
				break;
			}
			search.closed[id] = search.stamp;
			visited++;
			search.visited = (int32)visited;
			if (id == goal)
			{
				var cursor = goal;
				while (cursor >= 0)
				{
					path.Add(cells[cursor].position);
					// The leg into this cell, read backwards: it is put the right way round below.
					if (legLinks != null && search.parent[cursor] >= 0)
						legLinks.Add(search.parentLink[cursor]);
					cursor = search.parent[cursor];
				}
				for (int i = 0; i < path.Count / 2; i++)
				{
					let p = path[i];
					path[i] = path[path.Count - 1 - i];
					path[path.Count - 1 - i] = p;
				}
				if (legLinks != null)
				{
					for (int i = 0; i < legLinks.Count / 2; i++)
						Swap!(legLinks[i], legLinks[legLinks.Count - 1 - i]);
					// One entry per point, so the last point (no leg after it) has -1.
					legLinks.Add(-1);
				}
				return true;
			}
			// The cell's place on the grid, worked out once (not for each neighbour), and only its linked directions.
			let x = id % width;
			let row = id / width;
			let z = row % depth;
			let y = row / depth;
			let position = cellData[id].position;
			let cost = search.cost[id];
			var directions = cellData[id].links & used;
			for (int32 direction = 0; directions != 0; direction++)
			{
				let bit = (uint32)1 << direction;
				if ((directions & bit) == 0) continue;
				directions &= ~bit;
				let nx = x + sStepX[direction], ny = y + sStepY[direction], nz = z + sStepZ[direction];
				if (nx < 0 || nx >= width || ny < 0 || ny >= height || nz < 0 || nz >= depth) continue;
				let next = nx + width * (nz + depth * ny);
				if (closed[next] == search.stamp || !cellData[next].walkable || (blocked != null && blocked[next] > 0)) continue;
				var g = (cellData[next].position - position).Length;
				if (scale != null)
					g *= scale[next];
				g += cost;
				if (seen[next] == search.stamp && g >= search.cost[next]) continue;
				search.cost[next] = g;
				search.parent[next] = id;
				search.parentLink[next] = -1;
				seen[next] = search.stamp;
				// The slight overweight breaks ties toward the goal, so open space is not flooded.
				Push(search.[Friend]open, .(next, g + Estimate(nx - gx, ny - gy, nz - gz) * 1.001f));
			}
			// Links from this cell.
			if (withLinks && mLinksAt.TryGetValue(id, let here))
			{
				for (let index in here)
				{
					let link = links[index];
					let next = link.from == id ? link.to : link.from;
					if (search.closed[next] == search.stamp || !Usable(next)) continue;
					let g = search.cost[id] + Math.Max(link.cost, 0.01f);
					if (search.seen[next] == search.stamp && g >= search.cost[next]) continue;
					search.cost[next] = g;
					search.parent[next] = id;
					search.parentLink[next] = link.id;
					search.seen[next] = search.stamp;
					Push(search.[Friend]open, .(next, g + Estimate(next, goal) * 1.001f));
				}
			}
		}
		return false;
	}

	/// One path request for FindPaths.
	public struct PathRequest
	{
		public Vector3 from, to;
		public List<Vector3> path;
		/// Optional: which link each leg crosses, as FindPath's.
		public List<int32> legLinks;
		public float snapDistance;
		public bool withLinks;
		public bool smooth;
		/// Set by FindPaths: whether a path was found.
		public bool found;
	}

	/// Finds many paths at once, spread over the job threads (Jobs), each with its own scratch: for many agents asking
	/// in one frame. Each request's lists are its own; the grid must not change while it runs.
	public void FindPaths(Span<PathRequest> requests, int32 maxVisited = 200000)
	{
		if (requests.Length == 0)
			return;
		EnsureRegions();
		EnsureNodes();
		let threads = Jobs.ThreadCount;
		while (mThreadSearches.Count < threads)
			mThreadSearches.Add(new .());
		Jobs.For(requests.Length, scope [&] (index) =>
			{
				ref PathRequest request = ref requests[index];
				let search = mThreadSearches[Jobs.ThreadIndex];
				request.found = FindPath(request.from, request.to, request.path, request.legLinks, request.snapDistance, maxVisited, search, request.withLinks);
				if (request.found && request.smooth)
					Smooth(request.path, request.legLinks);
			});
	}

	/// The nearest usable point within maxDistance (a cell's floor, or centre flying). False when there is none.
	public bool SamplePosition(Vector3 point, float maxDistance, out Vector3 found)
	{
		let cell = Nearest(point, maxDistance);
		found = cell >= 0 ? cells[cell].position : point;
		return cell >= 0;
	}

	/// A random usable point within radius of a centre, reachable from it (for wandering). False when there is none.
	public bool RandomPoint(Vector3 center, float radius, Random random, out Vector3 found)
	{
		found = center;
		let start = Nearest(center, Math.Max(radius, cellSize * 2));
		if (start < 0)
			return false;
		let region = Region(start);
		// Picks a few spots and takes the first that lands on a usable, connected cell.
		for (int attempt < 32)
		{
			let angle = (float)random.NextDouble() * Math.PI_f * 2;
			let distance = Math.Sqrt((float)random.NextDouble()) * radius;
			var point = center + .(Math.Cos(angle) * distance, 0, Math.Sin(angle) * distance);
			if (flying)
				point.y += ((float)random.NextDouble() * 2 - 1) * radius;
			let cell = CellAt(point);
			if (Usable(cell) && Region(cell) == region)
			{
				found = cells[cell].position;
				return true;
			}
		}
		found = cells[start].position;
		return true;
	}

	/// How far an agent can go straight from a towards b before something stops it: true when nothing does.
	public bool Raycast(Vector3 from, Vector3 to, out Vector3 hit) => LineClear(from, to, out hit);

	static void Put(List<uint8> bytes, uint32 value)
	{
		for (int shift = 0; shift < 32; shift += 8)
			bytes.Add((uint8)(value >> shift));
	}

	static void Put(List<uint8> bytes, float value)
	{
		var copy = value;
		Put(bytes, *(uint32*)&copy);
	}

	static uint32 Get(List<uint8> bytes, ref int cursor)
	{
		let v = (uint32)bytes[cursor] | ((uint32)bytes[cursor + 1] << 8) | ((uint32)bytes[cursor + 2] << 16) | ((uint32)bytes[cursor + 3] << 24);
		cursor += 4;
		return v;
	}

	static float GetFloat(List<uint8> bytes, ref int cursor)
	{
		var bits = Get(bytes, ref cursor);
		return *(float*)&bits;
	}

	bool ValidGrid(int64 count) => width > 0 && height > 0 && depth > 0 && width <= 4096 && height <= 4096 && depth <= 4096 && (int64)width * height * depth <= 1000000 && cellSize >= 0.05f && cellSize.IsFinite && chunkSize >= 1 && (flying || height == 1) && count == (int64)width * height * depth && origin.x.IsFinite && origin.y.IsFinite && origin.z.IsFinite;
	/// Binary: "TNAV", version 2, the grid settings, then one word per cell (links, top bit = usable) plus the floor
	/// height for walking cells. Everything else about a cell follows from its index.
	public bool Save(StringView path, String error)
	{
		List<uint8> bytes = scope .();
		bytes.Reserve(64 + cells.Count * (flying ? 4 : 8));
		bytes.Add((uint8)'T');
		bytes.Add((uint8)'N');
		bytes.Add((uint8)'A');
		bytes.Add((uint8)'V');
		Put(bytes, (uint32)2);
		Put(bytes, origin.x);
		Put(bytes, origin.y);
		Put(bytes, origin.z);
		Put(bytes, cellSize);
		Put(bytes, (uint32)width);
		Put(bytes, (uint32)height);
		Put(bytes, (uint32)depth);
		Put(bytes, (uint32)chunkSize);
		Put(bytes, flying ? 1u : 0u);
		Put(bytes, agentRadius);
		Put(bytes, agentHeight);
		Put(bytes, maxStep);
		Put(bytes, maxSlope);
		for (let c in cells)
		{
			Put(bytes, (c.links & 0x7FFFFFFF) | (c.walkable ? 0x80000000u : 0u));
			if (!flying)
				Put(bytes, c.position.y);
		}
		if (File.WriteAll(path, bytes) case .Err)
		{
			error.Set("Cannot write navigation asset.");
			return false;
		}
		return true;
	}

	public bool Load(StringView path, String error)
	{
		List<uint8> bytes = scope .();
		if (AssetPack.ReadAll(path, bytes) case .Err)
		{
			error.Set("Cannot read navigation asset.");
			return false;
		}
		if (bytes.Count < 4 || bytes[0] != (uint8)'T' || bytes[1] != (uint8)'N' || bytes[2] != (uint8)'A' || bytes[3] != (uint8)'V') return LoadText(StringView((char8*)bytes.Ptr, bytes.Count), error);
		const int HeaderSize = 60;
		int cursor = 4;
		cells.Clear();
		if (bytes.Count < HeaderSize || Get(bytes, ref cursor) != 2)
		{
			error.Set("Unsupported navigation asset version.");
			return false;
		}
		origin.x = GetFloat(bytes, ref cursor);
		origin.y = GetFloat(bytes, ref cursor);
		origin.z = GetFloat(bytes, ref cursor);
		cellSize = GetFloat(bytes, ref cursor);
		width = (int32)Get(bytes, ref cursor);
		height = (int32)Get(bytes, ref cursor);
		depth = (int32)Get(bytes, ref cursor);
		chunkSize = (int32)Get(bytes, ref cursor);
		flying = Get(bytes, ref cursor) == 1;
		agentRadius = GetFloat(bytes, ref cursor);
		agentHeight = GetFloat(bytes, ref cursor);
		maxStep = GetFloat(bytes, ref cursor);
		maxSlope = GetFloat(bytes, ref cursor);
		let count = (int64)(bytes.Count - HeaderSize) / (flying ? 4 : 8);
		if (!ValidGrid(count) || (int64)bytes.Count != HeaderSize + count * (flying ? 4 : 8))
		{
			width = height = depth = 0;
			error.Set("Invalid navigation dimensions.");
			return false;
		}
		cells.Resize((int)count);
		for (int32 y = 0; y < height; y++)
		{
			for (int32 z = 0; z < depth; z++)
			{
				for (int32 x = 0; x < width; x++)
				{
					let word = Get(bytes, ref cursor);
					Cell cell = default;
					cell.walkable = (word & 0x80000000) != 0;
					cell.links = word & 0x7FFFFFFF;
					cell.position = Center(x, y, z);
					if (!flying)
					{
						cell.position.y = GetFloat(bytes, ref cursor);
						if (!cell.position.y.IsFinite)
						{
							cells.Clear();
							error.Set("Navigation cell has a non-finite position.");
							return false;
						}
					}
					cells[Index(x, y, z)] = cell;
				}
			}
		}
		Touch();
		return true;
	}

	/// Reads the version 1 text format written by earlier builds. Those assets have no diagonal links; bake again to add them.
	bool LoadText(StringView text, String error)
	{
		List<StringView> tokens = scope .();
		List<String> storage = scope .();
		defer
		{
			for (let item in storage)
				delete item;
		}
		bool header = false, grid = false;
		cells.Clear();
		for (let line in text.Split('\n'))
		{
			tokens.Clear();
			SceneSerializer.Tokenize(line, tokens, storage);
			if (tokens.Count == 0) continue;
			if (tokens.Count == 2 && tokens[0] == "navigation" && tokens[1] == "1" && !header)
				header = true;
			else if (tokens.Count == 15 && tokens[0] == "grid" && header && !grid)
			{
				origin = .(SceneSerializer.ParseFloat(tokens[1]), SceneSerializer.ParseFloat(tokens[2]), SceneSerializer.ParseFloat(tokens[3]));
				cellSize = SceneSerializer.ParseFloat(tokens[4]);
				width = SceneSerializer.ParseInt(tokens[5]);
				height = SceneSerializer.ParseInt(tokens[6]);
				depth = SceneSerializer.ParseInt(tokens[7]);
				chunkSize = SceneSerializer.ParseInt(tokens[8]);
				flying = tokens[9] == "1";
				agentRadius = SceneSerializer.ParseFloat(tokens[10]);
				agentHeight = SceneSerializer.ParseFloat(tokens[11]);
				maxStep = SceneSerializer.ParseFloat(tokens[12]);
				maxSlope = SceneSerializer.ParseFloat(tokens[13]);
				if (width <= 0 || height <= 0 || depth <= 0 || width > 4096 || height > 4096 || depth > 4096 || (int64)width * height * depth > 1000000 || cellSize < 0.05f || !cellSize.IsFinite || chunkSize < 1 || (!flying && height != 1) || SceneSerializer.ParseInt(tokens[14]) != (int64)width * height * depth || !origin.x.IsFinite || !origin.y.IsFinite || !origin.z.IsFinite)
				{
					error.Set("Invalid navigation dimensions.");
					return false;
				}
				grid = true;
			}
			else if (tokens.Count == 6 && tokens[0] == "cell" && grid && cells.Count < width * height * depth)
				cells.Add(.() { walkable = tokens[1] == "1", position = .(SceneSerializer.ParseFloat(tokens[2]), SceneSerializer.ParseFloat(tokens[3]), SceneSerializer.ParseFloat(tokens[4])), links = (uint32)SceneSerializer.ParseInt(tokens[5]) & 0x3F });
			else
			{
				error.Set("Malformed navigation asset.");
				return false;
			}
		}
		for (let cell in cells)
		{
			if (!cell.position.x.IsFinite || !cell.position.y.IsFinite || !cell.position.z.IsFinite)
			{
				error.Set("Navigation cell has a non-finite position.");
				return false;
			}
		}
		if (!grid || cells.Count != width * height * depth)
		{
			error.Set("Incomplete navigation asset.");
			return false;
		}
		Touch();
		return true;
	}
}
