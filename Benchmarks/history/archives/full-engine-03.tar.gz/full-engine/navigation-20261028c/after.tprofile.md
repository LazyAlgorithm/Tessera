# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 0.800 ms | 0.799 ms | 0.810 ms | 0.831 ms | 0.849 ms | 0.776 ms |
| CPU main thread | 0.739 ms | 0.738 ms | 0.748 ms | 0.763 ms | 0.776 ms | 0.729 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 0.720 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Search | AI | 0.416 ms | 0.493 ms | 100 | 0.510 ms | 64/64 |
| Navigation.LineClear | AI | 0.167 ms | 0.167 ms | 900 | 0.179 ms | 64/64 |
| Navigation.Corridor | AI | 0.077 ms | 0.077 ms | 100 | 0.081 ms | 64/64 |
| Navigation.Smooth | AI | 0.036 ms | 0.203 ms | 100 | 0.218 ms | 64/64 |
| Frame | Other | 0.019 ms | 0.739 ms | 1 | 0.776 ms | 64/64 |
| Navigation.Nearest | AI | 0.013 ms | 0.016 ms | 200 | 0.023 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.012 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.009 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 0.849 ms, CPU 0.743 ms, GPU -

```
Frame  total 0.743 ms, self 0.019 ms
  Navigation.Search  total 0.497 ms, self 0.421 ms, 100 calls
    Navigation.Corridor  total 0.076 ms, self 0.076 ms, 100 calls
  Navigation.Smooth  total 0.203 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.166 ms, self 0.166 ms, 900 calls
```

### Frame 57: interval 0.831 ms, CPU 0.742 ms, GPU -

```
Frame  total 0.742 ms, self 0.019 ms
  Navigation.Search  total 0.492 ms, self 0.416 ms, 100 calls
    Navigation.Corridor  total 0.076 ms, self 0.076 ms, 100 calls
  Navigation.Smooth  total 0.204 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.167 ms, self 0.167 ms, 900 calls
```

### Frame 61: interval 0.825 ms, CPU 0.742 ms, GPU -

```
Frame  total 0.742 ms, self 0.019 ms
  Navigation.Search  total 0.495 ms, self 0.418 ms, 100 calls
    Navigation.Corridor  total 0.076 ms, self 0.076 ms, 100 calls
  Navigation.Smooth  total 0.205 ms, self 0.038 ms, 100 calls
    Navigation.LineClear  total 0.167 ms, self 0.167 ms, 900 calls
```

### Frame 32: interval 0.810 ms, CPU 0.742 ms, GPU -

```
Frame  total 0.741 ms, self 0.019 ms
  Navigation.Search  total 0.497 ms, self 0.421 ms, 100 calls
    Navigation.Corridor  total 0.077 ms, self 0.077 ms, 100 calls
  Navigation.Smooth  total 0.201 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.165 ms, self 0.165 ms, 900 calls
```

### Frame 7: interval 0.810 ms, CPU 0.739 ms, GPU -

```
Frame  total 0.739 ms, self 0.019 ms
  Navigation.Search  total 0.494 ms, self 0.415 ms, 100 calls
    Navigation.Corridor  total 0.079 ms, self 0.079 ms, 100 calls
  Navigation.Smooth  total 0.203 ms, self 0.037 ms, 100 calls
    Navigation.LineClear  total 0.166 ms, self 0.166 ms, 900 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
