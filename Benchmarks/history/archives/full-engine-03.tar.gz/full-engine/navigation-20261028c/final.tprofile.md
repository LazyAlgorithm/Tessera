# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 0.795 ms | 0.792 ms | 0.816 ms | 0.818 ms | 0.860 ms | 0.777 ms |
| CPU main thread | 0.731 ms | 0.729 ms | 0.746 ms | 0.755 ms | 0.777 ms | 0.721 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 0.713 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Search | AI | 0.414 ms | 0.490 ms | 100 | 0.505 ms | 64/64 |
| Navigation.LineClear | AI | 0.165 ms | 0.165 ms | 900 | 0.176 ms | 64/64 |
| Navigation.Corridor | AI | 0.076 ms | 0.076 ms | 100 | 0.087 ms | 64/64 |
| Navigation.Smooth | AI | 0.033 ms | 0.198 ms | 100 | 0.212 ms | 64/64 |
| Frame | Other | 0.019 ms | 0.731 ms | 1 | 0.777 ms | 64/64 |
| Navigation.Nearest | AI | 0.013 ms | 0.016 ms | 200 | 0.025 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.013 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.010 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 0.860 ms, CPU 0.729 ms, GPU -

```
Frame  total 0.729 ms, self 0.018 ms
  Navigation.Search  total 0.488 ms, self 0.413 ms, 100 calls
    Navigation.Corridor  total 0.076 ms, self 0.076 ms, 100 calls
  Navigation.Smooth  total 0.198 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.165 ms, self 0.165 ms, 900 calls
```

### Frame 19: interval 0.818 ms, CPU 0.743 ms, GPU -

```
Frame  total 0.743 ms, self 0.019 ms
  Navigation.Search  total 0.500 ms, self 0.419 ms, 100 calls
    Navigation.Corridor  total 0.081 ms, self 0.081 ms, 100 calls
  Navigation.Smooth  total 0.201 ms, self 0.034 ms, 100 calls
    Navigation.LineClear  total 0.167 ms, self 0.167 ms, 900 calls
```

### Frame 41: interval 0.817 ms, CPU 0.726 ms, GPU -

```
Frame  total 0.726 ms, self 0.019 ms
  Navigation.Search  total 0.487 ms, self 0.412 ms, 100 calls
    Navigation.Corridor  total 0.075 ms, self 0.075 ms, 100 calls
  Navigation.Smooth  total 0.197 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.164 ms, self 0.164 ms, 900 calls
```

### Frame 63: interval 0.816 ms, CPU 0.729 ms, GPU -

```
Frame  total 0.729 ms, self 0.019 ms
  Navigation.Search  total 0.487 ms, self 0.412 ms, 100 calls
    Navigation.Corridor  total 0.075 ms, self 0.075 ms, 100 calls
  Navigation.Smooth  total 0.200 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.167 ms, self 0.167 ms, 900 calls
```

### Frame 59: interval 0.812 ms, CPU 0.726 ms, GPU -

```
Frame  total 0.726 ms, self 0.018 ms
  Navigation.Search  total 0.487 ms, self 0.412 ms, 100 calls
    Navigation.Corridor  total 0.075 ms, self 0.075 ms, 100 calls
  Navigation.Smooth  total 0.197 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.164 ms, self 0.164 ms, 900 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
