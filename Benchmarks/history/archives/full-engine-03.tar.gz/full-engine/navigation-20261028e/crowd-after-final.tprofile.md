# Tessera Profiler report

Frames 40 to 103 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 4.586 ms | 4.848 ms | 6.292 ms | 6.304 ms | 6.331 ms | 3.425 ms |
| CPU main thread | 4.422 ms | 4.715 ms | 6.139 ms | 6.155 ms | 6.188 ms | 3.314 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 4.217 ms
- Scripts: 0.193 ms
- Other: 0.011 ms
- Animation: 0.000 ms
- Audio: 0.000 ms

## Thread 'Load Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Avoid.Neighbors | AI | 2.972 ms | 2.972 ms | 1000 | 3.040 ms | 64/64 |
| Navigation.Avoid.Candidates | AI | 1.115 ms | 1.159 ms | 1000 | 2.886 ms | 64/64 |
| Update (every component) | Scripts | 0.182 ms | 4.399 ms | 1 | 6.165 ms | 64/64 |
| Navigation.Avoid | AI | 0.086 ms | 4.217 ms | 1000 | 5.984 ms | 64/64 |
| Navigation.LineClear | AI | 0.044 ms | 0.044 ms | 382.81 | 0.124 ms | 34/64 |
| Frame | Other | 0.011 ms | 4.422 ms | 1 | 6.188 ms | 64/64 |
| OnFrame (every component) | Scripts | 0.006 ms | 0.006 ms | 1 | 0.012 ms | 64/64 |
| LateUpdate (every component) | Scripts | 0.006 ms | 0.006 ms | 1 | 0.006 ms | 64/64 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.001 ms | 64/64 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Start | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 51: interval 6.331 ms, CPU 6.127 ms, GPU -

```
Frame  total 6.127 ms, self 0.011 ms
  Update (every component)  total 6.104 ms, self 0.183 ms
    Navigation.Avoid  total 5.921 ms, self 0.089 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.953 ms, self 2.953 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.879 ms, self 2.768 ms, 1000 calls
        Navigation.LineClear  total 0.111 ms, self 0.111 ms, 1000 calls
```

### Frame 42: interval 6.304 ms, CPU 6.049 ms, GPU -

```
Frame  total 6.049 ms, self 0.011 ms
  Update (every component)  total 6.026 ms, self 0.180 ms
    Navigation.Avoid  total 5.846 ms, self 0.087 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.891 ms, self 2.891 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.868 ms, self 2.762 ms, 1000 calls
        Navigation.LineClear  total 0.106 ms, self 0.106 ms, 1000 calls
```

### Frame 49: interval 6.293 ms, CPU 6.066 ms, GPU -

```
Frame  total 6.066 ms, self 0.013 ms
  Update (every component)  total 6.041 ms, self 0.180 ms
    Navigation.Avoid  total 5.861 ms, self 0.087 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.901 ms, self 2.901 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.873 ms, self 2.765 ms, 1000 calls
        Navigation.LineClear  total 0.108 ms, self 0.108 ms, 1000 calls
```

### Frame 55: interval 6.292 ms, CPU 4.776 ms, GPU -

```
Frame  total 4.776 ms, self 0.011 ms
  Update (every component)  total 4.754 ms, self 0.185 ms
    Navigation.Avoid  total 4.569 ms, self 0.087 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 3.006 ms, self 3.006 ms, 1000 calls
      Navigation.Avoid.Candidates  total 1.475 ms, self 1.420 ms, 1000 calls
        Navigation.LineClear  total 0.055 ms, self 0.055 ms, 500 calls
```

### Frame 47: interval 6.283 ms, CPU 6.108 ms, GPU -

```
Frame  total 6.107 ms, self 0.011 ms
  Update (every component)  total 6.085 ms, self 0.183 ms
    Navigation.Avoid  total 5.902 ms, self 0.087 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.949 ms, self 2.949 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.865 ms, self 2.758 ms, 1000 calls
        Navigation.LineClear  total 0.107 ms, self 0.107 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
