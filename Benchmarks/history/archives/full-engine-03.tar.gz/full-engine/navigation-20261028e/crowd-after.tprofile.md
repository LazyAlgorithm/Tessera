# Tessera Profiler report

Frames 40 to 103 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 4.532 ms | 4.793 ms | 6.256 ms | 6.265 ms | 6.266 ms | 3.341 ms |
| CPU main thread | 4.356 ms | 4.645 ms | 6.098 ms | 6.109 ms | 6.112 ms | 3.224 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 4.143 ms
- Scripts: 0.202 ms
- Other: 0.011 ms
- Audio: 0.000 ms
- Animation: 0.000 ms

## Thread 'Load Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Avoid.Neighbors | AI | 2.869 ms | 2.869 ms | 1000 | 2.972 ms | 64/64 |
| Navigation.Avoid.Candidates | AI | 1.135 ms | 1.176 ms | 1000 | 2.946 ms | 64/64 |
| Update (every component) | Scripts | 0.190 ms | 4.333 ms | 1 | 6.089 ms | 64/64 |
| Navigation.Avoid | AI | 0.098 ms | 4.143 ms | 1000 | 5.899 ms | 64/64 |
| Navigation.LineClear | AI | 0.042 ms | 0.042 ms | 382.81 | 0.123 ms | 34/64 |
| Frame | Other | 0.011 ms | 4.356 ms | 1 | 6.111 ms | 64/64 |
| OnFrame (every component) | Scripts | 0.006 ms | 0.006 ms | 1 | 0.006 ms | 64/64 |
| LateUpdate (every component) | Scripts | 0.006 ms | 0.006 ms | 1 | 0.007 ms | 64/64 |
| Start | Scripts | 0.000 ms | 0.000 ms | 1 | 0.005 ms | 64/64 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 47: interval 6.266 ms, CPU 6.109 ms, GPU -

```
Frame  total 6.109 ms, self 0.011 ms
  Update (every component)  total 6.085 ms, self 0.189 ms
    Navigation.Avoid  total 5.896 ms, self 0.101 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.910 ms, self 2.812 ms, 1000 calls
        Navigation.LineClear  total 0.098 ms, self 0.098 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.886 ms, self 2.886 ms, 1000 calls
```

### Frame 48: interval 6.265 ms, CPU 6.051 ms, GPU -

```
Frame  total 6.051 ms, self 0.011 ms
  Update (every component)  total 6.027 ms, self 0.190 ms
    Navigation.Avoid  total 5.837 ms, self 0.098 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.910 ms, self 2.811 ms, 1000 calls
        Navigation.LineClear  total 0.099 ms, self 0.099 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.829 ms, self 2.829 ms, 1000 calls
```

### Frame 44: interval 6.256 ms, CPU 6.045 ms, GPU -

```
Frame  total 6.044 ms, self 0.011 ms
  Update (every component)  total 6.022 ms, self 0.190 ms
    Navigation.Avoid  total 5.831 ms, self 0.098 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.924 ms, self 2.825 ms, 1000 calls
        Navigation.LineClear  total 0.098 ms, self 0.098 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.810 ms, self 2.810 ms, 1000 calls
```

### Frame 42: interval 6.256 ms, CPU 6.012 ms, GPU -

```
Frame  total 6.011 ms, self 0.011 ms
  Update (every component)  total 5.989 ms, self 0.191 ms
    Navigation.Avoid  total 5.798 ms, self 0.099 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.911 ms, self 2.812 ms, 1000 calls
        Navigation.LineClear  total 0.098 ms, self 0.098 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.788 ms, self 2.788 ms, 1000 calls
```

### Frame 50: interval 6.250 ms, CPU 6.059 ms, GPU -

```
Frame  total 6.059 ms, self 0.011 ms
  Update (every component)  total 6.036 ms, self 0.190 ms
    Navigation.Avoid  total 5.846 ms, self 0.097 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.917 ms, self 2.819 ms, 1000 calls
        Navigation.LineClear  total 0.098 ms, self 0.098 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 2.832 ms, self 2.832 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
