# Tessera Profiler report

Frames 40 to 103 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 19.102 ms | 19.124 ms | 19.256 ms | 19.305 ms | 19.354 ms | 18.864 ms |
| CPU main thread | 18.969 ms | 18.993 ms | 19.107 ms | 19.175 ms | 19.183 ms | 18.746 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 18.751 ms
- Scripts: 0.207 ms
- Other: 0.011 ms
- Animation: 0.000 ms
- Audio: 0.000 ms

## Thread 'Load Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Avoid.Neighbors | AI | 15.817 ms | 15.817 ms | 1000 | 15.944 ms | 64/64 |
| Navigation.Avoid.Candidates | AI | 2.798 ms | 2.848 ms | 1000 | 3.005 ms | 64/64 |
| Update (every component) | Scripts | 0.196 ms | 18.946 ms | 1 | 19.160 ms | 64/64 |
| Navigation.Avoid | AI | 0.085 ms | 18.750 ms | 1000 | 18.958 ms | 64/64 |
| Navigation.LineClear | AI | 0.050 ms | 0.050 ms | 382.81 | 0.156 ms | 34/64 |
| Frame | Other | 0.011 ms | 18.969 ms | 1 | 19.183 ms | 64/64 |
| OnFrame (every component) | Scripts | 0.006 ms | 0.006 ms | 1 | 0.008 ms | 64/64 |
| LateUpdate (every component) | Scripts | 0.005 ms | 0.005 ms | 1 | 0.006 ms | 64/64 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Start | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 48: interval 19.354 ms, CPU 19.094 ms, GPU -

```
Frame  total 19.094 ms, self 0.011 ms
  Update (every component)  total 19.072 ms, self 0.199 ms
    Navigation.Avoid  total 18.873 ms, self 0.085 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 15.832 ms, self 15.832 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.955 ms, self 2.836 ms, 1000 calls
        Navigation.LineClear  total 0.119 ms, self 0.119 ms, 1000 calls
```

### Frame 64: interval 19.305 ms, CPU 18.943 ms, GPU -

```
Frame  total 18.943 ms, self 0.011 ms
  Update (every component)  total 18.921 ms, self 0.194 ms
    Navigation.Avoid  total 18.727 ms, self 0.085 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 15.731 ms, self 15.731 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.911 ms, self 2.838 ms, 1000 calls
        Navigation.LineClear  total 0.073 ms, self 0.073 ms, 500 calls
```

### Frame 50: interval 19.257 ms, CPU 19.107 ms, GPU -

```
Frame  total 19.107 ms, self 0.011 ms
  Update (every component)  total 19.085 ms, self 0.195 ms
    Navigation.Avoid  total 18.889 ms, self 0.086 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 15.842 ms, self 15.842 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.961 ms, self 2.838 ms, 1000 calls
        Navigation.LineClear  total 0.124 ms, self 0.124 ms, 1000 calls
```

### Frame 51: interval 19.256 ms, CPU 19.048 ms, GPU -

```
Frame  total 19.048 ms, self 0.011 ms
  Update (every component)  total 19.024 ms, self 0.195 ms
    Navigation.Avoid  total 18.829 ms, self 0.085 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 15.775 ms, self 15.775 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.969 ms, self 2.845 ms, 1000 calls
        Navigation.LineClear  total 0.124 ms, self 0.124 ms, 1000 calls
```

### Frame 43: interval 19.253 ms, CPU 19.095 ms, GPU -

```
Frame  total 19.095 ms, self 0.011 ms
  Update (every component)  total 19.072 ms, self 0.196 ms
    Navigation.Avoid  total 18.876 ms, self 0.086 ms, 1000 calls
      Navigation.Avoid.Neighbors  total 15.823 ms, self 15.823 ms, 1000 calls
      Navigation.Avoid.Candidates  total 2.968 ms, self 2.847 ms, 1000 calls
        Navigation.LineClear  total 0.120 ms, self 0.120 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
