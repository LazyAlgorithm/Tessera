# Tessera Profiler report

Frames 40 to 103 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 0.319 ms | 0.318 ms | 0.332 ms | 0.343 ms | 0.347 ms | 0.311 ms |
| CPU main thread | 0.316 ms | 0.315 ms | 0.328 ms | 0.341 ms | 0.345 ms | 0.308 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 0.312 ms
- Other: 0.004 ms

## Thread 'Load Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Nodes | AI | 0.284 ms | 0.284 ms | 1 | 0.311 ms | 64/64 |
| Navigation.Search | AI | 0.015 ms | 0.016 ms | 1 | 0.026 ms | 64/64 |
| Navigation.LineClear | AI | 0.011 ms | 0.011 ms | 5 | 0.016 ms | 64/64 |
| Frame | Other | 0.004 ms | 0.316 ms | 1 | 0.345 ms | 64/64 |
| Navigation.Corridor | AI | 0.001 ms | 0.001 ms | 1 | 0.003 ms | 64/64 |
| Navigation.Smooth | AI | 0.000 ms | 0.011 ms | 1 | 0.017 ms | 64/64 |
| Navigation.Nearest | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 64/64 |
| Navigation.Regions | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 82: interval 0.347 ms, CPU 0.312 ms, GPU -

```
Frame  total 0.312 ms, self 0.004 ms
  Navigation.Nodes  total 0.282 ms, self 0.282 ms
```

### Frame 81: interval 0.311 ms, CPU 0.345 ms, GPU -

```
Frame  total 0.345 ms, self 0.004 ms
  Navigation.Nodes  total 0.311 ms, self 0.311 ms
```

### Frame 61: interval 0.343 ms, CPU 0.313 ms, GPU -

```
Frame  total 0.313 ms, self 0.004 ms
  Navigation.Nodes  total 0.280 ms, self 0.280 ms
```

### Frame 60: interval 0.320 ms, CPU 0.341 ms, GPU -

```
Frame  total 0.341 ms, self 0.004 ms
  Navigation.Nodes  total 0.311 ms, self 0.311 ms
```

### Frame 41: interval 0.337 ms, CPU 0.314 ms, GPU -

```
Frame  total 0.314 ms, self 0.004 ms
  Navigation.Nodes  total 0.280 ms, self 0.280 ms
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 1, 1, 1, 1, 1
- Path Search Visits: 31, 31, 35.5, 40, 40

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
