# Tessera Profiler report

Frames 40 to 103 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 2.860 ms | 2.877 ms | 2.921 ms | 2.922 ms | 2.930 ms | 2.793 ms |
| CPU main thread | 2.858 ms | 2.878 ms | 2.917 ms | 2.918 ms | 2.927 ms | 2.790 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 2.853 ms
- Other: 0.004 ms

## Thread 'Load Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Regions | AI | 2.536 ms | 2.536 ms | 2 | 2.598 ms | 64/64 |
| Navigation.Nodes | AI | 0.289 ms | 0.289 ms | 1 | 0.297 ms | 64/64 |
| Navigation.Search | AI | 0.016 ms | 0.017 ms | 1 | 0.035 ms | 64/64 |
| Navigation.LineClear | AI | 0.011 ms | 0.011 ms | 5 | 0.015 ms | 64/64 |
| Frame | Other | 0.004 ms | 2.858 ms | 1 | 2.926 ms | 64/64 |
| Navigation.Corridor | AI | 0.001 ms | 0.001 ms | 1 | 0.001 ms | 64/64 |
| Navigation.Smooth | AI | 0.000 ms | 0.011 ms | 1 | 0.015 ms | 64/64 |
| Navigation.Nearest | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 80: interval 2.930 ms, CPU 2.873 ms, GPU -

```
Frame  total 2.873 ms, self 0.004 ms
  Navigation.Regions  total 2.555 ms, self 2.555 ms
  Navigation.Nodes  total 0.287 ms, self 0.287 ms
```

### Frame 79: interval 2.918 ms, CPU 2.927 ms, GPU -

```
Frame  total 2.926 ms, self 0.004 ms
  Navigation.Regions  total 2.598 ms, self 2.598 ms
  Navigation.Nodes  total 0.295 ms, self 0.295 ms
```

### Frame 77: interval 2.922 ms, CPU 2.912 ms, GPU -

```
Frame  total 2.912 ms, self 0.004 ms
  Navigation.Regions  total 2.586 ms, self 2.586 ms
  Navigation.Nodes  total 0.291 ms, self 0.291 ms
```

### Frame 94: interval 2.921 ms, CPU 2.889 ms, GPU -

```
Frame  total 2.889 ms, self 0.004 ms
  Navigation.Regions  total 2.571 ms, self 2.571 ms
  Navigation.Nodes  total 0.288 ms, self 0.288 ms
```

### Frame 102: interval 2.921 ms, CPU 2.901 ms, GPU -

```
Frame  total 2.901 ms, self 0.004 ms
  Navigation.Regions  total 2.580 ms, self 2.580 ms
  Navigation.Nodes  total 0.287 ms, self 0.287 ms
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 1, 1, 1, 1, 1
- Path Search Visits: 31, 31, 35.5, 40, 40

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
