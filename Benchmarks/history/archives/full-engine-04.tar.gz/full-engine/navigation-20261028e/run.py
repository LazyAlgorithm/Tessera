#!/usr/bin/env python3
from pathlib import Path
import subprocess,csv,json,hashlib,statistics,sys,datetime
O=Path(__file__).resolve().parent;phase=sys.argv[1];B=O/'Benchmark.before' if phase=='before' else O.parent/'navigation-load/build/Release_Linux64/Benchmark/Benchmark'
cases=[('nav-crowd',100),('nav-crowd',1000),('nav-crowd',2000),('nav-path-repeated',100),('nav-path-fresh',100),('nav-dynamic',1),('nav-dynamic',100)]
rows=[];manifest={'phase':phase,'started':datetime.datetime.now().isoformat(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'runs':[]}
for case,n in cases:
 for rep in range(3):
  name=f'{phase}-{case}-{n}-{rep}';args=[str(B),case,str(n),'40','120'];print(name,flush=True)
  p=subprocess.run(args,cwd=O.parent,capture_output=True,text=True,timeout=180);(O/(name+'.log')).write_text(p.stdout+'\n'+p.stderr)
  values=[float(x.rsplit(',',1)[1]) for x in p.stdout.splitlines() if x.startswith('BENCH,tessera,')];checks={x.split(',')[1]:x.split(',',2)[2] for x in p.stdout.splitlines() if x.startswith('CHECK,')}
  assert p.returncode==0 and len(values)==120,(name,p.returncode,len(values))
  rows.append([case,n,rep,statistics.median(values),statistics.mean(values),sorted(values)[113]])
  manifest['runs'].append({'name':name,'args':args,'exit':p.returncode,'checks':checks})
  (O/(phase+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
manifest['completed']=datetime.datetime.now().isoformat();(O/(phase+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
with (O/(phase+'.csv')).open('w') as f:w=csv.writer(f);w.writerow(['case','count','repeat','median_ms','mean_ms','p95_ms']);w.writerows(rows)
