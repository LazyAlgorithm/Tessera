#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile,shlex,os
O=Path(__file__).resolve().parent;R=O.parents[2]
with tempfile.TemporaryDirectory(prefix='tessera-navmesh-sanitize-') as directory:
 binary=str(Path(directory)/'native-smoke')
 args=[os.environ.get('CXX','clang++'),'-std=c++17','-O1','-g','-DNDEBUG','-fsanitize=address,undefined','-fno-omit-frame-pointer','-DJPH_OBJECT_LAYER_BITS=32','-DJPH_CROSS_PLATFORM_DETERMINISTIC','-DJPH_OBJECT_STREAM','-DJPH_USE_CPU_COMPUTE']
 args+=['-I'+str(R/p) for p in ['third_party/recastnavigation/Recast/Include','third_party/recastnavigation/Detour/Include','third_party/joltc/include','build/native/_deps/joltphysics-src']]
 args+=[str(R/'native/tessera_navigation.cpp'),str(R/'Tests/NavigationMesh/native_smoke.cpp')]
 for library in ['Recast','Detour']:args+=[str(p) for p in sorted((R/'third_party/recastnavigation'/library/'Source').glob('*.cpp'))]
 args+=['-Wl,--start-group',str(R/'build/native/joltc/libjoltc.a'),str(R/'build/native/_deps/joltphysics-build/libJolt.a'),'-Wl,--end-group','-pthread','-ldl','-lm','-o',binary]
 (O/'sanitize-command.txt').write_text(shlex.join(args)+'\n')
 with (O/'sanitize-build.log').open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
 with (O/'sanitize.log').open('w') as f:subprocess.run([binary],stdout=f,stderr=subprocess.STDOUT,check=True)
 print((O/'sanitize.log').read_text())
