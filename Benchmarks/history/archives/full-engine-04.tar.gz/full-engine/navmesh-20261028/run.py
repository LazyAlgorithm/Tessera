#!/usr/bin/env python3
from pathlib import Path
import subprocess,csv,json,hashlib,statistics,datetime,random
O=Path(__file__).resolve().parent;B=O.parent/'features/build/Release_Linux64/Benchmark/Benchmark'
cases=[('ai-nav-path',100),('ai-navmesh-path',100),('ai-nav-path-batch',100),('ai-navmesh-path-batch',100),('ai-nav-path-batch',1000),('ai-navmesh-path-batch',1000)]
jobs=[(c,n,r) for c,n in cases for r in range(5)];random.Random(28102026).shuffle(jobs)
manifest={'started':datetime.datetime.now().isoformat(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'runs':[]};rows=[]
for c,n,r in jobs:
 args=[str(B),c,str(n),'120','300'];p=subprocess.run(args,cwd=O.parent,capture_output=True,text=True,timeout=180);name=f'{c}-{n}-{r}';(O/(name+'.log')).write_text(p.stdout+'\n'+p.stderr)
 values=[float(x.rsplit(',',1)[1]) for x in p.stdout.splitlines() if x.startswith('BENCH,tessera,')];checks={x.split(',')[1]:x.split(',',2)[2] for x in p.stdout.splitlines() if x.startswith('CHECK,')}
 assert p.returncode==0 and len(values)==300,(name,p.returncode,len(values))
 rows.append([c,n,r,statistics.median(values),statistics.mean(values),sorted(values)[284]])
 manifest['runs'].append({'case':c,'count':n,'repeat':r,'args':args,'exit':p.returncode,'checks':checks});(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(name,statistics.median(values),flush=True)
with (O/'results.csv').open('w') as f:w=csv.writer(f);w.writerow(['case','count','repeat','median_ms','mean_ms','p95_ms']);w.writerows(rows)
manifest['completed']=datetime.datetime.now().isoformat();(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
