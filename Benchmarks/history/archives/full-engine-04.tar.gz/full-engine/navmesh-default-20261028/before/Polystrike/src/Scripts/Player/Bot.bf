using System;
using System.Collections;
using Tessera;

namespace Polystrike;

/// What a bot's behaviour tree has told it to do. The tree decides; the brain below carries it out.
enum BotOrder
{
	Idle,
	/// Keep the target in the sights, at the weapon's distance, and shoot.
	Fight,
	/// Run straight at the target and strike.
	Charge,
	/// Walk the waypoints to Goal.
	GoTo,
	/// Prop Hunt: find a spot, become something that belongs there, and keep still.
	Hide
}

/// A bot's senses and skills. What it does with them is decided by a behaviour tree (AI/bot.tbt), which can be
/// opened and rearranged in the editor's Behavior tab and watched live while a match runs. The tree's nodes set
/// an order; this class turns the order into the same kind of input a person's keyboard and mouse would give,
/// so a bot plays by exactly the rules everyone else does: it walks the map's waypoints, turns at a limited
/// speed, has to see a target to shoot it, and misses.
class BotBrain
{
	// ---- what the tree reads and sets ----
	public BotOrder Order;
	public Vector3 Goal;
	/// True once a GoTo order has reached its goal, or cannot get any nearer.
	public bool Arrived;
	public bool WantReload;
	public Player Target => mTarget;
	public bool Visible => mVisible && mTarget != null && mTarget.alive;
	public bool HasLastSeen => mHasLastSeen;
	public Vector3 LastSeen => mLastSeen;
	public bool Settled => mSettled;
	/// Prop Hunt: how long, in seconds, to look for a hiding place before settling.
	public float HideSeconds = 8;

	List<int32> mPath = new .() ~ delete _;
	int32 mPathIndex;
	Vector3 mPathGoal;
	bool mHasPath;
	Player mTarget;
	bool mVisible;
	int32 mSeenTicks;
	Vector3 mLastSeen;
	bool mHasLastSeen;
	float mYaw, mPitch;
	bool mStarted;
	int32 mTick;
	float mStrafe = 1;
	int32 mStrafeTicks;
	int32 mTriggerTicks, mRestTicks;
	Vector3 mStuckFrom;
	int32 mStuckCount;
	int32 mJumpTicks;
	uint32 mRandom;
	int32 mHideTicks = -1;
	bool mSettled;
	int32 mNavVersion = -1;

	public float Random01()
	{
		mRandom ^= mRandom << 13;
		mRandom ^= mRandom >> 17;
		mRandom ^= mRandom << 5;
		return (mRandom & 0xffffff) / 16777216.0f;
	}

	public int32 RandomInt(int32 count) => count > 0 ? (int32)(Random01() * count) % count : 0;

	public void ForgetLastSeen()
	{
		mHasLastSeen = false;
	}

	/// A waypoint somewhere on the map, for wandering to.
	public Vector3 RandomPlace(Vector3 fallback)
	{
		return NavGraph.Nodes.Count > 0 ? NavGraph.Nodes[RandomInt((int32)NavGraph.Nodes.Count)] : fallback;
	}

	public NetInput Think(Player self)
	{
		NetInput input = default;
		let match = Match.Instance;
		if (!mStarted)
		{
			mStarted = true;
			mYaw = self.Transform.EulerAngles.y;
			mRandom = (uint32)self.JoinOrder * 2654435761 + 0x01234567;
			if (mRandom == 0) mRandom = 1;
			mTick = RandomInt(60);
		}
		mTick++;
		input.yaw = mYaw;
		input.pitch = mPitch;
		// Bots climb a ledge as they reach it (Player's Custom5), as they always have: their jumps are held from the
		// ground, so the second press a keyboard player gives would never come.
		input.SetButton((int)InputButton.Custom5, true);
		if (match == null || !self.alive)
		{
			mPath.Clear();
			mHasPath = false;
			mTarget = null;
			mHideTicks = -1;
			mSettled = false;
			Order = .Idle;
			return input;
		}
		if (mNavVersion != NavGraph.Version)
		{
			// A new map: the route in hand belongs to the old one.
			mNavVersion = NavGraph.Version;
			mPath.Clear();
			mHasPath = false;
			mHasLastSeen = false;
			mTarget = null;
		}
		if (match.IsFrozen(self) || !NavGraph.Ready)
			return input;
		if (match.Mode == .Tag)
		{
			// Tag has no fighting in it: chasing, running away and freeing friends is a game of its own.
			ThinkTag(self, match, ref input);
			Unstick(self, ref input);
			if (mJumpTicks > 0)
			{
				mJumpTicks--;
				input.SetButton((int)InputButton.Jump, true);
			}
			input.yaw = mYaw;
			input.pitch = mPitch;
			return input;
		}

		// Whoever it was after may have left the game.
		if (mTarget != null && !Player.All.Contains(mTarget))
		{
			mTarget = null;
			mVisible = false;
		}
		// Senses, ten times a second.
		if (mTick % 6 == 0)
		{
			if (self.IsProp)
				mTarget = null;
			else
				PickTarget(self, match);
		}
		if (mTarget != null && !mTarget.alive)
		{
			mTarget = null;
			mVisible = false;
		}
		// Decisions, as often: the behaviour tree, or the same priorities in code if it is missing.
		if (mTick % 6 == 0)
		{
			let runner = self.GetComponent<BehaviorTreeRunner>();
			WantReload = false;
			if (runner == null || runner.Data == null || runner.Data.Root == null)
				Decide(self, match);
			else
				runner.Tick(0.1f);
		}
		// Skills: carry out the order.
		let def = Weapons.Get(self.CurrentWeapon);
		switch (Order)
		{
		case .Fight: Fight(self, def, false, ref input);
		case .Charge: Fight(self, def, true, ref input);
		case .GoTo: Walk(self, match, ref input);
		case .Hide: Hide(self, match, ref input);
		default:
		}
		if (Order != .Fight && Order != .Charge)
		{
			mSeenTicks = 0;
			mTriggerTicks = 0;
		}
		if (WantReload && mTick % 30 < 2)
			input.SetButton((int)InputButton.Reload, true);
		// Out of ammunition altogether: use the other weapon.
		if (!self.Unarmed && self.OtherWeapon >= 0 && self.Ammo == 0 && self.Reserve == 0 && mTick % 40 < 2)
			input.SetButton((int)InputButton.Ability1, true);
		Unstick(self, ref input);
		if (mJumpTicks > 0)
		{
			mJumpTicks--;
			input.SetButton((int)InputButton.Jump, true);
		}
		input.yaw = mYaw;
		input.pitch = mPitch;
		return input;
	}

	int32 mFleeTicks;

	/// Tag. Whoever is it runs down the nearest runner and swings at them. A runner keeps away from whoever is
	/// it, and in freeze tag goes to touch a frozen friend free when the coast is clear.
	void ThinkTag(Player self, Match match, ref NetInput input)
	{
		let here = self.Transform.Position;
		let it = self.team == 2;
		if (mFleeTicks > 0)
			mFleeTicks--;
		if (mTick % 10 == 0)
		{
			Player quarry = null, threat = null;
			float best = float.MaxValue, nearest = float.MaxValue;
			for (let other in Player.All)
			{
				if (other == self || !other.alive)
					continue;
				let distance = (other.Transform.Position - here).LengthSquared;
				if (it)
				{
					if (other.team == 1 && !other.frozenTag && other.TagImmuneTicks <= 0 && distance < best)
					{
						best = distance;
						quarry = other;
					}
				}
				else
				{
					if (other.team == 2 && distance < nearest)
					{
						nearest = distance;
						threat = other;
					}
					if (match.FreezeTag && other.team == 1 && other.frozenTag && distance < best)
					{
						best = distance;
						quarry = other;
					}
				}
			}
			// Nobody goes to the rescue with whoever is it breathing down their neck.
			if (!it && quarry != null && threat != null && nearest < 8 * 8)
				quarry = null;
			mTarget = quarry;
			Order = .GoTo;
			if (quarry != null)
				Goal = quarry.Transform.Position;
			else if (!it && threat != null && nearest < 15 * 15 && mFleeTicks == 0)
			{
				// Run: of a handful of places, the one furthest from whoever is it.
				let from = threat.Transform.Position;
				var chosen = here;
				float furthest = -1;
				for (int i < 6)
				{
					let place = RandomPlace(here);
					let away = (place - from).LengthSquared;
					if (away > furthest)
					{
						furthest = away;
						chosen = place;
					}
				}
				Goal = chosen;
				mFleeTicks = 90;
			}
			else if (Arrived || !mHasPath)
				Goal = RandomPlace(here);
		}
		if (mTarget != null && mTarget.alive)
		{
			let to = mTarget.Transform.Position - here;
			let distance = to.Length;
			if (distance < 4 && CanSee(self, mTarget))
			{
				// Close enough to go straight at them.
				float yaw, pitch;
				AnglesTo(self.EyePosition, mTarget.Center, out yaw, out pitch);
				TurnTowards(yaw, pitch, 14);
				SetMove(to, ref input);
				if (distance < 2.1f && mTick % 46 < 2)
					input.SetButton((int)InputButton.Fire, true);
				return;
			}
		}
		Walk(self, match, ref input);
	}

	/// The tree's priorities written out in code, used only when the tree file cannot be loaded.
	void Decide(Player self, Match match)
	{
		let hill = match.Mode == .KingOfTheHill ? match.ActiveHill : null;
		if (self.IsProp)
			Order = .Hide;
		else if (Visible)
			Order = BotNodes.HandToHand(self) ? .Charge : .Fight;
		else if (hill != null)
		{
			Order = .GoTo;
			Goal = hill.Transform.Position;
		}
		else if (Order != .GoTo || Arrived)
		{
			Order = .GoTo;
			Goal = mHasLastSeen ? mLastSeen : RandomPlace(self.Transform.Position);
			mHasLastSeen = false;
		}
	}

	// ---- seeing ----

	bool CanSee(Player self, Player other)
	{
		let from = self.EyePosition;
		let to = other.Center - from;
		let distance = to.Length;
		if (distance > 60 || distance < 0.01f)
			return distance < 0.01f;
		// Only what is roughly in front counts, unless it is very close.
		let facing = Quaternion.Euler(0, mYaw, 0) * Vector3.Forward;
		if (distance > 4 && Vector3.Dot(facing, to / distance) < 0.1f)
			return false;
		ShapeCastHit hit;
		if (!self.Trace(from, to, distance, out hit, 0.05f))
			return true;
		return hit.gameObject == other.GameObject;
	}

	void PickTarget(Player self, Match match)
	{
		Player best = null;
		float bestDistance = float.MaxValue;
		for (let other in Player.All)
		{
			if (!other.alive || !self.IsEnemy(other) || other.role == (int32)Role.Spectator)
				continue;
			let distance = (other.Transform.Position - self.Transform.Position).Length;
			if (other.IsProp)
			{
				// A prop is only given away by being close and moving, or by a lucky guess.
				let body = other.GetComponent<CharacterController>();
				let moving = body != null && body.Velocity.LengthSquared > 1.0f;
				if (distance > 16 || (!moving && other != mTarget && Random01() > 0.03f))
					continue;
			}
			if (distance < bestDistance && CanSee(self, other))
			{
				best = other;
				bestDistance = distance;
			}
		}
		if (best != null)
		{
			if (best != mTarget)
				mSeenTicks = 0;
			mTarget = best;
			mVisible = true;
			mLastSeen = best.Transform.Position;
			mHasLastSeen = true;
		}
		else
		{
			mVisible = false;
			mTarget = null;
		}
	}

	// ---- moving ----

	void SetMove(Vector3 world, ref NetInput input)
	{
		var flat = Vector3(world.x, 0, world.z);
		if (flat.LengthSquared < 1.0e-6f)
			return;
		flat = flat.Normalized;
		let rotation = Quaternion.Euler(0, mYaw, 0);
		input.moveX = Mathf.Clamp(Vector3.Dot(flat, rotation * Vector3.Right), -1, 1);
		input.moveZ = Mathf.Clamp(Vector3.Dot(flat, rotation * Vector3.Forward), -1, 1);
	}

	/// Walks along the route in hand. Returns false when there is nowhere left to go.
	bool FollowPath(Player self, ref NetInput input, out Vector3 heading)
	{
		heading = .Zero;
		let position = self.Transform.Position;
		for (let index in mPath)
		{
			if (index < 0 || index >= NavGraph.Nodes.Count)
			{
				mPath.Clear();
				return false;
			}
		}
		while (mPathIndex < mPath.Count)
		{
			let node = NavGraph.Nodes[mPath[mPathIndex]];
			let dx = node.x - position.x, dz = node.z - position.z;
			if (dx * dx + dz * dz < 0.8f * 0.8f && Math.Abs(node.y - position.y) < 1.6f)
				mPathIndex++;
			else
				break;
		}
		if (mPathIndex >= mPath.Count)
			return false;
		let node = NavGraph.Nodes[mPath[mPathIndex]];
		heading = Vector3(node.x - position.x, 0, node.z - position.z);
		SetMove(heading, ref input);
		return true;
	}

	/// The GoTo order: plan a route to Goal when it changes, then follow it.
	void Walk(Player self, Match match, ref NetInput input)
	{
		if (!mHasPath || (mPathGoal - Goal).LengthSquared > 1)
		{
			mPath.Clear();
			mPathIndex = 0;
			mPathGoal = Goal;
			mHasPath = true;
			Arrived = false;
			NavGraph.FindPath(NavGraph.Nearest(self.Transform.Position), NavGraph.Nearest(Goal), mPath);
		}
		Vector3 heading;
		if (!FollowPath(self, ref input, out heading))
		{
			Arrived = true;
			return;
		}
		// Look where we are going, with a glance to either side.
		TurnTowards(Math.Atan2(heading.x, heading.z) * Mathf.Rad2Deg + Math.Sin(mTick * 0.03f) * 25, 0, 5);
		SetMove(heading, ref input);
	}

	void Unstick(Player self, ref NetInput input)
	{
		if (mTick % 30 != 0)
			return;
		let moved = (self.Transform.Position - mStuckFrom).Length;
		mStuckFrom = self.Transform.Position;
		if ((Math.Abs(input.moveX) > 0.1f || Math.Abs(input.moveZ) > 0.1f) && moved < 0.5f)
		{
			mStuckCount++;
			mJumpTicks = 8;
			mStrafe = -mStrafe;
			if (mStuckCount >= 3)
			{
				// Give up on this route; whatever ordered it will order another.
				mStuckCount = 0;
				mHasPath = false;
				Arrived = true;
			}
		}
		else
			mStuckCount = 0;
	}

	void TurnTowards(float yaw, float pitch, float rate)
	{
		mYaw += Mathf.Clamp(Mathf.WrapAngle(yaw - mYaw), -rate, rate);
		mYaw = Mathf.WrapAngle(mYaw);
		mPitch = Mathf.Clamp(mPitch + Mathf.Clamp(pitch - mPitch, -rate, rate), -80, 80);
	}

	static void AnglesTo(Vector3 from, Vector3 to, out float yaw, out float pitch)
	{
		let d = to - from;
		yaw = Math.Atan2(d.x, d.z) * Mathf.Rad2Deg;
		pitch = -Math.Atan2(d.y, Math.Sqrt(d.x * d.x + d.z * d.z)) * Mathf.Rad2Deg;
	}

	// ---- fighting ----

	void Fight(Player self, WeaponDef def, bool charge, ref NetInput input)
	{
		if (mTarget == null || !mVisible)
			return;
		mHasPath = false;
		mSeenTicks++;
		let from = self.EyePosition;
		var aimAt = mTarget.Center;
		if (def.projectileKind > 0)
		{
			let flat = Vector3(aimAt.x - from.x, 0, aimAt.z - from.z).Length;
			if (def.projectileKind == 1 && flat > 0.1f)
			{
				// Low ballistic arc for the server's actual gravity and launch speed.
				let gravity = -self.Scene.Physics.Gravity.y;
				let speed2 = def.projectileSpeed * def.projectileSpeed;
				let disc = speed2 * speed2 - gravity * (gravity * flat * flat + 2 * (aimAt.y - from.y) * speed2);
				if (disc >= 0) aimAt.y = from.y + flat * (speed2 - Math.Sqrt(disc)) / (gravity * flat);
			}
		}
		// Aim wanders, more so at range and just after spotting someone.
		let wobble = 0.35f + 1.2f * Math.Exp(-mSeenTicks / 40.0f);
		aimAt += Vector3(Math.Sin(mTick * 0.21f), Math.Sin(mTick * 0.17f + 1) * 0.6f, Math.Cos(mTick * 0.19f)) * wobble;
		float yaw, pitch;
		AnglesTo(from, aimAt, out yaw, out pitch);
		TurnTowards(yaw, pitch, 7.5f);
		let to = mTarget.Transform.Position - self.Transform.Position;
		let distance = to.Length;
		let toward = Vector3(to.x, 0, to.z).Normalized;
		let right = Vector3.Cross(.Up, toward);
		let error = Math.Abs(Mathf.WrapAngle(yaw - mYaw)) + Math.Abs(pitch - mPitch);
		if (charge)
		{
			// Hand to hand there is only one thing to do: close the distance and strike.
			SetMove(toward, ref input);
			if (distance < 2.4f && mTick % 46 < 2)
				input.SetButton((int)InputButton.Ability2, true);
			if (def.sword && self.Ammo > 0 && !self.Unarmed && distance < Math.Max(def.lungeRange, def.range) && error < 12 && mTick % 44 < 2)
				input.SetButton((int)InputButton.Fire, true);
			return;
		}
		let preferred = def.preferredRange;
		let advance = distance > preferred + 3 ? 1.0f : (distance < preferred - 3 ? -0.7f : 0.0f);
		if (--mStrafeTicks <= 0)
		{
			mStrafeTicks = 35 + RandomInt(70);
			mStrafe = Random01() < 0.5f ? -1 : 1;
		}
		SetMove(toward * advance + right * mStrafe * 0.9f, ref input);
		let inRange = distance < def.range * (def.pellets > 1 ? 0.6f : 0.9f) && (def.projectileKind == 0 || distance > def.blastRadius + 1);
		// Fire in bursts, after a moment's reaction.
		if (mRestTicks > 0)
			mRestTicks--;
		else if (mSeenTicks > 18 && error < 7 && inRange)
		{
			input.SetButton((int)InputButton.Fire, def.automatic || mTick % Math.Max(def.fireTicks + 1, 2) == 0);
			if (++mTriggerTicks > 28 + RandomInt(30))
			{
				mTriggerTicks = 0;
				mRestTicks = 8 + RandomInt(16);
			}
		}
		if (distance < 2.0f && mTick % 50 < 2)
			input.SetButton((int)InputButton.Ability2, true);
		if (distance > 9 && distance < 24 && self.grenades > 0 && mTick % 240 == 17 && Random01() < 0.5f)
			input.SetButton((int)InputButton.Custom1, true);
		if (mTick % 150 == 5 && Random01() < 0.4f)
			mJumpTicks = 4;
	}

	// ---- hiding ----

	void Hide(Player self, Match match, ref NetInput input)
	{
		if (mHideTicks < 0)
		{
			mHideTicks = (int32)(60 * HideSeconds);
			mSettled = false;
			Goal = RandomPlace(self.Transform.Position);
			mHasPath = false;
		}
		if (mSettled)
		{
			// Sit still; bolt if a hunter is nearly on top of us.
			if (mTick % 20 == 0)
			{
				for (let other in Player.All)
				{
					if (other.alive && other.role == (int32)Role.Hunter && (other.Transform.Position - self.Transform.Position).Length < 3.2f && Random01() < 0.25f)
					{
						mSettled = false;
						mHideTicks = 60 * (3 + RandomInt(4));
						Goal = RandomPlace(self.Transform.Position);
						mHasPath = false;
					}
				}
			}
			return;
		}
		Walk(self, match, ref input);
		if (--mHideTicks <= 0 || Arrived)
		{
			mSettled = true;
			// Become whatever is nearest, so as to match the surroundings.
			int32 best = -1;
			float bestDistance = 9 * 9;
			for (int32 i = 0; i < match.Props.Count; i++)
			{
				if (!match.Props[i].disguise)
					continue;
				let distance = (match.Props[i].Transform.Position - self.Transform.Position).LengthSquared;
				if (distance < bestDistance)
				{
					bestDistance = distance;
					best = i;
				}
			}
			if (best >= 0 && self.Authority)
				self.BecomeProp(best);
			mYaw = RandomInt(8) * 45.0f;
		}
	}
}

/// The behaviour tree nodes a Polystrike bot is made of. They appear under "Polystrike" in the Behavior tab's
/// add-node menu, alongside the engine's flow nodes (Sequence, Reactive Selector, Cooldown, Wait and the rest).
static class BotNodes
{
	static Player Self(BTContext context) => context.Object.GetComponent<Player>();
	static BotBrain Brain(BTContext context) => Self(context)?.Brain;

	/// Bare hands, or a sword with charge in it: fight by closing in.
	public static bool HandToHand(Player self)
	{
		return self.Unarmed || (Weapons.Get(self.CurrentWeapon).sword && self.Ammo > 0);
	}

	class IsProp : BTNode
	{
		protected override BTStatus OnTick(BTContext context) => (Self(context)?.IsProp == true) ? .Success : .Failure;
	}

	class SeesEnemy : BTNode
	{
		protected override BTStatus OnTick(BTContext context) => (Brain(context)?.Visible == true) ? .Success : .Failure;
	}

	class CloseQuarters : BTNode
	{
		protected override BTStatus OnTick(BTContext context)
		{
			let self = Self(context);
			return (self != null && HandToHand(self)) ? .Success : .Failure;
		}
	}

	class RemembersEnemy : BTNode
	{
		protected override BTStatus OnTick(BTContext context) => (Brain(context)?.HasLastSeen == true) ? .Success : .Failure;
	}

	class HillIsLive : BTNode
	{
		protected override BTStatus OnTick(BTContext context)
		{
			let match = Match.Instance;
			return (match != null && match.Mode == .KingOfTheHill && match.Phase == .Playing && match.ActiveHill != null) ? .Success : .Failure;
		}
	}

	/// Shoot at, or charge, whoever the bot can see. Runs for as long as it can see them.
	class Engage : BTNode
	{
		public BotOrder order;
		protected override BTStatus OnTick(BTContext context)
		{
			let brain = Brain(context);
			if (brain == null || !brain.Visible)
				return .Failure;
			brain.Order = order;
			return .Running;
		}
	}

	class HoldHill : BTNode
	{
		Vector3 mOffset;
		HillZone mHill;
		protected override BTStatus OnTick(BTContext context)
		{
			let brain = Brain(context);
			let hill = Match.Instance?.ActiveHill;
			if (brain == null || hill == null)
				return .Failure;
			if (hill != mHill)
			{
				// Somewhere inside it, not all on the same spot.
				mHill = hill;
				mOffset = .((brain.Random01() - 0.5f) * hill.radius, 0, (brain.Random01() - 0.5f) * hill.radius);
			}
			brain.Order = .GoTo;
			brain.Goal = hill.Transform.Position + mOffset;
			return .Running;
		}
	}

	/// Go and look where an enemy was last seen, then forget about it.
	class Search : BTNode
	{
		protected override void OnStart(BTContext context)
		{
			let brain = Brain(context);
			if (brain == null)
				return;
			brain.Goal = brain.LastSeen;
			brain.Arrived = false;
		}

		protected override BTStatus OnTick(BTContext context)
		{
			let brain = Brain(context);
			if (brain == null)
				return .Failure;
			brain.Order = .GoTo;
			if (!brain.Arrived)
				return .Running;
			brain.ForgetLastSeen();
			return .Success;
		}
	}

	/// Walk to a waypoint picked at random; give up after a while and pick another.
	class Wander : BTNode
	{
		float mLeft;
		protected override void OnStart(BTContext context)
		{
			let brain = Brain(context);
			if (brain == null)
				return;
			brain.Goal = brain.RandomPlace(context.Transform.Position);
			brain.Arrived = false;
			mLeft = Math.Max(Number(0), 2);
		}

		protected override BTStatus OnTick(BTContext context)
		{
			let brain = Brain(context);
			if (brain == null)
				return .Failure;
			brain.Order = .GoTo;
			mLeft -= context.deltaTime;
			return (brain.Arrived || mLeft <= 0) ? .Success : .Running;
		}
	}

	/// Top up a weapon that is running low while nobody is about.
	class Reload : BTNode
	{
		protected override BTStatus OnTick(BTContext context)
		{
			let self = Self(context);
			let brain = Brain(context);
			if (self == null || brain == null)
				return .Failure;
			brain.WantReload = !self.Unarmed && self.Ammo < Weapons.Get(self.CurrentWeapon).magazine / 2 && self.Reserve > 0;
			return .Success;
		}
	}

	/// Prop Hunt: look for a hiding place for a random time between the two settings, then settle.
	class HideAsProp : BTNode
	{
		protected override void OnStart(BTContext context)
		{
			let brain = Brain(context);
			if (brain != null)
				brain.HideSeconds = Number(0) + brain.Random01() * Math.Max(Number(1) - Number(0), 0);
		}

		protected override BTStatus OnTick(BTContext context)
		{
			let brain = Brain(context);
			if (brain == null)
				return .Failure;
			brain.Order = .Hide;
			return .Running;
		}
	}

	public static void Register()
	{
		BehaviorLibrary.Add("polystrike.isprop", "Polystrike", "Is A Prop", .Condition, new () => new IsProp())
			.Describe("Succeeds while this player is a prop in Prop Hunt.");
		BehaviorLibrary.Add("polystrike.sees", "Polystrike", "Sees Enemy", .Condition, new () => new SeesEnemy())
			.Describe("Succeeds while the bot has an enemy in view. Bots look ten times a second, only see what is in front of them, and cannot see through walls.");
		BehaviorLibrary.Add("polystrike.closequarters", "Polystrike", "Fights Hand To Hand", .Condition, new () => new CloseQuarters())
			.Describe("Succeeds when the bot has nothing in its hands, or holds a sword with charge left.");
		BehaviorLibrary.Add("polystrike.remembers", "Polystrike", "Remembers Enemy", .Condition, new () => new RemembersEnemy())
			.Describe("Succeeds if the bot saw an enemy somewhere and has not been to look yet.");
		BehaviorLibrary.Add("polystrike.hill", "Polystrike", "Hill Is Live", .Condition, new () => new HillIsLive())
			.Describe("Succeeds in King of the Hill while there is a hill to hold.");
		BehaviorLibrary.Add("polystrike.fight", "Polystrike", "Shoot Enemy", .Action, new () => new Engage() { order = .Fight })
			.Describe("Keeps the enemy in view at the weapon's best distance, strafing and firing in bursts. Runs until the enemy is lost.");
		BehaviorLibrary.Add("polystrike.charge", "Polystrike", "Charge Enemy", .Action, new () => new Engage() { order = .Charge })
			.Describe("Runs straight at the enemy and strikes: fists, or a sword lunge. Runs until the enemy is lost.");
		BehaviorLibrary.Add("polystrike.holdhill", "Polystrike", "Hold The Hill", .Action, new () => new HoldHill())
			.Describe("Walks to a spot inside the live hill and stays there.");
		BehaviorLibrary.Add("polystrike.search", "Polystrike", "Search Where Last Seen", .Action, new () => new Search())
			.Describe("Walks to where an enemy was last seen, then forgets it.");
		BehaviorLibrary.Add("polystrike.wander", "Polystrike", "Wander", .Action, new () => new Wander())
			.With("Give Up After", .Number, "25")
			.Describe("Walks to a waypoint picked at random. Succeeds on arrival, or after this many seconds.");
		BehaviorLibrary.Add("polystrike.reload", "Polystrike", "Reload If Low", .Action, new () => new Reload())
			.Describe("Reloads if the magazine is under half full. Always succeeds, so it can sit at the start of a Sequence.");
		BehaviorLibrary.Add("polystrike.hide", "Polystrike", "Hide As A Prop", .Action, new () => new HideAsProp())
			.With("Look For At Least", .Number, "5")
			.With("And At Most", .Number, "16")
			.Describe("Prop Hunt: walks somewhere at random for a time between these, becomes the nearest prop, and keeps still. Bolts if a hunter comes close.");
	}
}
