using System;
using System.Collections;
using Tessera;

namespace Polystrike;

/// On the root object of every map: its name and the few things the game needs to know about it. The map's sky,
/// fog and sun are the ones of the scene it is kept in, set in the editor like any scene's.
[Component]
class MapInfo : Component
{
	public String displayName = new .("Map") ~ delete _;
	public String description = new .() ~ delete _;
	/// Anyone who falls below this height dies.
	public float killHeight = -12;
	/// Looping background sound, relative to the asset folder.
	public String ambience = new .() ~ delete _;
	/// Where the menu camera circles from, and what it looks at.
	public Vector3 previewPosition = .(-20, 12, -20);
	public Vector3 previewTarget = .(0, 1, 0);
}

/// In every map scene. Pressing Play in the editor with a map open starts a match on it, exactly as it is on
/// screen, without going through the menu: this brings in the Game object the map scene does not have.
/// When the game itself loads the map it does nothing.
[Component]
class MapPreview : Component
{
	public override void Awake()
	{
		if (Match.Instance != null || Scene.FindComponent<Match>() != null)
			return;
		let info = Scene.FindComponent<MapInfo>();
		if (info == null || Prefab.Create(Scene, "Prefabs/Game.tprefab") == null)
			return;
		Session.DirectMap = info.GameObject;
	}
}

/// Marks a piece of scenery that a player can disguise as in Prop Hunt, and that hunters are punished for shooting.
[Component]
class PropInfo : Component
{
	public String label = new .("Prop") ~ delete _;
	public String mesh = new .() ~ delete _;
	/// Size of the box a player hiding as this prop collides with.
	public Vector3 size = .One;
	/// Off for scenery that is too big or too odd to be a fair disguise.
	public bool disguise = true;
}

/// A body of water: a box of it, placed and sized in Anvil. Its top is the surface. Anyone in it sinks slowly
/// and can swim; anyone whose head is under it is holding their breath; and a camera below the surface sees
/// the world through it.
[Component]
class WaterZone : Component
{
	public static List<WaterZone> All = new .() ~ delete _;

	/// How wide, deep and long it is. The object is scaled to the same, so a unit box fits it exactly.
	public Vector3 size = .(8, 2, 8);

	public override void Awake() => All.Add(this);
	public override void OnDestroy() => All.Remove(this);

	public bool Contains(Vector3 point)
	{
		let local = Transform.InverseTransformPoint(point);
		return Math.Abs(local.x) <= 0.5f && Math.Abs(local.y) <= 0.5f && Math.Abs(local.z) <= 0.5f;
	}

	// ---- the swell ----
	//
	// The surface moves, and what floats on it moves with it. All of it is worked out from where a point is and
	// what time it is by the server's clock, which every machine knows: so the water is in the same state on
	// every screen, and on the server that decides what collides with what, without any of it being sent.

	/// The time the water goes by, in seconds.
	public static double Now(Scene scene)
	{
		let network = scene?.Network;
		if (network != null && network.Mode != .Offline)
			return network.ServerTick / Time.TickRate;
		return (double)Time.Tick / Time.TickRate;
	}

	struct Ring
	{
		public Vector3 centre;
		public double start;
	}
	static List<Ring> sRings = new .() ~ delete _;

	/// Something has struck the water (an explosion, say): rings spread from there for a few seconds.
	public static void Ripple(Scene scene, Vector3 position)
	{
		// Only if it happened in the water, or just over it.
		if (At(position) == null && At(position - .(0, 1.5f, 0)) == null)
			return;
		if (sRings.Count >= 8)
			sRings.RemoveAt(0);
		sRings.Add(.() { centre = position, start = Now(scene) });
	}

	/// How far above its resting level the surface is at a place and time, in metres.
	public static float Wave(float x, float z, double time)
	{
		let t = (float)(time % 3600);
		var height = 0.07f * Math.Sin(0.9f * x + 1.3f * t) + 0.05f * Math.Sin(1.4f * z - 1.7f * t + 1.1f) + 0.03f * Math.Sin(0.7f * (x + z) + 2.3f * t);
		for (let ring in sRings)
		{
			let age = (float)(time - ring.start);
			if (age < 0 || age > 6)
				continue;
			let dx = x - ring.centre.x, dz = z - ring.centre.z;
			// A band of ripples travelling outwards at four metres a second, fading as it goes.
			let behind = age * 4 - Math.Sqrt(dx * dx + dz * dz);
			if (behind < 0 || behind > 7)
				continue;
			height += 0.3f * Math.Sin(behind * 2.6f) * Math.Exp(-behind * 0.45f) * Math.Exp(-age * 0.55f);
		}
		return height;
	}

	/// How far a ring is pushing something floating at a place, and which way: outwards as the front passes.
	public static Vector3 Push(float x, float z, double time)
	{
		Vector3 push = .Zero;
		for (let ring in sRings)
		{
			let age = (float)(time - ring.start);
			if (age < 0 || age > 6)
				continue;
			let dx = x - ring.centre.x, dz = z - ring.centre.z;
			let distance = Math.Sqrt(dx * dx + dz * dz);
			let behind = age * 4 - distance;
			if (behind < 0 || behind > 7 || distance < 0.05f)
				continue;
			let strength = 0.55f * Math.Sin(Math.Min(behind, 3.14f)) * Math.Exp(-age * 0.5f);
			push += Vector3(dx / distance, 0, dz / distance) * strength;
		}
		return push;
	}

	/// The height of the surface above a spot right now.
	public float SurfaceAt(float x, float z, double time) => Transform.Position.y + size.y * 0.5f + Wave(x, z, time);

	// ---- how it is drawn: the still water below, and a sheet on top that moves with the swell ----

	const int cGrid = 24;
	Mesh mSheet ~ delete _;
	GameObject mBody, mSurface;
	/// How far below the resting surface the still part stops, so that the troughs do not show it.
	const float cSlack = 0.3f;

	public override void Start()
	{
		if (Session.Headless)
			return;
		let tint = Color(0.16f, 0.5f, 0.78f, 0.5f);
		mBody = Scene.CreateGameObject("Depths", Transform);
		mBody.Transient = true;
		let body = mBody.AddComponent<MeshRenderer>();
		body.color = tint;
		body.roughness = 0.15f;
		body.castShadows = false;
		mSurface = Scene.CreateGameObject("Surface", Transform);
		mSurface.Transient = true;
		let sheet = mSurface.AddComponent<MeshRenderer>();
		sheet.color = tint;
		sheet.roughness = 0.12f;
		sheet.metallic = 0.3f;
		sheet.castShadows = false;
		sheet.flatShading = false;
		mSheet = new Mesh();
		// A grid over the top, and a strip down from each edge to the still water.
		let white = Color.White;
		for (int z <= cGrid)
			for (int x <= cGrid)
				mSheet.AddVertex(.((float)x / cGrid - 0.5f, 0.5f, (float)z / cGrid - 0.5f), .Up, white);
		for (int z < cGrid)
		{
			for (int x < cGrid)
			{
				let a = (uint32)(z * (cGrid + 1) + x), b = a + 1, c = a + (uint32)cGrid + 1, d = c + 1;
				mSheet.AddTriangle(a, c, b);
				mSheet.AddTriangle(b, c, d);
			}
		}
		let skirt = (uint32)mSheet.Vertices.Count;
		for (int side < 4)
		{
			for (int i <= cGrid)
			{
				let along = (float)i / cGrid - 0.5f;
				Vector3 place = side == 0 ? .(along, 0.5f, -0.5f) : (side == 1 ? .(0.5f, 0.5f, along) : (side == 2 ? .(-along, 0.5f, 0.5f) : .(-0.5f, 0.5f, -along)));
				let outward = side == 0 ? Vector3(0, 0, -1) : (side == 1 ? Vector3(1, 0, 0) : (side == 2 ? Vector3(0, 0, 1) : Vector3(-1, 0, 0)));
				mSheet.AddVertex(place, outward, white);
				mSheet.AddVertex(place, outward, white);
			}
			for (int i < cGrid)
			{
				let top = skirt + (uint32)(side * (cGrid + 1) * 2 + i * 2);
				mSheet.AddTriangle(top, top + 1, top + 2);
				mSheet.AddTriangle(top + 2, top + 1, top + 3);
			}
		}
		mSheet.UploadDynamic();
		sheet.RuntimeMesh = mSheet;
	}

	public override void OnFrame()
	{
		if (mSheet == null || mBody == null || mBody.IsDestroyed)
			return;
		let depth = Math.Max(size.y, 0.5f);
		let slack = Math.Min(cSlack, depth * 0.5f) / depth;
		mBody.Transform.LocalPosition = .(0, -slack * 0.5f, 0);
		mBody.Transform.LocalScale = .(1, 1 - slack, 1);
		let time = Now(Scene);
		let world = Transform.LocalToWorld;
		float Height(float lx, float lz)
		{
			let p = world.TransformPoint(.(lx, 0, lz));
			return Wave(p.x, p.z, time) / depth;
		}
		let vertices = mSheet.Vertices;
		let step = 1.0f / cGrid;
		for (int z <= cGrid)
		{
			for (int x <= cGrid)
			{
				let lx = (float)x / cGrid - 0.5f, lz = (float)z / cGrid - 0.5f;
				let h = Height(lx, lz);
				// The slope either way gives the sheet its shading. Heights are in the box's own units: back to metres.
				let sx = (Height(lx + step, lz) - h) * depth / (step * Math.Max(size.x, 0.1f));
				let sz = (Height(lx, lz + step) - h) * depth / (step * Math.Max(size.z, 0.1f));
				var vertex = vertices[z * (cGrid + 1) + x];
				vertex.position.y = 0.5f + h;
				vertex.normal = Vector3(-sx, 1, -sz).Normalized;
				vertices[z * (cGrid + 1) + x] = vertex;
			}
		}
		let skirt = (cGrid + 1) * (cGrid + 1);
		for (int side < 4)
		{
			for (int i <= cGrid)
			{
				let index = skirt + side * (cGrid + 1) * 2 + i * 2;
				var top = vertices[index];
				top.position.y = 0.5f + Height(top.position.x, top.position.z);
				vertices[index] = top;
				var bottom = vertices[index + 1];
				bottom.position.y = 0.5f - slack;
				vertices[index + 1] = bottom;
			}
		}
		mSheet.UpdateDynamic();
	}

	/// The water a point is in, or null.
	public static WaterZone At(Vector3 point)
	{
		for (let zone in All)
		{
			if (zone.IsActiveAndEnabled && zone.Contains(point))
				return zone;
		}
		return null;
	}

	// ---- how the world looks from under it ----

	static bool sUnder;
	static Color sFogColor;
	static float sFogDensity;
	static GameObject sFogMap;
	/// True while the camera is below the surface of some water: the HUD tints the picture.
	public static bool CameraUnder => sUnder;

	/// Called every frame with where the camera is. Under water the fog closes in, thick and blue; back above
	/// it, the map's own air returns.
	public static void UpdateView(Scene scene, Vector3 camera)
	{
		let map = Match.Instance?.MapRoot;
		// A different map is in the world than when the camera went under: its air is already its own.
		if (sUnder && map != sFogMap)
			sUnder = false;
		let under = At(camera) != null;
		if (under == sUnder)
			return;
		if (under)
		{
			sFogColor = scene.Environment.fogColor;
			sFogDensity = scene.Environment.fogDensity;
			sFogMap = map;
			scene.Environment.fogColor = .(0.08f, 0.32f, 0.5f, 1);
			scene.Environment.fogDensity = 0.11f;
		}
		else
		{
			scene.Environment.fogColor = sFogColor;
			scene.Environment.fogDensity = sFogDensity;
		}
		sUnder = under;
	}
}

/// On a prop or a block lying loose in water: it floats. It rides the swell up and down, leans with the slope
/// of it, wanders a little, and is shoved outwards by rings passing under it. Like the water itself, where it
/// is depends only on the place it was put and the server's clock, so it is in the same place on every machine.
[Component]
class Floater : Component
{
	public WaterZone zone;
	public Vector3 home;
	public float homeYaw;
	/// How deep it sits, and how far apart the points are that its lean is taken from.
	public float draft = 0.3f, span = 0.6f;
	public float seed;
	public static bool Trace;
	static Floater sTraced;

	public override void OnDestroy()
	{
		if (sTraced == this)
			sTraced = null;
	}

	/// Puts it back exactly where it was placed (for the editor, which must not save where it has drifted to).
	public void GoHome()
	{
		Transform.Position = home;
		Transform.Rotation = Quaternion.Euler(0, homeYaw, 0);
	}

	public override void FixedUpdate()
	{
		if (zone == null || zone.GameObject.IsDestroyed)
			return;
		let time = WaterZone.Now(Scene);
		let t = (float)(time % 3600);
		// A slow wander round where it was left, and whatever the rings are doing to it.
		let push = WaterZone.Push(home.x, home.z, time);
		let x = home.x + 0.3f * Math.Sin(0.21f * t + seed) + push.x;
		let z = home.z + 0.3f * Math.Cos(0.17f * t + seed * 1.7f) + push.z;
		let level = zone.SurfaceAt(x, z, time);
		// It leans the way the water slopes under it.
		let pitch = Math.Atan2(WaterZone.Wave(x, z + span, time) - WaterZone.Wave(x, z - span, time), span * 2) * Mathf.Rad2Deg;
		let roll = Math.Atan2(WaterZone.Wave(x + span, z, time) - WaterZone.Wave(x - span, z, time), span * 2) * Mathf.Rad2Deg;
		Transform.Position = .(x, level - draft, z);
		// Test switch --floattest: one floater, the same one on every machine, says where it is twice a second.
		if (Trace)
		{
			if (sTraced == null || home.x + home.z * 1000 < sTraced.home.x + sTraced.home.z * 1000)
				sTraced = this;
			if (sTraced == this && Time.Tick % 30 == 0)
				Log.Info(scope $"floattest wall {DateTime.UtcNow.Ticks / 10000} tick {time * Time.TickRate:0.00} at {x:0.0000} {level - draft:0.0000} {z:0.0000}");
		}
		Transform.Rotation = Quaternion.Euler(-pitch * 1.5f, homeYaw + 6 * Math.Sin(0.13f * t + seed), roll * 1.5f);
	}
}

/// A place the hill can be in King of the Hill.
[Component]
class HillZone : Component
{
	public float radius = 4.5f;

	public bool Contains(Vector3 point)
	{
		let d = point - Transform.Position;
		return d.x * d.x + d.z * d.z <= radius * radius && d.y > -1.0f && d.y < 3.0f;
	}

	public override void OnDrawGizmos(bool selected)
	{
		Gizmos.Lines.Circle(Transform.Position + .(0, 0.1f, 0), .Up, radius, .(1, 0.8f, 0.2f, 1));
	}
}

/// A weapon lying on the map. Press Use beside it to swap it for the weapon in your hands; walking over one you
/// already carry tops up its ammunition. Once taken it comes back after a while.
[Component]
class WeaponPickup : Component
{
	public int32 weapon = 1;
	public float respawnSeconds = 25;

	/// Decided by the server and told to everyone.
	[NonSerialized] public bool Available = true;
	[NonSerialized] public int32 RespawnTicks;
	GameObject mModel, mPad;
	MeshRenderer mPadRenderer;
	int32 mShown = -1;

	public override void Start()
	{
		if (Application.Instance != null && Application.Instance.Headless)
			return;
		mPad = Scene.CreateGameObject("Pad", Transform);
		mPad.Transient = true;
		mPad.Transform.LocalPosition = .(0, 0.03f, 0);
		mPad.Transform.LocalScale = .(1.1f, 0.03f, 1.1f);
		mPadRenderer = mPad.AddComponent<MeshRenderer>();
		mPadRenderer.mesh.Set("builtin:cylinder");
		mPadRenderer.castShadows = false;
		mPadRenderer.flatShading = false;
		mModel = Scene.CreateGameObject("Weapon", Transform);
		mModel.Transient = true;
		let renderer = mModel.AddComponent<MeshRenderer>();
		renderer.metallic = 0.25f;
		renderer.roughness = 0.65f;
	}

	public override void Update()
	{
		if (mModel == null)
			return;
		if (mShown != weapon)
		{
			mShown = weapon;
			WorldWeaponVisual.Apply(mModel.GetComponent<MeshRenderer>(), weapon);
		}
		mModel.SetActive(Available);
		// Turning slowly and bobbing, so that it catches the eye.
		mModel.Transform.LocalPosition = .(0, 0.75f + Math.Sin(Time.RealTime * 2 + Transform.Position.x) * 0.06f, 0);
		mModel.Transform.LocalRotation = Quaternion.Euler(-8, Time.RealTime * 70, 0);
		let glow = Available ? Palette.Hud : Color(0.3f, 0.35f, 0.4f, 1);
		mPadRenderer.color = glow;
		mPadRenderer.emissive = glow;
		mPadRenderer.emissiveIntensity = Available ? 1.5f + 0.5f * Math.Sin(Time.RealTime * 4) : 0;
	}
}

/// A waypoint for bots. The links between waypoints are worked out when the map loads.
[Component]
class NavNode : Component
{
	public override void OnDrawGizmos(bool selected)
	{
		Gizmos.Lines.Circle(Transform.Position + .(0, 0.05f, 0), .Up, 0.25f, .(0.3f, 1, 0.5f, 0.6f), 8);
	}
}

/// The waypoint graph of the loaded map: which waypoints a bot can walk between, and routes across it.
static class NavGraph
{
	public static List<Vector3> Nodes = new .() ~ delete _;
	public static List<List<int32>> Links = new .() ~ DeleteContainerAndItems!(_);
	public static bool Ready;
	/// Changes whenever the waypoints do, so that routes planned on the old ones can be thrown away.
	public static int32 Version;

	public static void Clear()
	{
		Version++;
		Nodes.Clear();
		ClearAndDeleteItems!(Links);
		Ready = false;
	}

	/// Links every pair of nearby waypoints that has clear air and continuous floor between them.
	public static void Build(Scene scene, GameObject mapRoot)
	{
		Clear();
		if (mapRoot == null)
			return;
		for (let child in mapRoot.Transform.Children)
		{
			if (child.GameObject.GetComponent<NavNode>() != null)
			{
				Nodes.Add(child.Position);
				Links.Add(new .());
			}
		}
		int linkCount = 0;
		for (int32 i = 0; i < Nodes.Count; i++)
		{
			for (int32 j = i + 1; j < Nodes.Count; j++)
			{
				let a = Nodes[i], b = Nodes[j];
				let dx = b.x - a.x, dz = b.z - a.z;
				let flat = dx * dx + dz * dz;
				if (flat > 5.5f * 5.5f || Math.Abs(b.y - a.y) > 1.5f)
					continue;
				if (!Walkable(scene, a, b))
					continue;
				Links[i].Add(j);
				Links[j].Add(i);
				linkCount++;
			}
		}
		Ready = Nodes.Count > 0;
		Log.Info(scope $"Navigation: {Nodes.Count} waypoints, {linkCount} links.");
	}

	static bool Walkable(Scene scene, Vector3 a, Vector3 b)
	{
		let up = Vector3(0, 1.0f, 0);
		ShapeCastHit hit;
		let delta = (b + up) - (a + up);
		let length = delta.Length;
		if (length > 0.01f && scene.Physics.SphereCast(a + up, 0.3f, delta, length, out hit))
		{
			// Somebody standing in the way does not make it a wall.
			if (hit.gameObject == null || hit.gameObject.GetComponent<Player>() == null)
				return false;
		}
		for (int step = 1; step < 4; step++)
		{
			let point = Vector3.Lerp(a, b, step / 4.0f);
			RaycastHit ground;
			if (!scene.Physics.Raycast(point + up, .Down, 2.4f, out ground))
				return false;
			if (Math.Abs(ground.point.y - point.y) > 0.75f)
				return false;
		}
		return true;
	}

	public static int32 Nearest(Vector3 point)
	{
		int32 best = -1;
		float bestDistance = float.MaxValue;
		for (int32 i = 0; i < Nodes.Count; i++)
		{
			let d = Nodes[i] - point;
			// Height counts double, so a waypoint on the floor above is not mistaken for a near one.
			let distance = d.x * d.x + d.z * d.z + d.y * d.y * 4;
			if (distance < bestDistance)
			{
				bestDistance = distance;
				best = i;
			}
		}
		return best;
	}

	/// Shortest route between two waypoints (A*). The path is filled start to goal; false if there is none.
	public static bool FindPath(int32 start, int32 goal, List<int32> path)
	{
		path.Clear();
		if (start < 0 || goal < 0 || start >= Nodes.Count || goal >= Nodes.Count)
			return false;
		let count = Nodes.Count;
		float[] cost = scope .[count];
		int32[] from = scope .[count];
		bool[] closed = scope .[count];
		for (int i < count)
		{
			cost[i] = float.MaxValue;
			from[i] = -1;
		}
		List<int32> open = scope .();
		cost[start] = 0;
		open.Add(start);
		while (open.Count > 0)
		{
			int bestIndex = 0;
			float bestScore = float.MaxValue;
			for (int i < open.Count)
			{
				let score = cost[open[i]] + (Nodes[open[i]] - Nodes[goal]).Length;
				if (score < bestScore)
				{
					bestScore = score;
					bestIndex = i;
				}
			}
			let current = open[bestIndex];
			open.RemoveAtFast(bestIndex);
			if (current == goal)
				break;
			closed[current] = true;
			for (let next in Links[current])
			{
				if (closed[next])
					continue;
				let total = cost[current] + (Nodes[next] - Nodes[current]).Length;
				if (total < cost[next])
				{
					if (cost[next] == float.MaxValue)
						open.Add(next);
					cost[next] = total;
					from[next] = current;
				}
			}
		}
		if (from[goal] < 0 && goal != start)
			return false;
		var at = goal;
		while (at >= 0)
		{
			path.Add(at);
			at = from[at];
		}
		for (int i = 0, j = path.Count - 1; i < j; i++, j--)
			Swap!(path[i], path[j]);
		return true;
	}
}
