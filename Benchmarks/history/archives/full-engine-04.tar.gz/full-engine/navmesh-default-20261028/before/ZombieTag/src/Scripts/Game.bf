using System;
using System.Collections;
using System.IO;
using Tessera;
namespace ZombieTag;

[Component]
class Game : Component
{
 public static Game Instance;
 public Camera camera;
 public bool menu = true;
 public bool ready;
 bool mPractice;
 public String teamDetails = new .() ~ delete _;
 public String selectedPlayer = new .() ~ delete _;
 public String inviteId = new .() ~ delete _;
 public float fieldOfView = 80;
 public float sensitivity = 0.15f;
 int32 mPlayerSlot;
 uint32 mRandom = 1234567;
 [Sync] public bool randomTeams = true;
 [Sync] public bool randomZombieCount;
 uint32 NextRandom() { mRandom = mRandom * 1664525 + 1013904223; return mRandom; }
 public Vector3 KeyPosition(int32 index)
 {
  if (mHouse == null) return .Zero;
  return mHouse.RandomKeyPosition(index, keyRoll);
 }
 int32 mPreviousKeySite = -1;
 void RerollKey()
 {
  mRandom ^= (uint32)Time.Tick;
  // Exclude the previous room rather than relying on chance to avoid a repeat.
  let choices = mPreviousKeySite < 0 ? 8 : 7;
  keySite = (int32)(NextRandom() % (uint32)choices);
  if (mPreviousKeySite >= 0 && keySite >= mPreviousKeySite) keySite++;
  mPreviousKeySite = keySite;
  keyRoll = (int32)(NextRandom() & 0x7FFFFFFF);
 }
 void EnsureHouse()
 {
  if (mBuilt == seed) return;
  if (mHouse == null) mHouse = new House(Scene, seed); else mHouse.Rebuild(seed);
  mBuilt = seed;
 }
 public bool PlaceNewPlayer(Player player)
 {
  if (!Authority) return false; EnsureHouse();
  List<Vector3> occupied = scope .(); List<Vector3> enemies = scope .();
  for (let other in Player.All)
  {
   if (other == player || other.escaped) continue;
   occupied.Add(other.Transform.Position);
   if (phase == 1 && !other.zombie) enemies.Add(other.Transform.Position);
  }
  Vector3 at;
  if (!mHouse.ChooseSpawn(phase == 1, phase == 1, occupied, enemies, out at)) { player.escaped = true; player.GetComponent<CharacterController>().Enabled = false; return false; }
  player.GetComponent<CharacterController>().Enabled = true; player.GetComponent<CharacterController>().Teleport(at, .Zero, 0); player.escaped = false; return true;
 }
 bool PlaceTeams()
 {
  EnsureHouse();
  List<Vector3> occupied = scope .(); List<Vector3> humans = scope .(); List<Vector3> none = scope .();
  for (int32 team < 2) for (let player in Player.All)
  {
   if (player.zombie != (team == 1)) continue;
   Vector3 at;
   if (!mHouse.ChooseSpawn(player.zombie, false, occupied, player.zombie ? humans : none, out at)) return false;
   player.GetComponent<CharacterController>().Enabled = true; player.GetComponent<CharacterController>().Teleport(at, .Zero, 0); occupied.Add(at); if (!player.zombie) humans.Add(at);
  }
  return true;
 }
 public Vector3 ConstrainMovement(Vector3 from, Vector3 velocity, float dt) => mHouse != null ? mHouse.Constrain(from, velocity, dt) : velocity;
 public Vector3 ExitPosition => mHouse != null ? mHouse.exit : .Zero;
 public bool BotCanSee(Vector3 from, Vector3 to) => mHouse != null && !mHouse.AttackBlocked(from + .(0, 1.2f, 0), to + .(0, 1.2f, 0));
 public bool BotRoute(Vector3 from, Vector3 to, List<Vector3> path) => mHouse != null && mHouse.BotRoute(from, to, path);

 public int32 selection;
 bool mPreviewZombie;
 GameObject mPreview, mPreviewLight;
 SkinnedMeshRenderer mPreviewSkin;
 int32 mPreviewShown = -1;
 void UpdatePreview()
 {
  if (Application.Instance.Headless) return;
  if (mPreview == null)
  {
   mPreview = Scene.CreateGameObject("Selection Preview"); mPreview.Transient = true;
   mPreview.Transform.Position = .(30, 0, 0); mPreview.Transform.Rotation = Quaternion.Euler(0, 0, 0);
   mPreview.AddComponent<MeshRenderer>(); mPreviewSkin = mPreview.AddComponent<SkinnedMeshRenderer>();
   mPreviewLight = Scene.CreateGameObject("Selection Studio Light"); mPreviewLight.Transient = true; mPreviewLight.Transform.Position = .(28, 2.8f, -3);
   let light = mPreviewLight.AddComponent<Light>(); light.type = .Point; light.range = 10; light.intensity = 6; light.color = .(0.9f, 0.95f, 0.8f);
  }
  mPreview.SetActive(UsesPreview); mPreviewLight.SetActive(UsesPreview);
  if (!UsesPreview) return;
  camera.Transform.Position = .(28.5f, 1.15f, -3.8f); camera.Transform.Rotation = .Identity;
  Scene.Environment.ambientIntensity = 0.4f; Scene.Environment.exposure = 1; Scene.Environment.colorFilter = .White;
  let chosen = selection * 2 + (mPreviewZombie ? 1 : 0);
  if (mPreviewShown != chosen) { mPreviewShown = chosen; mPreviewSkin.model.Set(scope $"Models/{(mPreviewZombie ? "zombie" : "human")}_{selection}.glb"); mPreviewSkin.OnValidate(); }
  mPreviewSkin.Play("Idle");
 }
 public void OnPreviewZombie() { mPreviewZombie = !mPreviewZombie; }

 public String portText = new .("27841") ~ delete _;
 uint16 Port => (uint16)Math.Clamp(SceneSerializer.ParseInt(portText), 1024, 65535);
 public String address = new .("127.0.0.1") ~ delete _;
 public String notice = new .() ~ delete _;
 public String profile = new .() ~ delete _;
 public String details = new .() ~ delete _;
 public String hud = new .() ~ delete _;
 public String roster = new .() ~ delete _;
 public String rules = new .() ~ delete _;
 public String friends = new .() ~ delete _;
 [Sync] public int32 phase; // 0 lobby, 1 playing, 2 humans won, 3 zombies won
 [Sync] public int32 seed;
 [Sync] public int32 initialZombies = 1;
 [Sync] public int32 keySite;
 [Sync] public int32 keyRoll;
 [Sync] public int32 keySize;
 [Sync] public float infectionDelay = 3;
 public float KeyScale => keySize == 2 ? 0.52f : (keySize == 1 ? 0.42f : 0.32f);
 [Sync] public int32 keyOwner = -1;
 [Sync] public float seconds = 300;
 [Sync] public int32 round;
 [Sync] public int32 escapedCount;
 House mHouse ~ delete _;
 int32 mBuilt = -1;
 float mEndWait, mPresence;
 GameObject mKey;
 UIDocument mMenu, mHud, mChrome;
 bool mDisconnect;
 public bool Authority => Scene.Network != null && Scene.Network.IsServer;
 public bool Connected => Scene.Network != null && Scene.Network.Mode != .Offline;
 public override void Awake() { Instance = this; }
 public override void OnDestroy() { HouseVoice.Shutdown(); Steam.ClearPresence(); if (Instance == this) Instance = null; }
 public override void Start()
 {
  camera = Scene.Cameras[0];
  if (!Application.Instance.Headless)
  {
   let iconPath = scope String(); Environment.GetExecutableFilePath(iconPath);
   let slash = Math.Max(iconPath.LastIndexOf('/'), iconPath.LastIndexOf('\\'));
   if (slash >= 0) iconPath.RemoveToEnd(slash + 1); else iconPath.Clear(); iconPath.Append("icon.png");
   if (!Application.Instance.SetWindowIcon(iconPath)) Application.Instance.SetWindowIcon("src/icon.png");
  }
  mMenu = GetComponent<UIDocument>(); InitializeMenus(); InitializeAudio();
  mHud = GameObject.AddComponent<UIDocument>(); mHud.document.Set("UI/hud.tui"); mHud.referenceHeight = 1080; mHud.referenceWidth = 1920;
  mChrome = GameObject.AddComponent<UIDocument>(); mChrome.document.Set("UI/chrome.tui"); mChrome.referenceHeight = 1080; mChrome.referenceWidth = 1920;
  NetworkManager.RegisterMessage(1, new => ReceiveProfile);
  NetworkManager.RegisterMessage(2, new => ReceiveStart);
  if (!Application.Instance.HasArg("--direct") && !Application.Instance.Headless) Steam.Start();
  let app = Application.Instance; let arg = scope String();
  if (app.HasArg("--voice-device-test")) { voiceEnabled = true; voicePushToTalk = false; masterVolume = 1; musicVolume = 0; effectsVolume = 0; ambienceVolume = 0; voiceVolume = 1; ApplyAudioVolumes(); }
  if (app.GetArg("--port", arg)) portText.Set(arg);
  if (app.GetArg("--test-seconds", arg)) mTestLimit = Math.Max(1, SceneSerializer.ParseInt(arg));
  if (app.GetArg("--character", arg)) selection = Math.Clamp(SceneSerializer.ParseInt(arg), 0, 18);
  if (app.HasArg("--net-test") && !app.HasArg("--server")) { flashlightBrightness = 3 + selection * 0.25f; flashlightBeam = 35 + selection; }
  if (app.GetArg("--zombies", arg)) initialZombies = Math.Clamp(SceneSerializer.ParseInt(arg), 1, 7);
  if (app.GetArg("--seed", arg)) seed = Math.Max(0, SceneSerializer.ParseInt(arg));
  if (app.GetArg("--preview", arg))
  {
   if (arg == "players") { Host(false, true); AddBot(1); AddBot(2); OnPlayers(); }
   if (arg == "join") { mInvitingFriends = false; OpenPage(.Join); }
   if (arg == "friends") { mInvitingFriends = true; OpenPage(.Join); }
   if (arg == "character") OpenPage(.Character);
   if (arg == "settings") OpenPage(.Settings);
   if (arg == "rules") OpenPage(.Rules);
   if (arg == "traits") { Host(false, true); OpenPage(.Traits); }
   if (arg == "help") OpenPage(.Help);
   if (arg == "pause") OpenPage(.Pause);
   if (arg == "lobby") { Host(false, true); AddBot(1); AddBot(2); }
   if (arg == "hallway" || arg == "tv" || arg == "desk" || arg == "frame" || arg == "frame-back" || arg == "house" || arg == "furnished" || arg == "regenerated" || arg == "obstruction" || arg == "kitchen" || arg == "dining" || arg == "bedroom" || arg == "bathroom" || arg == "study")
   {
    menu = false; mRebuildPreview = arg == "regenerated" || arg == "obstruction"; mAuditHall = arg == "obstruction";
    if (arg == "hallway" || arg == "tv" || arg == "desk" || arg == "frame" || arg == "frame-back" || arg == "furnished" || arg == "regenerated" || arg == "obstruction" || arg == "kitchen" || arg == "dining" || arg == "bedroom" || arg == "bathroom" || arg == "study")
    {
     mInspectionFocus = arg == "tv" ? 1 : (arg == "desk" ? 2 : (arg == "frame" ? 3 : (arg == "frame-back" ? 4 : 0)));
     mInspectionRoom = arg == "kitchen" ? 2 : (arg == "dining" ? 1 : (arg == "bedroom" ? 4 : (arg == "bathroom" ? 5 : (arg == "study" ? 3 : 0))));
     if (arg == "obstruction" || arg == "hallway") mInspectionRoom = -1;
     camera.Transform.Position = .(-5.7f, 1.65f, -10.1f); camera.Transform.Rotation = Quaternion.Euler(12, 190, 0);
     Scene.Environment.ambientIntensity = 1.8f; Scene.Environment.exposure = 1.4f; Scene.Environment.fogDensity = 0;
     if (arg == "hallway") { camera.Transform.Position = .(0, 1.64f, -13); camera.Transform.Rotation = .Identity; }
     if (arg == "obstruction") { camera.Transform.Position = .(0, 1.64f, -10); camera.Transform.Rotation = .Identity; }
     if (arg == "kitchen") { camera.Transform.Position = .(-6.25f, 1.64f, 4.7f); camera.Transform.Rotation = Quaternion.Euler(10, 180, 0); }
     if (arg == "dining") { camera.Transform.Position = .(-6.25f, 1.64f, -2.3f); camera.Transform.Rotation = Quaternion.Euler(10, 180, 0); }
     if (arg == "bedroom") { camera.Transform.Position = .(6.25f, 1.64f, -9.8f); camera.Transform.Rotation = Quaternion.Euler(10, 180, 0); }
     if (arg == "bathroom") { camera.Transform.Position = .(6.25f, 1.64f, -3); camera.Transform.Rotation = Quaternion.Euler(10, 180, 0); }
     if (arg == "study") { camera.Transform.Position = .(-6.25f, 1.64f, 12); camera.Transform.Rotation = Quaternion.Euler(10, 180, 0); }
     let studio = Scene.CreateGameObject("Inspection light"); studio.Transient = true; studio.Transform.Position = .(-6.25f, 2.5f, -11.25f);
     let light = studio.AddComponent<Light>(); light.type = .Point; light.intensity = 6; light.range = 12;
    }
   }
   if (arg == "human" || arg == "zombie" || arg == "key-found" || arg == "key-found-zombie" || arg == "tag" || arg == "tag-remote" || arg == "exit-guide" || arg == "key-test" || arg == "infection" || arg == "bat" || arg == "bat-swing" || arg == "feet")
   {
    mPreviewFeet = arg == "feet"; if (mPreviewFeet) arg.Set("bat"); mPreviewBat = arg.StartsWith("bat"); mPreviewBatSwing = arg == "bat-swing"; if (mPreviewBat) { arg.Set("tag-remote"); batEnabled = true; } mPreviewMode = arg == "human" || arg == "key-found" || arg == "tag-remote" || arg == "exit-guide" || arg == "key-test" || arg == "infection" ? 1 : 2; mPreviewTag = arg == "tag" || arg == "tag-remote"; mPreviewTagRemote = arg == "tag-remote"; mPreviewExit = arg == "exit-guide"; mPreviewPickup = arg.StartsWith("key-found") || mPreviewExit; mPreviewKeyTest = arg == "key-test"; mPreviewInfection = arg == "infection"; Host(false, true); }
  }
  if (app.HasArg("--practice")) OnPractice();
  if (app.HasArg("--host") || app.HasArg("--server")) Host(app.HasArg("--server"), app.HasArg("--direct"));
  else if (app.GetArg("--connect", arg)) { address.Set(arg); OnJoin(); }
 }
 public override void Update()
 {
  UpdateVoice();
  if (phase != mObservedPhase) { if (phase == 1) { menu = false; if (!Application.Instance.Headless) Audio.PlayOneShot2D("Audio/door.wav"); } if (phase == 0 && Connected && (Authority || Scene.Network.IsConnected)) { OpenPage(.Lobby); ready = false; } mObservedPhase = phase; }
  if (Application.Instance.HasArg("--voice-device-test")) RunVoiceDeviceTest();
  if (Application.Instance.HasArg("--menu-test")) RunMenuTest();
  if (Application.Instance.HasArg("--net-test")) RunNetworkTest();
  EnsureHouse();
  if (mRebuildPreview && Time.FrameCount > 10) { mRebuildPreview = false; seed = 123; EnsureHouse(); }
  if (mInspectionRoom >= 0 && !mInspectionPlaced && (!mRebuildPreview || Time.FrameCount > 12))
  {
   mInspectionPlaced = true;
   if (mInspectionFocus == 1 || mInspectionFocus == 2)
    for (int32 room < 8) if (mHouse.plan.rooms[room] == .Living) { mInspectionRoom = room; break; }
   let i = mInspectionRoom;
   camera.Transform.Position = .(i < 4 ? -House.HallHalf - mHouse.plan.widths[i] * 0.5f : House.HallHalf + mHouse.plan.widths[i] * 0.5f, 1.64f,
    mHouse.plan.starts[i] + Math.Min(mHouse.plan.depths[i] - 0.9f, 5.2f));
   camera.Transform.Rotation = Quaternion.Euler(12, 185, 0);
   if (mInspectionFocus > 0)
   {
    bool found = false;
    for (let ob in Scene.Objects)
    {
     let desired = mInspectionFocus == 1 ? "tv" : (mInspectionFocus == 2 ? "desk" : "art");
     if (ob.Name != desired || ob.GetComponent<MeshRenderer>()?.IsActiveAndEnabled != true) continue;
     let at = ob.Transform.Position;
     if (mInspectionFocus == 2 && (at.z < mHouse.plan.starts[i] || at.z > mHouse.plan.starts[i] + mHouse.plan.depths[i] || (i < 4 ? at.x > -House.HallHalf : at.x < House.HallHalf))) continue;
     let facing = ob.Transform.Rotation * Quaternion.Euler(0, mInspectionFocus == 4 ? 180 : 0, 0);
     let offset = mInspectionFocus >= 3 ? Vector3(0, 0.12f, -0.65f) : (mInspectionFocus == 1 ? Vector3(0.5f, 1.0f, -4.0f) : Vector3(1.4f, 1.64f, -2.2f));
     camera.Transform.Position = at + facing * offset;
     camera.Transform.Rotation = facing * Quaternion.Euler(mInspectionFocus >= 3 ? 0 : 10, mInspectionFocus == 2 ? -30 : 0, 0);
     Log.Info(scope $"INSPECT {desired} seed={seed} position={at} front={ob.Transform.Rotation * Vector3(0, 0, -1)}"); found = true; break;
    }
    if (!found) Log.Info(scope $"INSPECT no {mInspectionFocus} target fits this room seed={seed}");
   }
   for (let ob in Scene.Objects) if (ob.Name == "Inspection light") ob.Transform.Position = camera.Transform.Position + Vector3(0, 0.8f, -1.0f);
  }
  if (mAuditHall && Time.FrameCount > 20) { mAuditHall = false; mHouse.AuditHall(); }
  let exportPath = scope String();
  if (!mExported && Application.Instance.GetArg("--export-house", exportPath))
  {
   mExported = true;
   for (let ob in Scene.Objects) if (ob == mHouse.root || ob.Transform.Parent == mHouse.root.Transform) ob.Transient = false;
   Check(Prefab.Save(mHouse.root, exportPath), "fixed house exported to editable prefab");
   for (let ob in Scene.Objects) if (ob == mHouse.root || ob.Transform.Parent == mHouse.root.Transform) ob.Transient = true;
   Application.Instance.Running = false;
  }
  if (Application.Instance.HasArg("--selftest") && !mTested && Time.FrameCount > 5) { mTested = true; RunSelfTest(); }
  if (mPreviewMode > 0 && !mPreviewStarted && Time.FrameCount > 10)
  {
   mPreviewStarted = true; AddBot(2); for (let p in Player.All) p.ready = true; OnStart();
   for (let p in Player.All) { if (!p.bot) { p.zombie = mPreviewMode == 2; p.Transform.Position = .(0, 0.1f, -10); } else { p.zombie = mPreviewMode == 1; p.Transform.Position = .(-4.5f, 0.1f, -5); } }
   if (mPreviewTag) for (let p in Player.All)
   {
    if (p.bot) { p.Transform.Position = .(0, 0.1f, -8.5f); p.Transform.Rotation = Quaternion.Euler(0, 180, 0); }
   }
   if (mPreviewExit) for (let p in Player.All) if (!p.bot) p.Yaw = 180;
   if (mPreviewFeet) for (let p in Player.All) if (!p.bot) p.Pitch = 80;
   if (mPreviewBat) for (let p in Player.All) if (p.bot) { p.zombie = false; p.Transform.Position = .(0.15f, 0.1f, -8.2f); }
   if (mPreviewKeyTest) OnToggleKeyHighlight();
   if (mPreviewInfection) for (let p in Player.All) if (!p.bot) p.BeginInfection(10);
   if (mPreviewPickup) for (let p in Player.All) if (!p.zombie) { keyOwner = (int32)p.Identity.NetId; break; }
  }
  if (mPreviewBatSwing && Time.FrameCount == 52) for (let p in Player.All) if (!p.zombie) p.TrySwing(.Forward);
  if (mPreviewTag && Time.FrameCount == 52) for (let p in Player.All) if (p.zombie) p.TryTag(mPreviewTagRemote ? Vector3(0, 0, -1) : Vector3.Forward);
  if (mPreviewTag && Time.FrameCount == 59) for (let p in Player.All) if (p.zombie) Log.Info(scope $"TAG VISUAL / sequence={p.tagSequence} armBound={p.TagArmBound} hand={p.TagHandPosition} camera={camera.Transform.Position}");
  if (mKey == null)
  {
   mKey = Scene.CreateGameObject("House key"); mKey.Transient = true;
   for (int32 part < 4)
   {
    let piece = Scene.CreateGameObject("Key part", mKey.Transform); piece.Transient = true;
    let mr = piece.AddComponent<MeshRenderer>(); mr.mesh.Set(part == 0 ? "builtin:sphere" : "builtin:cube"); mr.color = .(1, 0.7f, 0.12f); mr.metallic = 0.7f; mr.emissive = .(0.3f, 0.14f, 0.01f); mr.emissiveIntensity = 0;
    piece.Transform.LocalPosition = part == 0 ? .(-0.07f, 0, 0) : (part == 1 ? .(0.035f, 0, 0) : .(0.06f + (part - 2) * 0.05f, 0, 0.035f));
    piece.Transform.LocalScale = part == 0 ? .(0.10f, 0.025f, 0.10f) : (part == 1 ? .(0.17f, 0.025f, 0.025f) : .(0.025f, 0.025f, 0.07f));
   }
  }
  mKey.Transform.LocalScale = .(KeyScale, KeyScale, KeyScale);
  mKey.Transform.Position = KeyPosition(Math.Clamp(keySite, 0, 7)); mKey.SetActive(phase == 1 && keyOwner < 0);
  if (Input.GetKeyDown(.F8)) OnToggleKeyHighlight();
  if (Input.GetKeyDown(.Escape) || InputActions.Pressed("Pause")) EscapeMenu();
  UpdatePreview();
  mChrome.Enabled = menu;
  mMenu.Enabled = menu; mHud.Enabled = Connected && !menu;
  Input.LockCursor = Connected && !menu;
  if (Steam.IsReady) Steam.Update();
  camera.fieldOfView = UsesPreview ? 50 : fieldOfView;
  if (Player.Local != null) Player.Local.mouseSensitivity = sensitivity;
  let join = scope String(); if (Steam.TakeJoinRequest(join)) { if (Connected) OnLeave(); address.Set(join); OnJoin(); }
  if (Connected && Scene.Network.Mode == .Client && !Scene.Network.IsConnected)
  {
   if (mDisconnect) { notice.Set("The host closed the room. Leave this session to reconnect."); if (mPage != .Confirm) OpenPage(.Pause); }
  }
  else if (Connected) mDisconnect = true;
  if (Authority)
  {
   if (phase == 1)
   {
    if (!mPractice) seconds -= Time.DeltaTime;
    int32 humans = 0; bool carrier = false;
    for (let p in Player.All)
    {
     if (!p.zombie && !p.escaped) humans++;
     if (p.Identity != null && (int32)p.Identity.NetId == keyOwner && !p.zombie && !p.escaped) carrier = true;
    }
    if (keyOwner >= 0 && !carrier) keyOwner = -1;
    if (humans == 0 || seconds <= 0) End(escapedCount > 0 ? 2 : 3);
   }
   else if (phase >= 2) { mEndWait -= Time.DeltaTime; if (mEndWait <= 0) { phase = 0; for (let p in Player.All) { p.ready = p.bot; p.escaped = false; p.zombie = false; p.ClearInfection(); } } }
  }
  mPresence -= Time.DeltaTime;
  if (mPresence <= 0)
  {
   mPresence = 3;
   if (Authority && Scene.Network.Transport == .Steam) { Steam.SetPresence("connect", scope $"{Steam.UserId}"); Steam.SetPresence("zombie_tag_room", scope $"{Steam.UserId}"); Steam.SetPresence("status", "Zombie Tag - Blackwood House"); }
   friends.Set("FRIENDS / ");
   for (int i < Steam.FriendCount)
   {
    let id = Steam.FriendAt(i); let host = scope String(); Steam.FriendPresence(id, "connect", host);
    if (!host.IsEmpty) { let name = scope String(); Steam.FriendName(id, name); friends.AppendF("{} ({})  ", name, host); }
   }
  }
  profile.Set(scope $"CHARACTER  {selection + 1}/19  /  {CharacterName(selection)}");
  rules.Set(scope $"{(seed == 0 ? "BLACKWOOD / FIXED TEST HOUSE" : "PROCEDURAL HOUSE")}   |   SEED {seed}   |   {initialZombies} STARTING ZOMBIE(S)");
  roster.Clear();
  for (int i < Player.All.Count) { let player = Player.All[i]; roster.AppendF("{} {}{} / {} / {}\n", i == mPlayerSlot ? ">" : " ", CharacterName(player.character), player.bot ? " [NPC]" : "", player.ready ? "READY" : "NOT READY", player.assignedTeam == 2 ? "ZOMBIE" : (player.assignedTeam == 1 ? "HUMAN" : "AUTO")); }
  selectedPlayer.Set(Selected != null ? CharacterName(Selected.character) : "NO PLAYERS");
  teamDetails.Set(scope $"TEAMS / {(randomTeams ? "RANDOM AT START" : "HOST ASSIGNED")}   |   ZOMBIE COUNT / {(randomZombieCount ? "RANDOM" : "FIXED")}");
  details.Set(Connected ? (Authority ? "HOST / Ready up, then start the round." : "CONNECTED / Choose a character and ready up.") : "STEAM / Host and share your Steam ID, or enter a friend's ID below.");
  UpdateMenuBindings();
  UpdateGameHud(); UpdateAudio();
 }
 public static StringView CharacterName(int32 i)
 {
  StringView[19] names = .("Biker", "Fast Food Guy", "Firefighter", "Gamer Girl", "Gangster", "Grandma", "Grandpa", "Hipster Girl", "Hipster Guy", "Hobo", "Hotdog", "Jock", "Paramedic", "Punk Girl", "Punk Guy", "Roadworker", "Shopkeeper", "Summer Girl", "Tourist");
  return names[Math.Clamp(i, 0, 18)];
 }
 public void Host(bool dedicated = false, bool direct = false)
 {
  if (Connected) return;
  let net = new NetworkManager(Scene); Scene.Network = net; net.PlayerPrefab.Set("Player");
  net.Transport = (!direct && Steam.IsReady) ? .Steam : .Direct;
  if (!net.StartServer(Port, !dedicated)) { notice.Set("Could not host. Check Steam or use Direct Host."); Scene.Network = null; delete net; return; }
  mObservedPhase = phase;
  if (!dedicated) OpenPage(.Lobby);
  notice.Set(net.Transport == .Steam ? "Lobby created. Invite your Steam friends." : "Local session ready.");
 }
 public void OnHost() { Host(); }
 public void OnDirectHost() { Host(false, true); }
 public void OnJoin()
 {
  if (Connected) { notice.Set("Leave the current room before joining another."); return; }
  let net = new NetworkManager(Scene); Scene.Network = net; net.PlayerPrefab.Set("Player");
  net.Transport = (address.Length >= 16 && !address.Contains('.')) ? .Steam : .Direct;
  if (!net.StartClient(address, Port)) { notice.Set("Could not connect. Check address and Steam."); Scene.Network = null; delete net; return; }
  notice.Set("Connecting to the house..."); mDisconnect = false; mConnectTime = 0; OpenPage(.Connecting);
 }
 public void OnLeave()
 {
  HouseVoice.Shutdown(); mPractice = false;
  let net = Scene.Network;
  if (net != null) { net.Stop(); Scene.Network = null; for (let player in Player.All) Scene.Destroy(player.GameObject); delete net; }
  Steam.ClearPresence(); phase = 0; ready = false; menu = true; mDisconnect = false; notice.Clear(); OpenPage(.Main);
 }
 public void OnPrevious() { selection = (selection + 18) % 19; SendProfile(); }
 public void OnNext() { selection = (selection + 1) % 19; SendProfile(); }
 public void OnReady() { ready = !ready; SendProfile(); }
 public void SendProfile()
 {
  if (!Connected) return;
  let writer = scope NetWriter(); writer.Write((int32)selection); writer.Write((uint8)(ready ? 1 : 0)); writer.Write(flashlightBrightness); writer.Write(flashlightBeam); Scene.Network.SendToServer(1, writer);
 }
 static void ReceiveProfile(int32 sender, ref NetReader reader)
 {
  let index = reader.Read<int32>(); let ready = reader.Read<uint8>() != 0; let brightness = reader.Read<float>(); let beam = reader.Read<float>();
  if (!reader.Ok || Instance == null || !Instance.Authority ) return;
  for (let p in Player.All) if (!p.bot && p.Identity != null && p.Identity.ownerId == sender) { p.flashlightBrightness = brightness.IsFinite ? Math.Clamp(brightness, 2, 14) : 7; p.flashlightBeam = beam.IsFinite ? Math.Clamp(beam, 25, 75) : 48; if (Instance.phase == 0 || !p.profileSet) { p.character = Math.Clamp(index, 0, 18); p.ready = ready; p.profileSet = true; } }
 }
 static void ReceiveStart(int32 sender, ref NetReader reader) { /* Clients cannot start rounds. */ }
 public void OnFixed() { if (!Connected || (Authority && phase == 0)) seed = 0; }
 static int32 NextSeed(int32 value) => (int32)(((int64)value * 7919 + 104729) % 1000000) + 1;
 public void OnGenerate() { if (!Connected || (Authority && phase == 0)) seed = NextSeed(seed); }
 public void OnMoreZombies() { if (!Connected || (Authority && phase == 0)) initialZombies = initialZombies % 15 + 1; }
 public void OnStart()
 {
  if (!Authority || phase != 0) return;
  if (Player.All.Count < 2) { notice.Set("At least two players are required."); return; }
  for (let p in Player.All) if (!p.ready) { notice.Set("Every player must ready up."); return; }
  if (!randomZombieCount && initialZombies >= Player.All.Count) { notice.Set("Keep at least one human. Lower the zombie count."); return; }
  mRandom ^= (uint32)(Time.Tick + seed + round * 3331);
  List<Player> pool = scope .(); for (let p in Player.All) pool.Add(p);
  // Fisher-Yates: each starting zombie set has equal probability.
  for (int32 i = (int32)pool.Count - 1; i > 0; i--) { let j = (int32)(NextRandom() % (uint32)(i + 1)); let swap = pool[i]; pool[i] = pool[j]; pool[j] = swap; }
  int32 wanted = randomZombieCount ? 1 + (int32)(NextRandom() % (uint32)(Player.All.Count - 1)) : initialZombies;
  if (!randomTeams)
  {
   int32 assigned = 0, automatic = 0;
   for (let p in pool) { if (p.assignedTeam == 2) assigned++; if (p.assignedTeam == 0) automatic++; }
   if (randomZombieCount)
   {
    let minimum = Math.Max(assigned, 1); let maximum = Math.Min((int32)pool.Count - 1, assigned + automatic);
    if (maximum < minimum) { notice.Set("Assignments must leave both a human and a zombie."); return; }
    wanted = minimum + (int32)(NextRandom() % (uint32)(maximum - minimum + 1));
   }
   if (assigned > wanted || assigned + automatic < wanted) { notice.Set("Team assignments conflict with zombie count. Adjust assignments or count."); return; }
   int32 remaining = wanted - assigned;
   for (let p in pool) { p.zombie = p.assignedTeam == 2 || (p.assignedTeam == 0 && remaining-- > 0); }
  }
  else for (int i < pool.Count) pool[i].zombie = i < wanted;
  if (seed != 0) seed = NextSeed(seed);
  mPractice = false; round++; escapedCount = 0; keyOwner = -1; RerollKey(); seconds = 300;
  for (int i < Player.All.Count)
  {
   let p = Player.All[i]; p.PrepareRound(); p.escaped = false; p.flashlight = true;

  }
  if (!PlaceTeams()) { notice.Set("Could not find safe separated spawn positions. Generate another house."); return; }
  if (mHouse.keySpots.Count == 0) { notice.Set("No visible key surface in this layout. Generate a new house."); return; }
  phase = 1; menu = false; notice.Set("The doors are locked. Find the key.");
 }
 public void Interact(Player player)
 {
  if (!Authority || phase != 1 || player.zombie || player.InfectionPending || player.escaped) return;
  if (keyOwner < 0 && (player.Transform.Position - KeyPosition(keySite)).Length < 1.7f) { keyOwner = (int32)player.Identity.NetId; return; }
  if (keyOwner == (int32)player.Identity.NetId && (player.Transform.Position - mHouse.exit).Length < 2)
  {
   player.escaped = true; escapedCount++; keyOwner = -1; End(2);
  }
 }
 public void Infect(Player source, Vector3 forward)
 {
  if (!Authority || phase != 1 || !source.zombie || source.escaped) return;
  for (let target in Player.All)
  {
   let delta = target.Transform.Position - source.Transform.Position;
   if (target == source || target.zombie || target.InfectionPending || target.escaped || delta.Length > zombieReach || Vector3.Dot(delta.Normalized, forward) < 0.2f) continue;
   if (mHouse.AttackBlocked(source.Transform.Position + .(0, 1.2f, 0), target.Transform.Position + .(0, 1.2f, 0))) continue;
   target.health = Math.Max(0, target.health - 1);
   if (target.health > 0) continue;
   target.BeginInfection(infectionDelay); if (keyOwner == (int32)target.Identity.NetId) keyOwner = -1;
  }
 }
 void End(int32 result) { phase = result; mEndWait = 8; }
 public void OnResume() { if (Connected) menu = false; }
 public void OnQuit()
 {
  mQuitConfirm = true; mConfirmBack = mPage; confirmTitle.Set("QUIT ZOMBIE TAG?");
  confirmBody.Set(Authority ? "Your room will close and all players will disconnect." : "Return to the desktop?"); OpenPage(.Confirm);
 }
 bool mNetKeyForced, mNetInfectionForced, mNetBatForced;
 public bool TagPreview => mPreviewTag;
 bool mPreviewTag, mPreviewTagRemote, mPreviewBat, mPreviewBatSwing, mPreviewFeet;
 bool mPreviewPickup, mPreviewKeyTest, mPreviewInfection, mPreviewExit;
 int32 mSeenKeyOwner = -1;
 bool mExported;
 int32 mPreviewMode;
 bool mPreviewStarted;
 bool mRebuildPreview, mAuditHall;
 int32 mObservedPhase = -1;
 float mTestElapsed, mTestLog;
 float mTestLimit = 10, mVoiceTestTime;
 bool mTestBots, mTestStart;
 void RunNetworkTest()
 {
  mTestElapsed += Time.UnscaledDeltaTime;
  ready = true;
  mVoiceTestTime -= Time.UnscaledDeltaTime;
  if (Application.Instance.HasArg("--voice-net-test") && mVoiceTestTime <= 0 && !Authority && Scene.Network?.IsConnected == true && Player.Local != null)
  {
   mVoiceTestTime = 0.02f; HouseVoice.Muted = false; HouseVoice.Talk = true;
   float[HouseVoice.FrameSize] tone = ?;
   for (int i < HouseVoice.FrameSize) tone[i] = 0.45f * Math.Sin(i * 0.0576f);
   HouseVoice.Session?.Capture(.(&tone, HouseVoice.FrameSize)); HouseVoice.Talk = false;
  }
  if (Authority && !mTestBots) { mTestBots = true; AddBot(1); AddBot(2); seed = 123; keySize = 2; humanHealth = 5; infectionDelay = 5; batEnabled = true; batFreeze = 9; zombieSpeed = 2.9f; }
  if (Authority && !mTestStart && mTestElapsed > 4 && Player.All.Count >= 4)
  { for (let p in Player.All) p.ready = true; mTestStart = true; OnStart(); }
  if (Authority && phase == 1 && mTestElapsed > 6 && !mNetKeyForced)
  {
   for (let player in Player.All) if (!player.bot && !player.zombie && player.Identity != null)
   { keyOwner = (int32)player.Identity.NetId; mNetKeyForced = true; break; }
  }
  if (Authority && phase == 1 && mTestElapsed > 7.5f && !mNetInfectionForced)
  {
   for (let player in Player.All) if (player.bot && !player.zombie)
   { player.BeginInfection(9); mNetInfectionForced = true; for (let attacker in Player.All) if (attacker.zombie) { attacker.TryTag(.Forward); break; } break; }
  }
  if (Authority && phase == 1 && mTestElapsed > 8 && !mNetBatForced)
  {
   mNetBatForced = true;
   for (let player in Player.All) if (player.HoldsBat) { player.TrySwing(.Forward); break; }
   for (let player in Player.All) if (player.zombie) { player.Freeze(9); break; }
  }
  mTestLog -= Time.UnscaledDeltaTime;
  if (mTestLog <= 0)
  {
   mTestLog = 1;
   Log.Info(scope $"NETSTATE time={(int32)mTestElapsed} phase={phase} seed={seed} players={Player.All.Count} round={round}");
   for (let p in Player.All) Log.Info(scope $"NETPLAYER id={p.Identity.NetId} owner={p.Identity.ownerId} character={p.character} bot={p.bot} zombie={p.zombie} local={p.LocalPlayer} ownerFlag={p.IsOwner}");
  }
  if (mTestElapsed >= mTestLimit)
  {
   if (Application.Instance.HasArg("--voice-net-test") && Authority) Check(HouseVoice.Session != null && HouseVoice.Session.FramesRelayed > 20, "server decodes and relays synthetic proximity voice");
   else if (Application.Instance.HasArg("--voice-net-test")) Check(HouseVoice.Session != null && HouseVoice.Session.FramesSent > 20 && HouseVoice.Session.FramesReceived > 20, "proximity voice packets travel between clients");
   Check(Player.All.Count >= 4, "two clients and two NPCs replicated");
   Check(round >= 1, "round start replicated");
   Check(keyOwner >= 0 && hudAnnouncement.Contains("FOUND") && hudKey.Contains("KEY"), "key-found HUD alert reaches every peer including late join");
   Check(keySize == 2, "host key-size rule replicates including late join");
   Check(humanHealth == 5, "host survivor health replicates including late join");
   for (let player in Player.All) if (!player.zombie && !player.InfectionPending) Check(player.maxHealth == 5 && player.health == 5, "survivor health replicates to peers");
   Check(infectionDelay == 5, "host infection delay replicates including late join");
   bool turningBot = false;
   for (let player in Player.All) if (player.bot && !player.zombie && player.infectionRemaining > 0 && player.infectionRemaining <= 9) turningBot = true;
   Check(turningBot, "pending infection countdown replicates including late join");
   bool sawTag = false; for (let player in Player.All) if (player.tagSequence > 0) sawTag = true;
   Check(sawTag, "zombie tag animation sequence replicates to every peer");
   Check(batEnabled && batFreeze == 9 && Math.Abs(zombieSpeed - 2.9f) < 0.001f, "host team traits replicate including late join");
   bool frozen = false, swung = false;
   for (let player in Player.All) { if (player.zombie && player.Frozen) frozen = true; if (player.swingSequence > 0) swung = true; }
   Check(frozen, "a bat-frozen zombie replicates to every peer");
   Check(swung, "bat swing animation sequence replicates to every peer");
   bool lightsMatch = true;
   for (let player in Player.All) if (!player.bot && (Math.Abs(player.flashlightBrightness - (3 + player.character * 0.25f)) > 0.01f || player.flashlightBeam != 35 + player.character)) lightsMatch = false;
   Check(lightsMatch, "individual flashlight brightness and beam size replicate to every peer");
   Log.Info(scope $"NETKEY site={keySite} roll={keyRoll} position={KeyPosition(keySite)}");
   Check(keyRoll > 0 && keySite >= 0 && keySite < 8, "random key placement replicates including late join");
   Check(seed != 0 && seed != 123, "generated round seed replicated");
   if (!Authority) Check(Player.Local != null && Player.Local.character == selection, "local character selection confirmed by server");
   bool gamer = false, medic = false;
   for (let p in Player.All) { if (!p.bot && p.character == 3) gamer = true; if (!p.bot && p.character == 12) medic = true; }
   Check(gamer && medic, "other clients' selected models replicated");
   Log.Info(scope $"NETWORK TEST RESULT / {mTestFailures} failure(s)");
   if (mTestFailures > 0) Environment.Exit(1);
   Application.Instance.Running = false;
  }
 }
 int32 mInspectionRoom = -1, mInspectionFocus; bool mInspectionPlaced;
 bool mTested;
 void Check(bool valid, StringView label)
 {
  Log.Info(scope $"CHECK {(valid ? "PASS" : "FAIL")} / {label}");
  if (!valid) { notice.Set("SELFTEST FAILED"); mTestFailures++; }
 }
 int32 mTestFailures;
 /// How far a player walks in ten ticks down the open hallway.
 static float Stride(Player who)
 {
  who.GetComponent<CharacterController>().Teleport(.(0, 0.05f, -10), .Zero, 0);
  let from = who.Transform.Position; NetInput walk = default; walk.moveZ = 1;
  for (int32 tick < 10) who.Simulate(walk, Time.FixedDeltaTime);
  var moved = who.Transform.Position - from; moved.y = 0; return moved.Length;
 }
 void RunSelfTest()
 {
  if (!Authority) return;
  let oldCameraPosition = camera.Transform.Position; let oldCameraRotation = camera.Transform.Rotation;
  camera.Transform.Position = .Zero; camera.Transform.Rotation = .Identity;
  Vector2 markerAt, markerDirection;
  Check(MarkerProjection(.(0, 0, 5), 1920, 1080, out markerAt, out markerDirection) && Math.Abs(markerAt.x - 960) < 1 && Math.Abs(markerAt.y - 540) < 1, "objective ahead projects to screen center");
  Check(!MarkerProjection(.(10, 0, 1), 1920, 1080, out markerAt, out markerDirection) && markerAt.x > 960 && markerAt.x < 1920 && markerDirection.x > 0, "right off-screen objective gets inset right-pointing arrow");
  Check(!MarkerProjection(.(-10, 0, 1), 1920, 1080, out markerAt, out markerDirection) && markerAt.x > 0 && markerDirection.x < 0, "left off-screen objective gets inset left-pointing arrow");
  Check(!MarkerProjection(.(0, 0, -5), 1920, 1080, out markerAt, out markerDirection) && markerAt.y > 540 && markerAt.y < 1080, "objective behind camera stays visible as turn-around arrow");
  camera.Transform.Position = oldCameraPosition; camera.Transform.Rotation = oldCameraRotation;
  Check(Player.TagWeight(0) == 0 && Player.TagWeight(0.24f) > 0.99f && Player.TagWeight(0.68f) == 0, "IK tag reach eases in, contacts and returns to idle");
  Check(Player.ShouldMoan(true, false, 1) && !Player.ShouldMoan(false, false, 1) && !Player.ShouldMoan(true, true, 1) && !Player.ShouldMoan(true, false, 0), "living zombies vocalize during rounds; humans, escaped players and lobby characters stay quiet");
  for (int32 model < 19)
  {
   int32 variants = 0;
   for (int32 sequence < 3) { variants |= 1 << Player.MoanVariant(model, sequence); Check(Player.MoanInterval(model, sequence) >= 4.5f && Player.MoanInterval(model, sequence) <= 6.7f, "zombie moans recur without overlapping the clip"); }
   Check(variants == 14, scope $"character {model} cycles all three zombie moans");
  }
  Check(HouseVoice.CodecCheck(), "Opus encoding preserves quiet versus shouted voice levels");
  Check(HouseVoice.Obstructed(Scene, .(-0.2f, 1.55f, -14), .(-2.2f, 1.55f, -14)), "voice is muffled through a room wall");
  Check(!HouseVoice.Obstructed(Scene, .(0, 1.55f, -8), .(0, 1.55f, -4)), "open hallway voice stays clear");
  Check(HouseVoice.HearingRange(0.02f) < HouseVoice.HearingRange(0.1f), "quiet speech travels less far than normal speech");
  Check(HouseVoice.HearingRange(0.1f) < HouseVoice.HearingRange(0.3f), "shouting travels farther than normal speech");
  Check(HouseVoice.DistanceGain(1, 12) == 1 && HouseVoice.DistanceGain(12, 12) == 0, "proximity voice fades to silence at its range");
  Check(HouseVoice.DistanceGain(5, 12) > HouseVoice.DistanceGain(9, 12), "voice distance fade is monotonic");
  for (int32 testSeed < 12)
  {
   let testScene = new Scene(); let house = new House(testScene, testSeed * 137);
   bool spawnValid = true;
   for (int32 humanCount = 1; humanCount <= 15; humanCount += 7)
   {
    List<Vector3> occupied = scope .(); List<Vector3> humans = scope .(); List<Vector3> none = scope .();
    for (int32 i < 16)
    {
     bool zombie = i >= humanCount; Vector3 at;
     if (!house.ChooseSpawn(zombie, false, occupied, zombie ? humans : none, out at)) { spawnValid = false; break; }
     for (let other in occupied) if (Vector3.Distance(at, other) < 1.24f) spawnValid = false;
     if (zombie) for (let humanSpawn in humans) if (Vector3.Distance(at, humanSpawn) < 18) spawnValid = false;
     occupied.Add(at); if (!zombie) humans.Add(at);
    }
   }
   List<Vector3> emptySpawns = scope .(); List<Vector3> nearbyHumans = scope .(); nearbyHumans.Add(.(0, 0, -11)); Vector3 lateSpawn;
   Check(house.ChooseSpawn(true, true, emptySpawns, nearbyHumans, out lateSpawn) && Vector3.Distance(lateSpawn, nearbyHumans[0]) >= 10, "late zombie spawn stays at least 10 metres from survivors");
   nearbyHumans.Clear(); for (let cell in house.nav.cells) if (cell.walkable) nearbyHumans.Add(cell.position);
   Check(!house.ChooseSpawn(true, true, emptySpawns, nearbyHumans, out lateSpawn), "late join waits when there is no safe spawn");
   Check(spawnValid, "16 separated spawns with zombies at least 18 metres from humans");
   Check(house.LaundryRouteCheck(), "laundry annex and doorway retain an AI navigation route");
   Check(house.HallClearCheck(), "decorated 3.5 metre hall retains a clear running route");
   Check(house.WorkstationAccessCheck(), "desks retain a reachable side beside their chair");
   Check(house.NoClimbCheck(), "jumping cannot cross furniture footprints");
   Check(house.plan.Valid(), "semantic room constraints hold");
   Check(house.furnitureCount >= 40 && house.clutterCount >= 250, "dense furnished house uses at least 40 furniture pieces and 250 surface props");
   Log.Info(scope $"DENSITY seed={testSeed * 137} furniture={house.furnitureCount} clutter={house.clutterCount} keySpots={house.keySpots.Count}");
   bool candidatesReachable = house.keySpots.Count >= 16;
   int32[8] candidatesPerRoom = default;
   for (let spot in house.keySpots) candidatesPerRoom[spot.room]++;
   for (int32 room < 8) if (candidatesPerRoom[room] < 2) candidatesReachable = false;
   List<Vector3> candidatePath = scope .();
   for (let spot in house.keySpots)
   {
    candidatePath.Clear(); if (!house.KeyVisible(spot.at)) candidatesReachable = false; if (!house.Route(.(0, 0, -10), spot.at, candidatePath)) candidatesReachable = false;
   }
   Check(candidatesReachable, "key surfaces have clear sight lines, overhead clearance and reachable approaches");
   List<Vector3> path = scope .();
   for (int32 site < 8) { path.Clear(); Check(house.Route(.(0, 0, -10), house.keys[site], path), scope $"seed {testSeed * 137} key {site} reachable"); }
   bool smoothSafe = true; bool shortened = false;
   List<Vector3> smoothPath = scope .();
   for (int32 site < 8)
   {
    path.Clear();
    if (!house.Route(.(0, 0, -10), house.keys[site], path) || path.Count == 0) { smoothSafe = false; continue; }
    let start = path[0];
    if (!house.BotRoute(start, house.keys[site], smoothPath) || smoothPath.Count == 0) { smoothSafe = false; continue; }
    if (smoothPath.Count < path.Count) shortened = true;
    if (Vector3.Distance(smoothPath[smoothPath.Count - 1], path[path.Count - 1]) > 0.01f) smoothSafe = false;
    var previous = start;
    for (let corner in smoothPath) { if (!house.BotSegmentClear(previous, corner)) smoothSafe = false; previous = corner; }
   }
   Check(smoothSafe, "smoothed bot paths preserve endpoints and clear walls and furniture");
   Check(shortened, "bot smoothing removes grid stair steps");
   // Remove the corridor from the navigation graph: both wings must still connect end-to-end.
   for (int32 cellIndex < (int32)house.nav.cells.Count)
   {
    var cell = house.nav.cells[cellIndex];
    if (Math.Abs(cell.position.x) < House.HallHalf - 0.3f) { cell.walkable = false; cell.links = 0; house.nav.cells[cellIndex] = cell; }
   }
   house.nav.Touch();
   path.Clear(); Check(house.Route(house.keys[0], house.keys[3], path), "west wing loop without hallway");
   path.Clear(); Check(house.Route(house.keys[4], house.keys[7], path), "east wing loop without hallway");
   house.Rebuild(testSeed * 137 + 1);
   Check(house.ValidateShell(), "regeneration keeps ceiling clear and exterior walls facing outward");
   delete house; delete testScene;
  }
  bool plansValid = true;
  for (int32 i < 1000) { let generatedPlan = scope HousePlan(i); if (!generatedPlan.Valid()) plansValid = false; }
  Check(plansValid, "1000 semantic WFC seeds satisfy room counts and adjacency");
  randomTeams = false; randomZombieCount = false; initialZombies = 1;
  AddBot(1); AddBot(2);
  OnStart(); Check(phase == 1, "round starts with NPC human and zombie");
  Player human = null, infected = null;
  for (let p in Player.All) { if (p.zombie) infected = p; else human = p; }
  for (let p in Player.All) p.FixedUpdate();
  Check(human != null && infected != null && !human.zombie && infected.zombie, "host assigned teams survive first NPC tick");
  if (human != null && infected != null)
  {
   for (int32 team < 2)
   {
    let runner = team == 0 ? human : infected;
    runner.ResetBurst();
    Check(!runner.AdvanceBurst(true, false, 0.05f), "standing still does not consume movement burst");
    runner.AdvanceBurst(false, true, 0.05f);
    Check(runner.AdvanceBurst(true, true, 0.05f), "Shift starts movement burst");
    for (int32 tick < 65) runner.AdvanceBurst(true, true, 0.05f);
    Check(runner.burstRemaining == 0 && runner.burstCooldown > 0, "burst expires and enters cooldown");
    runner.AdvanceBurst(false, true, 0.05f);
    Check(!runner.AdvanceBurst(true, true, 0.05f), "cooldown rejects another burst");
    for (int32 tick < 110) runner.AdvanceBurst(true, true, 0.05f);
    Check(runner.burstRemaining == 0, "holding Shift does not automatically repeat burst");
    runner.AdvanceBurst(false, true, 0.05f);
    Check(runner.AdvanceBurst(true, true, 0.05f), "burst recharges and can be used again");
    runner.AdvanceBurst(false, true, 0.05f);
    Check(runner.burstCooldown > 0 && runner.burstRemaining == 0, "ending burst early starts cooldown");
    runner.PrepareRound();
    Check(runner.burstCooldown == 0 && runner.burstRemaining == 0, "round reset clears burst timers");
   }
   NetInput hostInput = default;
   hostInput.moveX = 0.25f; hostInput.moveZ = 1; hostInput.yaw = 90; hostInput.pitch = -12;
   hostInput.SetButton((int)InputButton.Ability2, true);
   let hostButtons = hostInput.buttons;
   infected.GatherInput(ref hostInput); human.GatherInput(ref hostInput);
   Check(hostInput.moveX == 0.25f && hostInput.moveZ == 1 && hostInput.yaw == 90 && hostInput.pitch == -12 && hostInput.buttons == hostButtons, "server-owned bots preserve host movement, camera yaw and buttons");
   human.bot = false; human.flashlight = true;
   NetInput toggle = default; toggle.SetButton((int)InputButton.Ability2, true); human.Simulate(toggle, Time.FixedDeltaTime);
   Check(!human.flashlight, "F input toggles human flashlight on the server");
   human.bot = true;
   human.Transform.Position = KeyPosition(keySite); Interact(human);
   Check(keyOwner == (int32)human.Identity.NetId, "NPC picks up key by unique network ID");
   human.Transform.Position = mHouse.exit; Interact(human); Check(phase == 2 && escapedCount == 1, "key carrier escapes and wins");
   phase = 0; OnStart(); human.zombie = false; infected.zombie = true;
   human.Transform.Position = .(0, 0, 1); infected.Transform.Position = .(0, 0, 0);
   infectionDelay = 3; keyOwner = (int32)human.Identity.NetId;
   Check(human.health == 3 && human.maxHealth == 3, "humans start a round with three health");
   Infect(infected, .Forward);
   Check(human.health == 2 && !human.InfectionPending && keyOwner == (int32)human.Identity.NetId, "first hit removes health and keeps carrier key");
   Infect(infected, .Forward);
   Check(human.health == 1 && !human.InfectionPending, "second hit leaves human alive with one health");
   Infect(infected, .Forward);
   Check(human.health == 0, "third hit depletes health");
   Check(!human.zombie && human.InfectionPending && human.infectionRemaining == 3 && keyOwner == -1, "infection starts configured countdown and immediately drops carrier key");
   human.AdvanceInfection(1); Infect(infected, .Forward);
   Check(!human.zombie && human.infectionRemaining == 2, "repeated attacks do not reset infection countdown");
   human.Transform.Position = KeyPosition(keySite); Interact(human);
   Check(keyOwner == -1, "turning player cannot pick up the key");
   keyOwner = (int32)human.Identity.NetId; human.Transform.Position = mHouse.exit; Interact(human);
   Check(phase == 1 && !human.escaped, "turning carrier cannot escape during countdown"); keyOwner = -1;
   human.AdvanceInfection(2.1f);
   Check(human.zombie && !human.InfectionPending && !human.flashlight, "countdown converts player to zombie when elapsed");
   Check(human.DesiredModelIndex == human.character * 2 + 1, "completed infection selects the matching network zombie model");
   human.zombie = false; human.BeginInfection(0);
   Check(human.zombie && !human.InfectionPending, "zero delay supports instant infection");
   human.zombie = false; human.BeginInfection(5); human.PrepareRound();
   Check(!human.InfectionPending && human.health == 3, "new round clears infection and restores full health");
   humanHealth = 5; human.PrepareRound();
   Check(human.health == 5 && human.maxHealth == 5, "round health follows host setting");
   humanHealth = 1; human.PrepareRound();
   human.Transform.Position = .(0, 0, 1); infected.Transform.Position = .Zero;
   infected.PrepareRound();
   let oldTag = infected.tagSequence;
   Check(infected.TryTag(.Forward) && infected.tagSequence == oldTag + 1 && !human.InfectionPending, "left-click tag replicates a reach before applying contact");
   Check(!infected.TryTag(.Forward), "tag cooldown prevents repeated attack spam");
   infected.AdvanceTag(0.1f); Check(!human.InfectionPending, "tag cannot infect before the hand reaches contact");
   infected.AdvanceTag(0.15f); Check(human.InfectionPending, "tag infects at IK reach contact time");
   human.ClearInfection(); infected.PrepareRound();
   Check(!human.TryTag(.Forward), "human players cannot use zombie tag attacks");
   human.zombie = false; human.ClearInfection(); human.zombie = false; human.Transform.Position = .(0, 0, -8.8f); infected.Transform.Position = .(0, 0, -10); infected.PrepareRound();
   infected.Transform.Rotation = Quaternion.Identity;
   Check(infected.CanSpot(human), "AI notices a nearby visible survivor");
   human.Transform.Position = .(0, 0, 3);
   Check(!infected.CanSpot(human), "AI cannot spot survivors beyond ten metres");
   human.Transform.Position = .(0, 0, -13);
   Check(!infected.CanSpot(human), "AI cannot spot distant survivors behind its view cone");
   human.Transform.Position = .(-1.7f, 0, -14); infected.Transform.Position = .(-0.2f, 0, -14);
   Check(!infected.CanSpot(human), "AI cannot see survivors through a room wall");
   human.Transform.Position = .(0, 0, -8.8f); infected.Transform.Position = .(0, 0, -10);
   for (int32 tick < 180) infected.FixedUpdate();
   Check(human.InfectionPending || human.zombie, "AI zombie pursuit and swipe infect a stationary player");
   human.AdvanceInfection(3.1f); Check(human.zombie && human.DesiredModelIndex == human.character * 2 + 1, "AI infection countdown finishes with the matching zombie model");
   human.ClearInfection(); human.zombie = false; human.ResetHealth(); human.Transform.Position = .(0, 0, 3); infected.Transform.Position = .Zero; Infect(infected, .Forward); Check(!human.zombie && human.health == human.maxHealth, "distant attacks cannot damage survivor health");
   human.Transform.Position = .(-2.2f, 0, -14); infected.Transform.Position = .(-0.2f, 0, -14); Infect(infected, .(-1, 0, 0)); Check(!human.zombie && human.health == human.maxHealth, "room walls block health damage");
   humanHealth = DefaultHumanHealth;
   // Traits and the bat.
   Check(MoveSpeed(true) < MoveSpeed(false), "zombies are slower than survivors by default");
   human.zombie = false; human.ClearInfection(); infected.PrepareRound(); human.PrepareRound();
   human.Transform.Position = .(0, 0, -8.8f); infected.Transform.Position = .(0, 0, -10);
   let towards = Vector3(0, 0, -1);
   batEnabled = false; Check(!human.TrySwing(towards), "the bat cannot be swung while the bat trait is off");
   batEnabled = true; batFreeze = 3;
   Check(human.TrySwing(towards), "a survivor swings the bat when the trait is on");
   Check(!infected.TrySwing(towards), "zombies cannot swing the bat");
   human.AdvanceBat(0.1f); Check(!infected.Frozen, "the bat cannot freeze before it reaches the zombie");
   human.AdvanceBat(0.15f); Check(infected.Frozen && infected.frozenRemaining == 3, "a bat hit freezes the zombie for the trait time");
   Check(!infected.TryTag(.Forward), "a frozen zombie cannot attack");
   infected.bot = false; let frozenAt = infected.Transform.Position;
   NetInput push = default; push.moveZ = 1; push.SetButton((int)InputButton.Jump, true);
   for (int32 tick < 10) infected.Simulate(push, Time.FixedDeltaTime);
   var frozenMoved = infected.Transform.Position - frozenAt; frozenMoved.y = 0;
   Check(frozenMoved.Length < 0.001f, "a frozen zombie cannot move");
   infected.AdvanceBat(3.05f); Check(!infected.Frozen, "the zombie thaws when the freeze time ends");
   human.AdvanceBat(2); human.TrySwing(towards); human.AdvanceBat(0.25f);
   Check(!infected.Frozen, "a thawed zombie cannot be frozen again straight away");
   infected.AdvanceBat(2); human.AdvanceBat(2); human.TrySwing(towards); human.AdvanceBat(0.25f);
   Check(infected.Frozen, "the zombie can be frozen again after the grace period");
   infected.AdvanceBat(4); infected.AdvanceBat(2);
   human.Transform.Position = .(-1.7f, 0, -14); infected.Transform.Position = .(-0.2f, 0, -14); human.AdvanceBat(2); human.TrySwing(.(1, 0, 0)); human.AdvanceBat(0.25f);
   Check(!infected.Frozen, "the bat cannot hit through a room wall");
   // Walk speed comes from the team trait.
   zombieSpeed = 2; let slow = Stride(infected); zombieSpeed = 5; let fast = Stride(infected);
   Check(slow > 0.05f && fast > slow * 2, scope $"zombie walk speed follows the trait ({slow:0.000} m vs {fast:0.000} m)");
   infected.bot = true;
   humanSpeed = DefaultHumanSpeed; zombieSpeed = DefaultZombieSpeed; batEnabled = false;
  }
  phase = 0; randomTeams = true; randomZombieCount = true;
  bool countsValid = true;
  for (int32 i < 20)
  {
   for (let p in Player.All) p.ready = true;
   OnStart(); int32 zombies = 0; for (let p in Player.All) if (p.zombie) zombies++;
   if (zombies < 1 || zombies >= Player.All.Count) countsValid = false;
   phase = 0;
  }
  bool keyRandomValid = true; int32 visitedRooms = 0;
  for (int32 i < 1000)
  {
   let previous = keySite; RerollKey();
   if (keySite == previous || keySite < 0 || keySite > 7) keyRandomValid = false;
   visitedRooms |= (int32)(1 << keySite);
  }
  Check(keyRandomValid && visitedRooms == 255, "key rerolls cover every room without consecutive repeats across 1000 rounds");
  int32 generated = 999999; bool seedsValid = true;
  for (int32 i < 1000) { generated = NextSeed(generated); if (generated < 1 || generated > 1000000) seedsValid = false; }
  Check(seedsValid, "repeated generation keeps seeds in range without integer overflow");
  Check(countsValid, "random zombie counts always leave human and zombie teams");
  Log.Info(scope $"SELFTEST RESULT / {mTestFailures} failure(s)");
  if (mTestFailures > 0) Environment.Exit(1);
  Application.Instance.Running = false;
 }
 public void OnPlayers() { notice.Clear(); OpenPage(.Players); }
 public void OnMain() { OpenPage(Connected ? .Lobby : .Main); }
 public void OnNextPlayer() { if (Player.All.Count > 0) mPlayerSlot = (mPlayerSlot + 1) % (int32)Player.All.Count; }
 Player Selected => Player.All.Count > 0 ? Player.All[Math.Clamp(mPlayerSlot, 0, (int32)Player.All.Count - 1)] : null;
 bool CanConfigure => !Connected || (Authority && phase == 0);
 public void OnHuman() { if (CanConfigure && Selected != null) Selected.assignedTeam = 1; }
 public void OnZombie() { if (CanConfigure && Selected != null) Selected.assignedTeam = 2; }
 public void OnAuto() { if (CanConfigure && Selected != null) Selected.assignedTeam = 0; }
 public void OnRandomTeams() { if (CanConfigure) randomTeams = !randomTeams; }
 public void OnRandomCount() { if (CanConfigure) randomZombieCount = !randomZombieCount; }
 void AddBot(int32 team)
 {
  if (!Authority || !CanConfigure || Player.All.Count >= 16) return;
  let ob = Scene.Network.Spawn("Player", .(0, 0.1f, -5), .Identity, 0);
  if (ob == null) return;
  let p = ob.GetComponent<Player>(); p.bot = true; p.ready = true; p.assignedTeam = team; p.character = (int32)(NextRandom() % 19);
 }
 public void OnAddHuman() { AddBot(1); }
 public void OnAddZombie() { AddBot(2); }
 public void OnRemoveBot() { if (CanConfigure && Selected != null && Selected.bot) Scene.Network.Despawn(Selected.GameObject); }
 public void OnFov(UIElement element) { fieldOfView = Math.Clamp(element.value, 60, 110); }
 public void OnSensitivity(UIElement element) { sensitivity = Math.Clamp(element.value, 0.03f, 0.5f); }
 public void OnInvite()
 {
  if (!Authority || Scene.Network.Transport != .Steam) { notice.Set("Host a Steam room first."); return; }
  let friend = uint64.Parse(inviteId).GetValueOrDefault();
  if (friend == 0 || !Steam.IsFriend(friend)) { notice.Set("Enter the Steam ID of a friend to invite."); return; }
  notice.Set(Steam.Invite(friend, scope $"{Steam.UserId}") ? "Invitation sent." : "Could not send invitation.");
 }
}
