using System;
using System.Collections;
using Tessera;
namespace ZombieTag;

/// Town construction modules with semantic WFC room assignment and reserved chase loops.
class House
{
 public const float HallHalf = 1.75f;
 public const float OuterHalf = HallHalf + 7.5f;
 Scene mScene;
 public GameObject root;
 public Vector3[8] keys;
 public struct KeySpot { public int32 room; public Vector3 at; public this(int32 r, Vector3 a) { room = r; at = a; } }
 public List<KeySpot> keySpots = new .() ~ delete _;
 struct Top { public Vector3 at; public float width, depth, yaw, clearance; public bool books, shelving;
  public this(Vector3 a, float w, float d, float y, float c, bool b, bool shelf = false) { at = a; width = w; depth = d; yaw = y; clearance = c; books = b; shelving = shelf; } }
 List<Top> mTops = new .() ~ delete _;
 List<Obstacle> mWindows = new .() ~ delete _;
 List<Obstacle> mClutter = new .() ~ delete _;
 public int32[8] roomFurniture, roomClutter;
 public HousePlan plan ~ delete _;
 List<GameObject> mPool = new .() ~ delete _;
 int32 mCursor;
 struct Obstacle { public Vector3 at, size; public bool furniture; public this(Vector3 a, Vector3 s, bool f = false) { at = a; size = s; furniture = f; } }
 List<Obstacle> mObstacles = new .() ~ delete _;
 public NavigationData nav = new .() ~ delete _;
 public Vector3 exit = .(0, 0, -14);
 uint32 mRandom;
 int32 mRoom;
 bool mFlip;
 public int32 furnitureCount, clutterCount, hallFurnitureCount, hallClutterCount;
 public this(Scene scene, int32 seed)
 {
  mScene = scene; mRandom = (uint32)Math.Max(seed, 1); plan = new HousePlan(seed);
  // The checked-in prefab is generated from exactly the same authored seed-zero rules.
  if (seed == 0 && !Application.Instance.HasArg("--export-house")) root = Prefab.Create(scene, "Prefabs/BlackwoodHouse.tprefab");
  let loadedPrefab = root != null;
  if (root != null)
  {
   root.Transient = true;
   for (let child in root.Transform.Children)
   {
    let ob = child.GameObject; ob.Transient = true; mPool.Add(ob);
    let collider = ob.GetComponent<BoxCollider>();
    if (collider != null && child.LocalPosition.y - collider.size.y * 0.5f < 2.2f && child.LocalPosition.y + collider.size.y * 0.5f > 0.1f)
    {
     let furniture = ob.Name == "Furniture collision"; mObstacles.Add(.(child.LocalPosition, collider.size, furniture)); if (furniture) furnitureCount++;
    }
    if (ob.Name == "HallStats") { hallFurnitureCount = (int32)child.LocalPosition.x; hallClutterCount = (int32)child.LocalPosition.y; }
    if (ob.Name.StartsWith("RoomStats"))
    {
     let room = Math.Clamp(SceneSerializer.ParseInt(ob.Name.Substring(9)), 0, 7);
     roomFurniture[room] = (int32)child.LocalPosition.x; roomClutter[room] = (int32)child.LocalPosition.y;
    }
    if (ob.Name.StartsWith("KeyCandidate")) keySpots.Add(.(SceneSerializer.ParseInt(ob.Name.Substring(12)), child.LocalPosition));
    if (ob.Name.StartsWith("KeySite")) keys[Math.Clamp(SceneSerializer.ParseInt(ob.Name.Substring(7)), 0, 7)] = child.LocalPosition;
    if (ob.Name == "mug" || ob.Name == "book_group" || ob.Name == "plant" || ob.Name == "lamp" || ob.Name == "plate" || ob.Name == "tv") clutterCount++;
   }
   if (keySpots.Count > 0) { furnitureCount = hallFurnitureCount; clutterCount = hallClutterCount; for (int32 i < 8) { furnitureCount += roomFurniture[i]; clutterCount += roomClutter[i]; } }
   mCursor = (int32)mPool.Count;
  }
  else
  {
   root = scene.CreateGameObject(seed == 0 ? "Test House - Blackwood" : "Generated House"); root.Transient = true; Build(seed);
  }
  BakeNavigation(); FinalizeKeys(!loadedPrefab);
 }
 GameObject Part(StringView name)
 {
  GameObject ob;
  if (mCursor < mPool.Count) ob = mPool[mCursor];
  else { ob = mScene.CreateGameObject(name, root.Transform); mPool.Add(ob); ob.Transient = true; }
  mCursor++; ob.Name.Set(name); ob.SetActive(true); ob.Transform.LocalRotation = .Identity; ob.Transform.LocalScale = .One;
  if (let mesh = ob.GetComponent<MeshRenderer>()) mesh.Enabled = false;
  if (let collider = ob.GetComponent<BoxCollider>()) collider.Enabled = false;
  return ob;
 }
 public void Rebuild(int32 seed)
 {
  mRandom = (uint32)Math.Max(seed, 1); delete plan; plan = new HousePlan(seed);
  mObstacles.Clear(); mWindows.Clear(); mClutter.Clear(); keySpots.Clear(); roomFurniture = default; roomClutter = default; hallFurnitureCount = 0; hallClutterCount = 0; furnitureCount = 0; clutterCount = 0; mCursor = 0;
  Build(seed);
  for (int i = mCursor; i < mPool.Count; i++) mPool[i].SetActive(false);
  BakeNavigation(); FinalizeKeys(true);
 }
 public void Remove() { if (root != null && !root.IsDestroyed) mScene.Destroy(root); }
 uint32 Next() { mRandom = mRandom * 1664525 + 1013904223; return mRandom; }
 void Collision(StringView name, Vector3 at, Vector3 size, bool furniture = false)
 {
  if (at.y - size.y * 0.5f < 2.2f && at.y + size.y * 0.5f > 0.1f) mObstacles.Add(.(at, size, furniture));
  let ob = Part(name);
  ob.Transform.LocalPosition = at;
  let collider = ob.GetComponent<BoxCollider>() ?? ob.AddComponent<BoxCollider>(); collider.size = size; collider.Enabled = true; collider.OnValidate();
 }
 void Art(StringView key, Vector3 at, float yaw = 0, float widthScale = 1)
 {
  for (int32 part < TownCatalog.Parts(key))
  {
   let ob = Part(key);
   ob.Transform.LocalPosition = at; ob.Transform.LocalRotation = Quaternion.Euler(0, yaw, 0); ob.Transform.LocalScale = .(widthScale, 1, 1);
   if (key == "art") ob.Transform.LocalScale = .(0.55f, 0.55f, 0.55f);
   if (key == "rug") ob.Transform.LocalScale = .(1.4f, 1.4f, 1.4f);
   if (key == "ceiling_fan") ob.Transform.LocalScale = .(0.75f, 0.75f, 0.75f);
   let mesh = ob.GetComponent<MeshRenderer>() ?? ob.AddComponent<MeshRenderer>(); mesh.Enabled = true; mesh.mesh.Set(scope $"Models/Town/{key}.glb#{part}"); mesh.material.Set(TownCatalog.Material(key, part));
  }
 }
 void Wall(Vector3 at, float yaw, bool door = false, bool outer = false, bool window = false, float widthScale = 1)
 {
  Art(outer ? (door ? "wall_entry" : (window ? "wall_window" : "wall_outer")) : (door ? "wall_door" : "wall_inner"), at, yaw, widthScale);
  let rotation = Quaternion.Euler(0, yaw, 0);
  if (window)
  {
   Art("window", at + rotation * Vector3(0.64f, 0, 0), yaw);
   let dims = rotation * TownCatalog.Size("window");
   mWindows.Add(.(at + rotation * Vector3(1.25f, 1.3f, 0), .(Math.Abs(dims.x), 2, Math.Abs(dims.z))));
  }
  // Door aperture 1.3m: collider posts and lintel preserve every opening.
  if (door)
  {
   WallBox(at, rotation, .(0.3f, 1.45f, 0), .(0.6f, 2.9f, 0.2f));
   WallBox(at, rotation, .(2.2f, 1.45f, 0), .(0.6f, 2.9f, 0.2f));
   WallBox(at, rotation, .(1.25f, 2.65f, 0), .(1.3f, 0.5f, 0.2f));
  }
  else WallBox(at, rotation, .(1.25f * widthScale, 1.45f, 0), .(2.5f * widthScale, 2.9f, 0.2f));
 }
 void WallBox(Vector3 at, Quaternion rotation, Vector3 offset, Vector3 size)
 {
  let rotated = rotation * size; Collision("Wall collision", at + rotation * offset, .(Math.Abs(rotated.x), size.y, Math.Abs(rotated.z)));
 }
 Vector3 RoomPoint(float u, float v, float height = 0)
 {
  var u; var v;
  if (mFlip) { u = plan.widths[mRoom] - u; v = plan.depths[mRoom] - v; }
  return .(((mRoom / 4 == 0) ? -HallHalf - plan.widths[mRoom] : HallHalf) + u, height, plan.starts[mRoom] + v);
 }
 void Furniture(StringView key, float u, float v, float yaw = 0)
 {
  var yaw;
  let at = RoomPoint(u, v); yaw += mFlip ? 180 : 0; Art(key, at, yaw); furnitureCount++; roomFurniture[mRoom]++;
  let size = TownCatalog.Size(key); let rotation = Quaternion.Euler(0, yaw, 0); let rotated = rotation * size;
  Collision("Furniture collision", at + Vector3(0, size.y * 0.5f, 0), .(Math.Abs(rotated.x), size.y, Math.Abs(rotated.z)), true);
  // Only exposed boards: cabinet interiors and the sink basin are deliberately excluded.
  if (key == "bookshelf" || key == "bookshelf2" || key == "shelf")
  {
   for (int32 i < TownCatalog.Surfaces(key))
   {
    let local = TownCatalog.SurfacePoint(key, i); let dims = TownCatalog.SurfaceSize(key, i);
    float clearance = 2.45f - local.y;
    for (int32 j < TownCatalog.Surfaces(key))
    {
     let above = TownCatalog.SurfacePoint(key, j);
     if (above.y > local.y + 0.05f && Math.Abs(above.x - local.x) < (dims.x + TownCatalog.SurfaceSize(key, j).x) * 0.5f)
      clearance = Math.Min(clearance, above.y - local.y - 0.055f);
    }
    mTops.Add(.(at + rotation * local, dims.x, dims.y, yaw, clearance, true, true));
   }
  }
 }
 bool FurnitureFits(StringView key, float u, float v, float yaw = 0)
 {
  let at = RoomPoint(u, v); let rotated = Quaternion.Euler(0, yaw, 0) * TownCatalog.Size(key);
  let half = Vector3(Math.Abs(rotated.x) * 0.5f, 0, Math.Abs(rotated.z) * 0.5f);
  // Reserve both cross-room openings and the hall entrance, including approach space.
  let length = plan.depths[mRoom]; let width = plan.widths[mRoom];
  if (u - half.x < 0.12f || u + half.x > width - 0.12f || v - half.z < 0.12f || v + half.z > length - 0.12f) return false;
  if ((v - half.z < 1.25f || v + half.z > length - 1.25f) &&
      (Math.Abs(u - 1.25f) < half.x + 0.8f || Math.Abs(u - (width - 1.25f)) < half.x + 0.8f)) return false;
  let doorV = plan.rooms[mRoom] == .Bathroom ? 1.25f : ((float)(int32)(length / 5) * 2.5f + 1.25f);
  let worldDoor = Vector3(mRoom < 4 ? -HallHalf : HallHalf, 0, plan.starts[mRoom] + doorV);
  if (Math.Abs(at.x - worldDoor.x) < half.x + 1.0f && Math.Abs(at.z - worldDoor.z) < half.z + 0.85f) return false;
  for (let window in mWindows)
   if (Math.Abs(at.x - window.at.x) < half.x + window.size.x * 0.5f + 0.05f && Math.Abs(at.z - window.at.z) < half.z + window.size.z * 0.5f + 0.05f) return false;
  for (let obstacle in mObstacles)
   if (obstacle.furniture && Math.Abs(at.x - obstacle.at.x) < half.x + obstacle.size.x * 0.5f + 0.15f && Math.Abs(at.z - obstacle.at.z) < half.z + obstacle.size.z * 0.5f + 0.15f) return false;
  return true;
 }
 bool OptionalFurniture(StringView key, float u, float v, float yaw = 0)
 {
  if (!FurnitureFits(key, u, v, yaw)) return false;
  Furniture(key, u, v, yaw); return true;
 }
 // Tabletop picture frames are 25.5cm high; use their rendered size for packing too.
 Vector3 ClutterSize(StringView key) => TownCatalog.Size(key) * (key == "art" ? 0.55f : (key == "rug" ? 1.4f : 1));
 void PlaceClutter(StringView key, Vector3 at, float yaw)
 {
  Art(key, at, yaw); clutterCount++; roomClutter[mRoom]++;
  let size = ClutterSize(key); let rotated = Quaternion.Euler(0, yaw, 0) * size;
  mClutter.Add(.(at + Vector3(0, size.y * 0.5f, 0), .(Math.Abs(rotated.x), size.y, Math.Abs(rotated.z))));
 }
 void Clutter(StringView key, float u, float v, float height, float yaw = 0) { PlaceClutter(key, RoomPoint(u, v, height), yaw + (mFlip ? 180 : 0)); }
 void Surface(float u, float v, float height, float width, float depth, bool books = true, float yaw = 0)
 {
  mTops.Add(.(RoomPoint(u, v, height), width, depth, yaw + (mFlip ? 180 : 0), 2.45f - height, books));
 }
 bool FreeApproach(Vector3 at)
 {
  for (int32 probe < 16)
  {
   let angle = probe * Math.PI_f / 8; let floor = at + Vector3(Math.Cos(angle) * 0.85f, 0, Math.Sin(angle) * 0.85f);
   if (Math.Abs(floor.x) > OuterHalf - 0.4f || floor.z < -14.6f || floor.z > 14.6f) continue;
   bool free = true;
   for (let obstacle in mObstacles)
    if (Math.Abs(floor.x - obstacle.at.x) < obstacle.size.x * 0.5f + 0.36f && Math.Abs(floor.z - obstacle.at.z) < obstacle.size.z * 0.5f + 0.36f) { free = false; break; }
   if (free) return true;
  }
  return false;
 }
 StringView SmallProp(bool books, bool shelving)
 {
  let roll = Next() % 16;
  if (plan.rooms[mRoom] == .Bathroom)
  {
   switch (roll % 5) { case 0: return "soap"; case 1: return "toothpaste"; case 2: return "toothbrushes"; case 3: return "mouthwash"; default: return "toilet_roll"; }
  }
  if (!books || plan.rooms[mRoom] == .Kitchen || plan.rooms[mRoom] == .Dining)
  {
   switch (roll) { case 0, 1: return "plate"; case 2: return "mug"; case 3: return "glass"; case 4: return "glass2";
   case 5: return "cutting_board"; case 6, 7: return "fork"; case 8: return "spoon"; case 9: return "knife";
   case 10: return "bread"; case 11: return "tomato"; case 12: return "onion"; case 13, 14: return "can"; default: return "juice"; }
  }
  if (!shelving)
  {
   switch (roll % 10) { case 0, 1: return "books4"; case 2: return "mug"; case 3: return "art"; case 4: return "candles";
   case 5: return "plant"; case 6: return "controller"; case 7: return "toy"; case 8: return "glass"; default: return "book_group"; }
  }
  switch (roll) { case 0, 1, 2: return "book2"; case 3, 4: return "book3"; case 5, 6: return "books2"; case 7, 8: return "books3";
  case 9: return "books4"; case 10: return "mug"; case 11: return "art"; case 12: return "candles"; case 13: return "plant"; case 14: return "controller"; default: return "toy"; }
 }
 void FillSurfaces()
 {
  let firstKey = (int32)keySpots.Count;
  // Several exposed surfaces per room, each with a reserved clear corner for the largest key.
  for (let top in mTops)
  {
   if (top.shelving || top.at.y > 1.25f || top.width < 0.28f || top.depth < 0.25f) continue;
   let rotate = Quaternion.Euler(0, top.yaw, 0);
   for (int32 corner < 2)
   {
   let point = top.at + rotate * Vector3((corner == 0 ? 1 : -1) * (top.width * 0.5f - 0.105f), 0.025f, -top.depth * 0.5f + 0.105f);
   bool clear = FreeApproach(point);
   for (let prop in mClutter)
    if (Math.Abs(point.y - prop.at.y) < prop.size.y * 0.5f + 0.06f && Math.Abs(point.x - prop.at.x) < prop.size.x * 0.5f + 0.1f && Math.Abs(point.z - prop.at.z) < prop.size.z * 0.5f + 0.1f) clear = false;
   if (clear) keySpots.Add(.(mRoom, point));
   }
  }
  if (keySpots.Count > firstKey) keys[mRoom] = keySpots[firstKey].at;
  let marker = Part(scope $"KeySite{mRoom}"); marker.Transform.LocalPosition = keys[mRoom];
  for (let top in mTops)
  {
   let rotate = Quaternion.Euler(0, top.yaw, 0);
   List<StringView> placed = scope .();
   // Rejection packing uses each actual mesh footprint, so props do not intersect or float.
   for (int32 attempt < 180)
   {
    let key = SmallProp(top.books, top.shelving);
    int32 duplicates = 0; for (let previous in placed) if (previous == key) duplicates++;
    int32 limit = top.shelving && (key == "book2" || key == "book3") ? 12 : 2;
    if (key == "candles" || key == "plant" || key == "art" || key == "controller" || key == "toy") limit = 1;
    if (duplicates >= limit) continue;
    let size = ClutterSize(key);
    if (size.y > top.clearance || top.at.y + size.y > 2.45f) continue;
    let randomYaw = (float)(Next() % 4) * 90;
    // Frames face the same accessible side as the furniture supporting them.
    let yaw = key == "art" ? 0 : randomYaw;
    let footprint = Quaternion.Euler(0, yaw, 0) * size;
    let wide = Math.Abs(footprint.x); let deep = Math.Abs(footprint.z);
    if (wide + 0.008f > top.width || deep + 0.008f > top.depth) continue;
    let u = ((float)(Next() % 10001) / 10000 - 0.5f) * (top.width - wide - 0.008f);
    let v = ((float)(Next() % 10001) / 10000 - 0.5f) * (top.depth - deep - 0.008f);
    let at = top.at + rotate * Vector3(u, 0.003f, v);
    let worldSize = rotate * Vector3(wide, size.y, deep); let half = Vector3(Math.Abs(worldSize.x), size.y, Math.Abs(worldSize.z)) * 0.5f;
    bool clear = true;
    for (let spot in keySpots)
     if (spot.room == mRoom && Math.Abs(at.y - spot.at.y) < size.y + 0.07f && Math.Abs(at.x - spot.at.x) < half.x + 0.1f && Math.Abs(at.z - spot.at.z) < half.z + 0.1f) { clear = false; break; }
    if (!clear) continue;
    for (let prop in mClutter)
     if (Math.Abs(at.y + half.y - prop.at.y) < half.y + prop.size.y * 0.5f + 0.008f && Math.Abs(at.x - prop.at.x) < half.x + prop.size.x * 0.5f + 0.012f && Math.Abs(at.z - prop.at.z) < half.z + prop.size.z * 0.5f + 0.012f) { clear = false; break; }
    if (clear) { PlaceClutter(key, at, top.yaw + yaw); placed.Add(key); }
   }
  }
 }
 void FinalizeKeys(bool writeMarkers)
 {
  CacheVisualBlocks();
  List<Vector3> path = scope .();
  for (int32 i = (int32)keySpots.Count - 1; i >= 0; i--)
  {
   path.Clear(); let at = keySpots[i].at;
   if (!KeyVisible(at) || !Route(.(0, 0, -10), at, path) || path.Count == 0 || Vector3.Distance(path[path.Count - 1], at) > 1.65f) keySpots.RemoveAt(i);
  }
  for (int32 room < 8)
  {
   for (let spot in keySpots) if (spot.room == room) { keys[room] = spot.at; break; }
   for (let ob in mPool) if (ob.Name == scope $"KeySite{room}") ob.Transform.LocalPosition = keys[room];
  }
  if (writeMarkers) for (let spot in keySpots)
  {
   let marker = Part(scope $"KeyCandidate{spot.room}"); marker.Transform.LocalPosition = spot.at;
  }
 }
 public Vector3 RandomKeyPosition(int32 room, int32 roll)
 {
  int32 count = 0; for (let spot in keySpots) if (spot.room == room) count++;
  if (count == 0 && keySpots.Count > 0) return keySpots[(int32)((uint32)roll % (uint32)keySpots.Count)].at;
  if (count == 0) return keys[room];
  int32 selected = (int32)((uint32)roll % (uint32)count);
  for (let spot in keySpots) if (spot.room == room && selected-- == 0) return spot.at;
  return keys[room];
 }
 void Furnish()
 {
  mTops.Clear(); let length = plan.depths[mRoom]; let variant = plan.variants[mRoom];
  switch (plan.rooms[mRoom])
  {
  case .Bedroom:
   if (variant == 2)
   {
    Furniture("single_bed", 2.5f, 1.65f, 180); Furniture("single_bed", 5, 1.65f, 180);
    Furniture("bedside", 3.75f, 0.8f, 180); Surface(3.75f, 0.8f, 0.4525f, 0.398f, 0.407f, true, 180);
   }
   else
   {
    Furniture(variant == 0 ? "bed" : "bed2", 3.75f, 1.65f, 180);
    Furniture("bedside", 5.2f, 0.8f, 180); Furniture("bedside", 2.3f, 0.8f, 180);
    Surface(5.2f, 0.8f, 0.4525f, 0.398f, 0.407f, true, 180); Surface(2.3f, 0.8f, 0.4525f, 0.398f, 0.407f, true, 180);
   }
   Furniture("wardrobe", 2.4f, length - 0.45f);
   Furniture("dresser2", 4.85f, length - 0.4f); Surface(4.85f, length - 0.4f, 0.817f, 0.64f, 0.44f);
   OptionalFurniture("laundry_bin", 5.4f, length - 1.5f);
   if (length >= 10 && OptionalFurniture("desk", 3.75f, length - 2.5f))
   {
    Surface(3.75f, length - 2.5f, 0.8769f, 2.229f, 0.896f);
    OptionalFurniture("desk_chair", 3.75f, length - 3.5f, 180);
   }
  case .Living:
   Furniture(variant == 0 ? "sofa" : "sofa2", 3.75f, 0.8f, 180);
   Furniture("coffee_table", 3.75f, 2.25f); Surface(3.75f, 2.25f, 0.424f, 1.194f, 0.711f);
   Furniture("tv_cabinet", 3.75f, length - 0.45f);
   Clutter("tv", 3.75f, length - 0.45f, 0.6006f);
   Clutter(variant == 2 ? "stereo" : "console", 2.7f, length - 0.45f, 0.6006f);
   Surface(3.75f, length - 0.45f, 0.6006f, 2.89f, 0.60f);
   OptionalFurniture("sofa3", 2.2f, 2.7f, -90); OptionalFurniture("sofa3", 5.3f, 2.7f, 90);
   // Try several wall bays, requiring space for both the desk and its chair.
   // A rejected centre bay must not make every generated living room lose its desk.
   bool placedDesk = false;
   if (length >= 10) for (int32 wall < 2) for (int32 bay < 3)
   {
    if (placedDesk) continue;
    let u = wall == 0 ? 0.6f : 6.9f; let yaw = wall == 0 ? -90.0f : 90.0f;
    let v = length * 0.5f + (bay == 0 ? 0.0f : (bay == 1 ? 1.5f : -1.5f));
    let chairU = u + (wall == 0 ? 1.1f : -1.1f);
    if (!FurnitureFits("desk", u, v, yaw) || !FurnitureFits("desk_chair", chairU, v, -yaw)) continue;
    Furniture("desk", u, v, yaw); Furniture("desk_chair", chairU, v, -yaw);
    Surface(u, v, 0.8769f, 2.229f, 0.896f, true, yaw); placedDesk = true;
   }
  case .Dining:
   Furniture(variant == 0 ? "dining_table" : "table2", 3.75f, 1.9f, 90);
   // Chair 03 is a bench: use one centred bench instead of overlapping two seats.
   if (variant == 2) Furniture("chair3", 2.5f, 1.9f, -90);
   else { Furniture("dining_chair", 2.5f, 1.3f, -90); Furniture("chair2", 2.5f, 2.5f, -90); }
   Furniture("chair2", 5, 1.3f, 90); Furniture("dining_chair", 5, 2.5f, 90);
   Surface(3.75f, 1.9f, variant == 0 ? 0.8528f : 1.026f, variant == 0 ? 1.299f : 0.85f, variant == 0 ? 2.105f : 1.4f, false);
   Furniture("dresser", 4.85f, length - 0.45f); Surface(4.85f, length - 0.45f, 0.70f, 0.86f, 0.58f, false);
  case .Kitchen:
   Furniture("counter", 2.65f, 0.7f, 180); Furniture("counter_sink", 3.67f, 0.7f, 180); Furniture("counter", 4.69f, 0.7f, 180);
   Surface(4.69f, 0.7f, 0.9496f, 1, 1.033f, false); Surface(2.65f, 0.7f, 0.9496f, 1, 1.033f, false);
   Furniture("fridge", 2.65f, length - 0.65f); Furniture("counter", 3.68f, length - 0.7f); Furniture("counter", 4.7f, length - 0.7f);
   Clutter(variant == 0 ? "microwave" : "toaster", 3.68f, length - 0.7f, 0.9496f);
   Clutter("bread_bin", 4.7f, length - 0.4f, 0.9496f);
   Surface(4.7f, length - 0.7f, 0.9496f, 1, 1.033f, false);
   OptionalFurniture("shelf", 0.4f, length * 0.5f, -90);
  case .Bathroom:
   // A compact 5x5 bathroom, with the remaining wing width used as a laundry annex.
   let east = mRoom >= 4;
   Furniture("bath", east ? 4.2f : 0.8f, 3.25f, 90);
   Furniture("toilet", 2.5f, 4.45f); Furniture("sink", 2.5f, 0.65f, 180);
   Furniture("bedside", east ? 2.0f : 3.0f, 2.5f, east ? 90 : -90);
   Surface(east ? 2.0f : 3.0f, 2.5f, 0.4525f, 0.398f, 0.407f, false);
   Furniture("washer", east ? 6.9f : -1.9f, 2.5f, east ? 90 : -90);
   Surface(east ? 6.9f : -1.9f, 2.5f, 1.23f, 1.0f, 1.0f, false);
   Furniture("shelf", east ? 7.1f : -2.1f, 0.8f, east ? 90 : -90);
   Furniture("laundry_bin", east ? 6.9f : -1.9f, 3.6f);
   OptionalFurniture("shelf", east ? 0.4f : 4.6f, 3.0f, east ? -90 : 90);
  case .Study:
   Furniture("desk", 3.75f, 0.8f, 180); Furniture("desk_chair", 3.75f, 2.0f);
   if (variant != 2)
   {
    Clutter("monitor", 3.75f, 0.55f, 0.8769f, 180); Clutter("keyboard", 3.75f, 0.98f, 0.8769f, 180); Clutter("mouse", 4.35f, 0.98f, 0.8769f);
   }
   else Clutter("lamp2", 4.55f, 0.8f, 0.8769f);
   Surface(3.75f, 0.8f, 0.8769f, 2.229f, 0.896f, true, 180);
   Furniture("drawers", 4.85f, length - 0.65f); Surface(4.85f, length - 0.65f, 0.822f, 0.65f, 0.85f);
   Furniture("bookshelf", 2.45f, length - 0.4f);
  }
  if (plan.rooms[mRoom] != .Bathroom)
  {
   // Thin shelving lines room edges; the centre and paired cross-room doors stay open.
   OptionalFurniture("bookshelf", 0.36f, 2.2f, -90);
   OptionalFurniture(variant == 0 ? "shelf" : "bookshelf", 7.14f, length - 2.2f, 90);
   OptionalFurniture("bookshelf2", 3.75f, length - 0.4f);
   if (length >= 7.5f)
   {
    OptionalFurniture("shelf", 0.4f, length - 2.2f, -90);
    OptionalFurniture("shelf", 7.1f, 2.2f, 90);
   }
   OptionalFurniture("box", 0.5f, length * 0.5f);
  }
  HomeDetails();
  FillSurfaces();
  let stats = Part(scope $"RoomStats{mRoom}"); stats.Transform.LocalPosition = .((float)roomFurniture[mRoom], (float)roomClutter[mRoom], 0);
 }
 void HomeDetails()
 {
  let length = plan.depths[mRoom]; let width = plan.widths[mRoom]; let kind = plan.rooms[mRoom];
  // Fixtures are mesh props only: no Light components and no emissive materials.
  let fan = (kind == .Living || kind == .Bedroom) && plan.variants[mRoom] == 1;
  let fixture = fan ? "ceiling_fan" : (kind == .Kitchen ? "ceiling_light3" : "ceiling_light2");
  let height = TownCatalog.Size(fixture).y * (fan ? 0.75f : 1);
  Art(fixture, RoomPoint(width * 0.5f, length * 0.5f, 2.9f - height)); clutterCount++; roomClutter[mRoom]++;
  let picture = kind == .Kitchen || kind == .Study ? "clock" : (plan.variants[mRoom] == 2 ? "wall_art3" : "wall_art");
  let pictureY = kind == .Kitchen || kind == .Study ? 1.85f : 1.55f;
  for (int32 bay < 3)
  {
   let u = width * 0.5f + (bay == 0 ? 0.0f : (bay == 1 ? -1.1f : 1.1f));
   let at = RoomPoint(u, 0.14f, pictureY); let size = TownCatalog.Size(picture); bool clear = true;
   for (let window in mWindows)
    if (Math.Abs(at.x - window.at.x) < size.x * 0.5f + window.size.x * 0.5f && Math.Abs(at.z - window.at.z) < 0.35f + window.size.z * 0.5f) clear = false;
   if (clear) { Clutter(picture, u, 0.14f, pictureY, 180); break; }
  }
  if (kind != .Bathroom && kind != .Kitchen)
  {
   Clutter("rug", width * 0.5f, kind == .Living ? 2.2f : (kind == .Dining ? 1.9f : Math.Min(length - 2.8f, 4.1f)), 0.003f);
   OptionalFurniture("floor_lamp", 2.3f, 0.65f, 180);
  }
  if (kind == .Bathroom) Clutter("bathmat", width * 0.5f, 1.65f, 0.003f);
  // Switch follows the physical hall doorway even when the room template is rotated.
  let doorV = kind == .Bathroom ? 1.25f : (float)(int32)(length / 5) * 2.5f + 1.25f;
  let u = mRoom < 4 ? width - 0.15f : 0.15f;
  let v = Math.Min(length - 0.25f, doorV + 1.0f);
  Clutter("light_switch", mFlip ? width - u : u, mFlip ? length - v : v, 1.1f, (mRoom < 4 ? 90 : -90) - (mFlip ? 180 : 0));
 }
 bool HallDoor(int32 side, float z)
 {
  for (int32 row < 4)
  {
   let room = side * 4 + row; let start = plan.starts[room]; let length = plan.depths[room];
   if (z < start || z >= start + length) continue;
   let part = (int32)((z - start) / 2.5f);
   return part == (plan.rooms[room] == .Bathroom ? 0 : (int32)(length / 2.5f) / 2);
  }
  return true;
 }
 void HallProp(StringView key, Vector3 at, float yaw = 0)
 {
  Art(key, at, yaw); clutterCount++; hallClutterCount++;
 }
 void DecorateHall()
 {
  for (int32 tile = 1; tile < 12; tile += 2)
  {
   let z = -15 + tile * 2.5f + 1.25f; int32 side = (tile / 2) % 2;
   if (HallDoor(side, z)) side = 1 - side;
   if (HallDoor(side, z)) continue;
   let left = side == 0; let yaw = left ? -90.0f : 90.0f;
   let x = left ? -HallHalf + 0.25f : HallHalf - 0.25f;
   Art("bookshelf2", .(x, 0, z), yaw); furnitureCount++; hallFurnitureCount++;
   let size = TownCatalog.Size("bookshelf2"); let rotated = Quaternion.Euler(0, yaw, 0) * size;
   Collision("Furniture collision", .(x, size.y * 0.5f, z), .(Math.Abs(rotated.x), size.y, Math.Abs(rotated.z)), true);
   HallProp("art", .(x, 1.029f, z - 0.2f), yaw);
   HallProp((tile % 4 == 1) ? "candles" : "mug", .(x, 1.029f, z + 0.22f), yaw);
   // Books occupy the exposed lower shelf; the console top remains believable and uncluttered.
   HallProp("books2", .(x, 0.703f, z), yaw);
   HallProp((tile % 4 == 1) ? "wall_art2" : "wall_art3", .(left ? -HallHalf + 0.13f : HallHalf - 0.13f, 1.6f, z), yaw);
  }
  for (int32 tile = 1; tile < 12; tile += 3)
   HallProp("ceiling_light2", .(0, 2.9f - TownCatalog.Size("ceiling_light2").y, -15 + tile * 2.5f + 1.25f));
  HallProp("doormat", .(0, 0.003f, -13.7f));
  let stats = Part("HallStats"); stats.Transform.LocalPosition = .((float)hallFurnitureCount, (float)hallClutterCount, 0);
 }
 public bool HallClearCheck()
 {
  for (let obstacle in mObstacles)
   if (obstacle.furniture && Math.Abs(obstacle.at.x) - obstacle.size.x * 0.5f < 0.7f) return false;
  List<Vector3> path = scope .(); return hallFurnitureCount >= 2 && Route(.(0, 0, -13), .(0, 0, 13), path);
 }
 /// Project horizontal motion against furniture at every height, preventing jumping onto it.
 public Vector3 Constrain(Vector3 from, Vector3 velocity, float dt)
 {
  if (dt <= 0) return velocity;
  var to = from + velocity * dt;
  for (let obstacle in mObstacles)
  {
   if (!obstacle.furniture) continue;
   let half = obstacle.size * 0.5f + Vector3(0.36f, 0, 0.36f);
   let low = obstacle.at - half; let high = obstacle.at + half;
   if (from.z > low.z && from.z < high.z)
   {
    if (from.x <= low.x && to.x > low.x) to.x = low.x;
    if (from.x >= high.x && to.x < high.x) to.x = high.x;
   }
   if (to.x > low.x && to.x < high.x)
   {
    if (from.z <= low.z && to.z > low.z) to.z = low.z;
    if (from.z >= high.z && to.z < high.z) to.z = high.z;
   }
  }
  return .((to.x - from.x) / dt, velocity.y, (to.z - from.z) / dt);
 }
 public bool ChooseSpawn(bool zombie, bool joining, List<Vector3> occupied, List<Vector3> enemies, out Vector3 position)
 {
  position = .Zero; float best = -float.MaxValue; bool found = false;
  for (int32 index < (int32)nav.cells.Count)
  {
   let cell = nav.cells[index]; if (!cell.walkable) continue;
   let at = cell.position;
   if (!joining && (zombie ? at.z < 9.5f : at.z > -9.5f)) continue;
   if (Math.Abs(at.z) > 13.5f || Math.Abs(at.x) > OuterHalf - 0.6f) continue;
   bool clear = true;
   for (let other in occupied) if (Vector3.Distance(at, other) < 1.25f) { clear = false; break; }
   if (!clear) continue;
   float separation = 100;
   for (let enemy in enemies) separation = Math.Min(separation, Vector3.Distance(at, enemy));
   if (separation < (joining ? 10.0f : 18.0f)) continue;
   // Farthest from the opposing team, then distribute ties deterministically.
   let jitter = (float)(((uint32)index * 1103515245 + mRandom) % 997) / 997;
   let score = enemies.Count > 0 ? separation + jitter * 0.15f : jitter - Math.Abs(at.x) * 0.015f;
   if (score > best) { best = score; position = at + Vector3(0, 0.1f, 0); found = true; }
  }
  return found;
 }
 public void AuditHall()
 {
  for (let ob in mPool)
  {
   let renderer = ob.GetComponent<MeshRenderer>(); if (renderer == null || !renderer.IsActiveAndEnabled) continue;
   let mesh = renderer.ActiveMesh; if (mesh == null) continue;
   // House parts are static; no network presentation correction is applied.
   let bounds = mesh.Bounds.Transformed(ob.Transform.LocalToWorld);
   if (bounds.min.x < 0.65f && bounds.max.x > -0.65f && bounds.min.y < 2.8f && bounds.max.y > 1.7f)
    Log.Info(scope $"HALL MESH {renderer.mesh} pos={ob.Transform.LocalPosition} min={bounds.min} max={bounds.max}");
  }
 }
 public bool ValidateShell()
 {
  for (let ob in mPool)
  {
   let mesh = ob.GetComponent<MeshRenderer>();
   if (mesh == null || !mesh.IsActiveAndEnabled || !mesh.mesh.StartsWith("Models/Town/")) continue;
   let key = StringView(mesh.mesh).Substring(12, mesh.mesh.IndexOf('#') - 16);
   let low = ob.Transform.LocalPosition.y + TownCatalog.Minimum(key).y * ob.Transform.LocalScale.y;
   let high = low + TownCatalog.Size(key).y * ob.Transform.LocalScale.y;
   if (key == "ceiling" && Math.Abs(low - 2.9f) > 0.02f) { Log.Info(scope $"SHELL ceiling {low}"); return false; }
   if (key == "door" && Math.Abs(ob.Transform.LocalPosition.y) > 0.001f) return false;
   if (key == "roof" && low < 3.01f) { Log.Info(scope $"SHELL roof {low}"); return false; }
   if (key == "wall_outer" || key == "wall_window" || key == "wall_entry")
   {
    var towardInside = -ob.Transform.LocalPosition; towardInside.y = 0;
    if (Vector3.Dot(ob.Transform.LocalRotation * Vector3.Forward, towardInside.Normalized) < 0.2f) { Log.Info(scope $"SHELL facing {key} {ob.Transform.LocalPosition}"); return false; }
   }
   else if (key.StartsWith("ceiling_")) { if (low < 2.5f || high > 2.91f) return false; }
   else if (!key.StartsWith("wall") && key != "window" && key != "door" && key != "floor" && key != "ceiling" && key != "roof" && (low < -0.01f || high > 2.5f)) { Log.Info(scope $"SHELL prop {key} {low} {high}"); return false; }
  }
  return true;
 }
 public bool WorkstationAccessCheck()
 {
  List<Vector3> path = scope .();
  for (let ob in mPool)
  {
   if (ob.Name != "desk" || ob.GetComponent<MeshRenderer>()?.IsActiveAndEnabled != true) continue;
   bool accessible = false;
   for (int32 side < 2)
   {
    let at = ob.Transform.LocalPosition + ob.Transform.LocalRotation * Vector3(side == 0 ? -1.2f : 1.2f, 0, -1.35f);
    path.Clear();
    if (Route(.(0, 0, -10), at, path) && path.Count > 0 && Vector3.Distance(path[path.Count - 1], at) < 0.55f) accessible = true;
   }
   if (!accessible) return false;
  }
  return true;
 }
 public bool NoClimbCheck()
 {
  for (let obstacle in mObstacles)
  {
   if (!obstacle.furniture) continue;
   let start = obstacle.at + Vector3(-obstacle.size.x * 0.5f - 0.8f, 3, 0);
   let velocity = Constrain(start, .(10, 0, 0), 0.2f);
   if (start.x + velocity.x * 0.2f > obstacle.at.x - obstacle.size.x * 0.5f - 0.35f) return false;
  }
  return true;
 }
 void BakeNavigation()
 {
  let error = scope String();
  nav.Configure(.(-OuterHalf, -0.25f, -15), .(OuterHalf * 2, 0.5f, 30), 0.5f, false, 16, error);
  for (int32 z < nav.depth) for (int32 x < nav.width)
  {
   let at = nav.Center(x, 0, z); bool free = true;
   for (let obstacle in mObstacles)
    if (Math.Abs(at.x - obstacle.at.x) < obstacle.size.x * 0.5f + 0.40f && Math.Abs(at.z - obstacle.at.z) < obstacle.size.z * 0.5f + 0.40f) { free = false; break; }
   let index = nav.Index(x, 0, z); var cell = nav.cells[index]; cell.position = .(at.x, 0, at.z); cell.walkable = free; nav.cells[index] = cell;
  }
  for (int32 i < (int32)nav.cells.Count)
  {
   var cell = nav.cells[i]; cell.links = 0;
   if (cell.walkable) for (int32 dir < 4) { let next = nav.Neighbor(i, dir); if (next >= 0 && nav.cells[next].walkable) cell.links |= (uint32)1 << dir; }
   nav.cells[i] = cell;
  }
  nav.Touch();
 }
 public bool Route(Vector3 from, Vector3 to, List<Vector3> path) => nav.FindPath(from, to, path, 2);
 void Build(int32 seed)
 {
  Collision("Floor collision", .(0, -0.15f, 0), .(OuterHalf * 2, 0.3f, 30));
  Collision("Ceiling collision", .(0, 3.05f, 0), .(OuterHalf * 2, 0.3f, 30));
  for (int32 x < 7) for (int32 z < 12)
  {
   let at = Vector3(-OuterHalf + x * 2.5f + (x > 3 ? 1 : 0), 0, -15 + z * 2.5f);
   let scale = x == 3 ? 1.4f : 1.0f;
   Art("floor", at, 0, scale); Art("ceiling", at, 0, scale); Art("roof", at + Vector3(0, 0.12f, 0), 0, scale);
  }
  for (int32 x < 7)
  {
   Wall(.(-OuterHalf + x * 2.5f + (x > 3 ? 1 : 0) + (x == 3 ? 0.5f : 0), 0, -15), 0, x == 3, true);
   if (x == 3)
   {
    Wall(.(-HallHalf, 0, -15), 0, false, true, false, 0.2f);
    Wall(.(1.25f, 0, -15), 0, false, true, false, 0.2f);
   }
   Wall(.(-OuterHalf + 2.5f + x * 2.5f + (x >= 3 ? 1 : 0), 0, 15), 180, false, true, x != 3 && x % 3 == 1, x == 3 ? 1.4f : 1);
  }
  Art("door", .(-1.25f + 0.63f, 0, -15)); Collision("Locked exit", .(0, 1.15f, -15), .(1.3f, 2.3f, 0.25f));
  for (int32 z < 12)
  {
   Wall(.(-OuterHalf, 0, -12.5f + z * 2.5f), 90, false, true, z % 3 == 1);
   Wall(.(OuterHalf, 0, -15 + z * 2.5f), -90, false, true, z % 3 == 1);
  }
  for (int32 side < 2) for (int32 row < 4)
  {
   mRoom = side * 4 + row;
   let roomZ = plan.starts[mRoom]; let length = plan.depths[mRoom]; let startX = side == 0 ? -OuterHalf : HallHalf;
   let bathroom = plan.rooms[mRoom] == .Bathroom; let parts = (int32)(length / 2.5f);
   for (int32 part < parts) Wall(.(side == 0 ? -HallHalf : HallHalf, 0, roomZ + part * 2.5f), -90, part == (bathroom ? 0 : parts / 2));
   if (row < 3) for (int32 part < 3) Wall(.(startX + part * 2.5f, 0, roomZ + length), 0, part != 1);
   if (bathroom) for (int32 part < 2) Wall(.(side == 0 ? -HallHalf - 5 : HallHalf + 5, 0, roomZ + part * 2.5f), -90, part == 0);
   mFlip = !bathroom && seed != 0 && Next() % 2 == 0; Furnish();
  }
  DecorateHall();
 }
}
