using System;
using System.Collections;
using Tessera;
namespace ZombieTag;

extension House
{
 List<Obstacle> mVisualBlocks = new .() ~ delete _;
 static bool SegmentBox(Vector3 from, Vector3 to, Vector3 low, Vector3 high)
 {
  let delta = to - from;
  float[3] a = .(from.x, from.y, from.z), d = .(delta.x, delta.y, delta.z);
  float[3] lo = .(low.x, low.y, low.z), hi = .(high.x, high.y, high.z);
  float start = 0.001f, end = 0.999f;
  for (int32 axis < 3)
  {
   if (Math.Abs(d[axis]) < 0.00001f) { if (a[axis] < lo[axis] || a[axis] > hi[axis]) return false; continue; }
   let t1 = (lo[axis] - a[axis]) / d[axis], t2 = (hi[axis] - a[axis]) / d[axis];
   start = Math.Max(start, Math.Min(t1, t2)); end = Math.Min(end, Math.Max(t1, t2));
   if (start > end) return false;
  }
  return true;
 }
 public bool AttackBlocked(Vector3 from, Vector3 to)
 {
  // Query house solids only: virtual character bodies must not occlude their own attacks.
  for (let ob in mObstacles) if (SegmentBox(from, to, ob.at - ob.size * 0.5f, ob.at + ob.size * 0.5f)) return true;
  return false;
 }
 // Sweep the bot's footprint rather than a sight ray, so shortcuts cannot
 // cut across a wall or graze furniture at a doorway.
 public bool BotSegmentClear(Vector3 from, Vector3 to)
 {
  let a = Vector3(from.x, 0, from.z), b = Vector3(to.x, 0, to.z);
  for (let ob in mObstacles)
  {
   let half = ob.size * 0.5f;
   if (SegmentBox(a, b, .(ob.at.x - half.x - 0.40f, -1, ob.at.z - half.z - 0.40f),
    .(ob.at.x + half.x + 0.40f, 1, ob.at.z + half.z + 0.40f))) return false;
  }
  return true;
 }
 public bool BotRoute(Vector3 from, Vector3 to, List<Vector3> path)
 {
  if (!Route(from, to, path)) return false;
  // String-pull the grid route from the bot's actual position. This also
  // avoids steering backwards to a cell center on every perception update.
  var anchor = from; int32 next = 0;
  while (next < path.Count)
  {
   int32 furthest = next;
   for (int32 candidate = (int32)path.Count - 1; candidate > next; candidate--)
    if (BotSegmentClear(anchor, path[candidate])) { furthest = candidate; break; }
   while (furthest > next) { path.RemoveAt(next); furthest--; }
   anchor = path[next]; next++;
  }
  return true;
 }
 void CacheVisualBlocks()
 {
  mVisualBlocks.Clear();
  for (let ob in mPool)
  {
   let renderer = ob.GetComponent<MeshRenderer>(); if (renderer == null || !renderer.IsActiveAndEnabled) continue;
   let mesh = renderer.ActiveMesh; if (mesh == null) continue;
   let bounds = mesh.Bounds.Transformed(ob.Transform.LocalToWorld);
   mVisualBlocks.Add(.(bounds.Center, bounds.max - bounds.min));
  }
 }
 bool ClearKeyColumn(Vector3 at)
 {
  for (let ob in mVisualBlocks)
  {
   let low = ob.at - ob.size * 0.5f, high = ob.at + ob.size * 0.5f;
   if (at.x + 0.075f > low.x && at.x - 0.075f < high.x && at.z + 0.075f > low.z && at.z - 0.075f < high.z && high.y > at.y - 0.005f && low.y < at.y + 0.28f) return false;
  }
  return true;
 }
 public bool KeyVisible(Vector3 at)
 {
  if (!ClearKeyColumn(at)) return false;
  for (let cell in nav.cells)
  {
   if (!cell.walkable || Vector3.Distance(cell.position, at) > 1.65f) continue;
   let eye = cell.position + Vector3(0, 1.64f, 0); bool visible = true;
   for (let ob in mVisualBlocks)
    if (SegmentBox(eye, at + Vector3(0, 0.015f, 0), ob.at - ob.size * 0.5f, ob.at + ob.size * 0.5f)) { visible = false; break; }
   if (visible) return true;
  }
  return false;
 }
}

extension House
{
 public bool LaundryRouteCheck()
 {
  for (int32 room < 8)
  {
   if (plan.rooms[room] != .Bathroom) continue;
   let x = room >= 4 ? HallHalf + 5.75f : -HallHalf - 5.75f;
   List<Vector3> path = scope .();
   let from = Vector3(x, 0, plan.starts[room] + 1.25f), to = Vector3(x, 0, plan.starts[room] + plan.depths[room] - 0.6f);
   if (!Route(from, to, path) || path.Count == 0 || Vector3.Distance(path[path.Count - 1], to) > 0.8f) return false;
  }
  return true;
 }
}
