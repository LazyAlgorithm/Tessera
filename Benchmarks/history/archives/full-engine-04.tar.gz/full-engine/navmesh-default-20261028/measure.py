#!/usr/bin/env python3
from pathlib import Path
import subprocess,statistics,csv,json,hashlib
O=Path(__file__).resolve().parent;R=O.parents[2];runs=[];rows=[]
jobs=[]
for case,n in [('ai-nav-path',100),('ai-navmesh-path',100),('ai-navmesh-path-batch',100),('ai-navmesh-path-batch',1000)]:jobs.append(('features',case,n,[]))
for n in [1,100]:
 for mode in [[],['--navmesh']]:jobs.append(('navigation-load','nav-dynamic',n,mode))
for project,case,n,options in jobs:
 b=R/'Benchmarks/full-engine'/project/'build/Release_Linux64/Benchmark/Benchmark'
 for repeat in range(3):
  args=[str(b),case,str(n),'40','120',*options];p=subprocess.run(args,capture_output=True,text=True,timeout=180);name=f'{case}-{n}-'+('navmesh' if options or 'navmesh' in case else 'grid')+f'-{repeat}';(O/(name+'.log')).write_text(p.stdout+'\n'+p.stderr)
  values=[float(x.rsplit(',',1)[1]) for x in p.stdout.splitlines() if x.startswith('BENCH,tessera,')];assert p.returncode==0 and len(values)==120,(name,p.returncode,len(values))
  checks={x.split(',')[1]:x.split(',',2)[2] for x in p.stdout.splitlines() if x.startswith('CHECK,')}
  rows.append([name,case,n,'navmesh' if options or 'navmesh' in case else 'grid',repeat,statistics.median(values)])
  runs.append({'name':name,'args':args,'binary_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'exit':p.returncode,'checks':checks});print(name,statistics.median(values),flush=True)
with (O/'results.csv').open('w') as f:w=csv.writer(f);w.writerow(['name','case','count','backend','repeat','median_ms']);w.writerows(rows)
(O/'measure-manifest.json').write_text(json.dumps(runs,indent=2)+'\n')
