// Recast/Detour walking backend. Meshes are immutable during queries; each worker owns its query scratch.
#include <Jolt/Jolt.h>
#include <Jolt/Physics/Collision/Shape/Shape.h>
#include "joltc.h"
#include "Recast.h"
#include "DetourNavMesh.h"
#include "DetourNavMeshBuilder.h"
#include "DetourNavMeshQuery.h"
#include "DetourCommon.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <memory>
#include <vector>
#include <cstdint>
#include <cstdio>

struct TnNavConfig { float min[3], max[3], cs,ch,radius,height,climb,slope; };
struct TnNavVolume { float center[3], rotation[4], half[3], cost; int cylinder, obstacle; };
struct TnNavLink { float start[3],end[3],radius,cost; int bidirectional,id; };
struct TnNav {
    TnNavConfig config{};
    std::vector<float> triangles;
    rcHeightfield* base=nullptr;
    dtNavMesh* mesh=nullptr;
    float costs[DT_MAX_AREAS]{};
    unsigned revision=0;
    int polygons=0;
    ~TnNav(){rcFreeHeightField(base);dtFreeNavMesh(mesh);}
};
struct TnNavQuery {
    dtNavMeshQuery query;
    const TnNav* owner=nullptr;
    unsigned revision=0;
    int nodes=0;
    std::vector<dtPolyRef> corridor, straightRefs;
    std::vector<float> points,straight;
    std::vector<unsigned char> flags;
    std::vector<int> legs;
};
static bool finite3(const float* p){return std::isfinite(p[0])&&std::isfinite(p[1])&&std::isfinite(p[2]);}
static bool valid(const TnNavConfig& c){
    if(!finite3(c.min)||!finite3(c.max)||c.cs<.01f||!std::isfinite(c.cs)||c.ch<.005f||!std::isfinite(c.ch)||c.radius<=0||!std::isfinite(c.radius)||c.height<2*c.radius||!std::isfinite(c.height)||c.climb<0||!std::isfinite(c.climb)||c.slope<0||c.slope>=90||!std::isfinite(c.slope))return false;
    for(int i=0;i<3;++i)if(c.max[i]<=c.min[i])return false;
    double w=std::ceil((c.max[0]-c.min[0])/c.cs),h=std::ceil((c.max[2]-c.min[2])/c.cs);
    return w<=4096&&h<=4096&&w*h<=4000000&&(c.max[1]-c.min[1])/c.ch<RC_SPAN_MAX_HEIGHT&&c.height/c.ch<RC_SPAN_MAX_HEIGHT&&c.climb/c.ch<RC_SPAN_MAX_HEIGHT&&c.radius/c.cs<=4096;
}
static bool baseBuild(TnNav& n){
    if(n.base)return true;
    auto& c=n.config;rcContext ctx(false);
    // Keep rasterizer float-to-cell conversions within range, including geometry outside the bake bounds.
    for(size_t i=0;i<n.triangles.size();++i)if(!std::isfinite(n.triangles[i])||std::abs((double(n.triangles[i])-c.min[i%3])/(i%3==1?c.ch:c.cs))>1e8)return false;
    std::unique_ptr<rcHeightfield,decltype(&rcFreeHeightField)> hf(rcAllocHeightfield(),rcFreeHeightField);
    int w,h;rcCalcGridSize(c.min,c.max,c.cs,&w,&h);
    if(!hf||!rcCreateHeightfield(&ctx,*hf,w,h,c.min,c.max,c.cs,c.ch))return false;
    const int count=int(n.triangles.size()/9);
    std::vector<int> indices(count*3);for(int i=0;i<count*3;++i)indices[i]=i;
    std::vector<unsigned char> areas(count,RC_NULL_AREA);
    if(count){
        rcMarkWalkableTriangles(&ctx,c.slope,n.triangles.data(),count*3,indices.data(),count,areas.data());
        if(!rcRasterizeTriangles(&ctx,n.triangles.data(),count*3,indices.data(),areas.data(),count,*hf,int(std::floor(c.climb/c.ch))))return false;
    }
    const int climb=int(std::floor(c.climb/c.ch)),height=int(std::ceil(c.height/c.ch));
    rcFilterLowHangingWalkableObstacles(&ctx,climb,*hf);
    rcFilterLedgeSpans(&ctx,height,climb,*hf);
    rcFilterWalkableLowHeightSpans(&ctx,height,*hf);
    n.base=hf.release();return true;
}
// Monotone-chain hull of the projected, fully rotated box corners.
static std::vector<float> footprint(const TnNavVolume& v,float& ymin,float& ymax){
    struct Point{float x,z;};std::vector<Point> p;
    ymin=1e30f;ymax=-1e30f;
    JPH::Quat q(v.rotation[0],v.rotation[1],v.rotation[2],v.rotation[3]);
    const int count=v.cylinder?24:8;
    for(int i=0;i<count;++i){
        JPH::Vec3 a;
        if(v.cylinder){float angle=float(i/2)*6.28318530718f/12;a=JPH::Vec3(std::cos(angle)*v.half[0]/.965925826f,i%2?v.half[1]:-v.half[1],std::sin(angle)*v.half[0]/.965925826f);}
        else a=JPH::Vec3(i&1?v.half[0]:-v.half[0],i&2?v.half[1]:-v.half[1],i&4?v.half[2]:-v.half[2]);
        a=q*a+JPH::Vec3(v.center[0],v.center[1],v.center[2]);p.push_back({a.GetX(),a.GetZ()});ymin=std::min(ymin,a.GetY());ymax=std::max(ymax,a.GetY());
    }
    std::sort(p.begin(),p.end(),[](Point a,Point b){return a.x<b.x||(a.x==b.x&&a.z<b.z);});
    p.erase(std::unique(p.begin(),p.end(),[](Point a,Point b){return a.x==b.x&&a.z==b.z;}),p.end());
    auto cross=[](Point a,Point b,Point c){return (b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x);};
    std::vector<Point> hull;
    for(auto a:p){while(hull.size()>=2&&cross(hull[hull.size()-2],hull.back(),a)<=0)hull.pop_back();hull.push_back(a);}
    auto lower=hull.size();for(int i=int(p.size())-2;i>=0;--i){while(hull.size()>lower&&cross(hull[hull.size()-2],hull.back(),p[i])<=0)hull.pop_back();hull.push_back(p[i]);}
    if(hull.size()>1)hull.pop_back();std::vector<float> out;for(auto a:hull){out.push_back(a.x);out.push_back(0);out.push_back(a.z);}return out;
}
static bool meshBuild(TnNav& n,const TnNavVolume* volumes,int nv,const TnNavLink* links,int nl){
    if(!baseBuild(n))return false;
    rcContext ctx(false);auto& c=n.config;
    std::unique_ptr<rcCompactHeightfield,decltype(&rcFreeCompactHeightfield)> chf(rcAllocCompactHeightfield(),rcFreeCompactHeightfield);
    std::unique_ptr<rcContourSet,decltype(&rcFreeContourSet)> contours(rcAllocContourSet(),rcFreeContourSet);
    std::unique_ptr<rcPolyMesh,decltype(&rcFreePolyMesh)> poly(rcAllocPolyMesh(),rcFreePolyMesh);
    std::unique_ptr<rcPolyMeshDetail,decltype(&rcFreePolyMeshDetail)> detail(rcAllocPolyMeshDetail(),rcFreePolyMeshDetail);
    if(!chf||!contours||!poly||!detail||!rcBuildCompactHeightfield(&ctx,int(std::ceil(c.height/c.ch)),int(std::floor(c.climb/c.ch)),*n.base,*chf))return false;
    float costs[DT_MAX_AREAS];std::fill(costs,costs+DT_MAX_AREAS,1.f);int nextArea=2;
    auto areaFor=[&](float cost)->int{for(int i=1;i<nextArea;++i)if(costs[i]==cost)return i;if(nextArea>=RC_WALKABLE_AREA)return -1;costs[nextArea]=cost;return nextArea++;};
    // Highest cost wins overlaps, independent of component order; blocking wins over all costs.
    std::vector<int> order(nv);for(int i=0;i<nv;++i){
        order[i]=i;const auto& v=volumes[i];
        if(!finite3(v.center)||!finite3(v.half)||v.half[0]<=0||v.half[1]<=0||v.half[2]<=0||!std::isfinite(v.cost))return false;
        float norm=0;for(float r:v.rotation){if(!std::isfinite(r))return false;norm+=r*r;}if(std::abs(norm-1)>.01f)return false;
    }
    std::stable_sort(order.begin(),order.end(),[&](int a,int b){return volumes[a].cost<volumes[b].cost;});
    for(int pass=0;pass<2;++pass)for(int i:order){
        auto& v=volumes[i];bool blocked=v.cost<=0;
        if(blocked!=(pass==1))continue;
        if(!finite3(v.center)||!finite3(v.half)||v.half[0]<=0||v.half[1]<=0||v.half[2]<=0||!std::isfinite(v.cost))return false;
        int area=blocked?RC_NULL_AREA:areaFor(std::max(v.cost,1.f));if(area<0)return false;
        float ymin,ymax;auto verts=footprint(v,ymin,ymax);
        if(v.obstacle)ymin-=c.height;
        if(verts.size()>=9)rcMarkConvexPolyArea(&ctx,verts.data(),int(verts.size()/3),ymin,ymax,(unsigned char)area,*chf);
    }
    if(!rcErodeWalkableArea(&ctx,int(std::ceil(c.radius/c.cs)),*chf))return false;
    if(!rcBuildDistanceField(&ctx,*chf)||!rcBuildRegions(&ctx,*chf,0,0,0)||!rcBuildContours(&ctx,*chf,1.3f,int(12/c.cs),*contours)||!rcBuildPolyMesh(&ctx,*contours,6,*poly))return false;
    if(!poly->npolys){dtFreeNavMesh(n.mesh);n.mesh=nullptr;n.polygons=0;++n.revision;return true;}
    if(poly->nverts>=65535||!rcBuildPolyMeshDetail(&ctx,*poly,*chf,c.cs*6,c.ch,*detail))return false;
    for(int i=0;i<poly->npolys;++i){if(poly->areas[i]==RC_WALKABLE_AREA)poly->areas[i]=1;poly->flags[i]=1;}
    std::vector<float> linkVertices,linkRadii;std::vector<unsigned char> linkDirs,linkAreas;std::vector<unsigned short> linkFlags;std::vector<unsigned> linkIds;
    for(int i=0;i<nl;++i){
        auto& l=links[i];if(!finite3(l.start)||!finite3(l.end)||!std::isfinite(l.radius)||l.radius<=0||!std::isfinite(l.cost)||l.cost<.1f||l.id<0)return false;
        int area=areaFor(l.cost);if(area<0)return false;
        linkVertices.insert(linkVertices.end(),l.start,l.start+3);linkVertices.insert(linkVertices.end(),l.end,l.end+3);linkRadii.push_back(l.radius);linkDirs.push_back(l.bidirectional?DT_OFFMESH_CON_BIDIR:0);linkAreas.push_back((unsigned char)area);linkFlags.push_back(2);linkIds.push_back(unsigned(l.id)+1);
    }
    dtNavMeshCreateParams params{};params.verts=poly->verts;params.vertCount=poly->nverts;params.polys=poly->polys;params.polyAreas=poly->areas;params.polyFlags=poly->flags;params.polyCount=poly->npolys;params.nvp=poly->nvp;
    params.detailMeshes=detail->meshes;params.detailVerts=detail->verts;params.detailVertsCount=detail->nverts;params.detailTris=detail->tris;params.detailTriCount=detail->ntris;
    params.offMeshConVerts=linkVertices.data();params.offMeshConRad=linkRadii.data();params.offMeshConDir=linkDirs.data();params.offMeshConAreas=linkAreas.data();params.offMeshConFlags=linkFlags.data();params.offMeshConUserID=linkIds.data();params.offMeshConCount=nl;
    params.walkableHeight=c.height;params.walkableRadius=c.radius;params.walkableClimb=c.climb;dtVcopy(params.bmin,poly->bmin);dtVcopy(params.bmax,poly->bmax);params.cs=c.cs;params.ch=c.ch;params.buildBvTree=true;
    unsigned char* data=nullptr;int size=0;
    if(!dtCreateNavMeshData(&params,&data,&size))return false;
    dtNavMesh* mesh=dtAllocNavMesh();if(!mesh){dtFree(data);return false;}
    if(dtStatusFailed(mesh->init(data,size,DT_TILE_FREE_DATA))){dtFreeNavMesh(mesh);dtFree(data);return false;}
    dtFreeNavMesh(n.mesh);n.mesh=mesh;n.polygons=poly->npolys;std::copy(costs,costs+DT_MAX_AREAS,n.costs);++n.revision;return true;
}
extern "C" void* tn_nav_create(JPH_PhysicsSystem* world,const TnNavConfig* config){
    if(!world||!config||!valid(*config))return nullptr;
    std::unique_ptr<TnNav> n(new TnNav());n->config=*config;
    const unsigned count=JPH_PhysicsSystem_GetNumBodies(world);std::vector<JPH_BodyID> ids(count);JPH_PhysicsSystem_GetBodies(world,ids.data(),count);
    const auto* locks=JPH_PhysicsSystem_GetBodyLockInterfaceNoLock(world);
    JPH::AABox box(JPH::Vec3(config->min[0],config->min[1],config->min[2]),JPH::Vec3(config->max[0],config->max[1],config->max[2]));
    for(auto id:ids){
        JPH_BodyLockRead lock{};JPH_BodyLockInterface_LockRead(locks,id,&lock);if(!lock.body)continue;
        auto* shape=reinterpret_cast<const JPH::Shape*>(JPH_Body_GetShape(const_cast<JPH_Body*>(lock.body)));
        JPH_RVec3 pos;JPH_Quat rot;JPH_Body_GetCenterOfMassPosition(lock.body,&pos);JPH_Body_GetRotation(lock.body,&rot);
        JPH::Shape::GetTrianglesContext context;shape->GetTrianglesStart(context,box,JPH::Vec3(float(pos.x),float(pos.y),float(pos.z)),JPH::Quat(rot.x,rot.y,rot.z,rot.w),JPH::Vec3::sReplicate(1));
        JPH::Float3 vertices[3*128];int found;
        while((found=shape->GetTrianglesNext(context,128,vertices))>0){
            if(n->triangles.size()+found*9>18000000){JPH_BodyLockInterface_UnlockRead(locks,&lock);return nullptr;}
            const float* ptr=&vertices[0].x;n->triangles.insert(n->triangles.end(),ptr,ptr+found*9);
        }
        JPH_BodyLockInterface_UnlockRead(locks,&lock);
    }
    if(!meshBuild(*n,nullptr,0,nullptr,0))return nullptr;return n.release();
}
extern "C" void tn_nav_destroy(TnNav* n){delete n;}
extern "C" int tn_nav_polygons(const TnNav* n){return n?n->polygons:0;}
extern "C" bool tn_nav_overlay(TnNav* n,const TnNavVolume* v,int nv,const TnNavLink* l,int nl){return n&&nv>=0&&nv<=65536&&nl>=0&&nl<=65535&&meshBuild(*n,v,nv,l,nl);}
extern "C" void* tn_nav_query_create(){return new TnNavQuery();}
extern "C" void tn_nav_query_destroy(TnNavQuery* q){delete q;}
static bool prepare(const TnNav* n,TnNavQuery* q,int nodes=4096){
    if(!n||!n->mesh||!q)return false;nodes=std::clamp(std::min(nodes,static_cast<const dtNavMesh*>(n->mesh)->getTile(0)->header->polyCount+8),32,65535);
    if(q->owner!=n||q->revision!=n->revision||q->nodes<nodes){if(dtStatusFailed(q->query.init(n->mesh,nodes)))return false;q->owner=n;q->revision=n->revision;q->nodes=nodes;}return true;
}
static dtQueryFilter filterFor(const TnNav* n,bool links=true){dtQueryFilter f;f.setIncludeFlags(links?3:1);for(int i=0;i<DT_MAX_AREAS;++i)f.setAreaCost(i,n->costs[i]);return f;}
static bool sample(const TnNav* n,TnNavQuery* q,const float* point,float distance,dtPolyRef& ref,float* found){
    ref=0;if(!finite3(point)||!std::isfinite(distance)||distance<0||!prepare(n,q))return false;
    const float extent[3]={std::max(distance,.01f),std::max(distance,.01f),std::max(distance,.01f)};auto f=filterFor(n,false);
    return dtStatusSucceed(q->query.findNearestPoly(point,extent,&f,&ref,found))&&ref&&dtVdistSqr(point,found)<=(distance+1e-4f)*(distance+1e-4f);
}
extern "C" unsigned tn_nav_sample(const TnNav* n,TnNavQuery* q,const float* p,float distance,float* found){dtPolyRef ref;return sample(n,q,p,distance,ref,found)?ref:0;}
extern "C" bool tn_nav_valid_poly(const TnNav* n,unsigned ref){return n&&n->mesh&&n->mesh->isValidPolyRef(ref);}
static void append(TnNavQuery* q,const float* p,int leg=-1){
    if(!q->points.empty()&&dtVdistSqr(q->points.data()+q->points.size()-3,p)<1e-10f)return;
    if(!q->points.empty())q->legs.push_back(leg);q->points.insert(q->points.end(),p,p+3);
}
static bool straight(TnNavQuery* q,const float* from,const float* to,const dtPolyRef* corridor,int count){
    int capacity=count+2;q->straight.resize(capacity*3);q->flags.resize(capacity);q->straightRefs.resize(capacity);int n=0;
    auto status=q->query.findStraightPath(from,to,corridor,count,q->straight.data(),q->flags.data(),q->straightRefs.data(),&n,capacity);
    if(dtStatusFailed(status)||(status&DT_BUFFER_TOO_SMALL))return false;
    for(int i=0;i<n;++i)append(q,q->straight.data()+i*3);return true;
}
extern "C" int tn_nav_path(const TnNav* n,TnNavQuery* q,const float* from,const float* to,float snap,int withLinks,int budget,int* visits,int* exceeded){
    *visits=0;*exceeded=0;if(!q)return 0;q->points.clear();q->legs.clear();
    if(!prepare(n,q,budget))return 0;
    dtPolyRef start,end;float a[3],b[3];if(!sample(n,q,from,snap,start,a)||!sample(n,q,to,snap,end,b))return 0;
    if(budget<=0){*exceeded=1;return 0;}
    auto filter=filterFor(n,withLinks!=0);
    auto status=q->query.initSlicedFindPath(start,end,a,b,&filter);
    if(dtStatusFailed(status))return 0;
    if(dtStatusInProgress(status))status=q->query.updateSlicedFindPath(budget,visits);
    if(dtStatusInProgress(status)||(status&DT_OUT_OF_NODES)){*exceeded=1;return 0;}
    if(dtStatusFailed(status))return 0;
    int count=0;int capacity=std::min(static_cast<const dtNavMesh*>(n->mesh)->getTile(0)->header->polyCount+1,65535);q->corridor.resize(capacity);
    status=q->query.finalizeSlicedFindPath(q->corridor.data(),&count,capacity);
    if(dtStatusFailed(status)||(status&(DT_PARTIAL_RESULT|DT_BUFFER_TOO_SMALL))||count<=0||q->corridor[count-1]!=end)return 0;
    // Split at off-mesh connections to retain both endpoints and per-leg gameplay link IDs.
    float segment[3];dtVcopy(segment,a);int first=0;
    for(int i=0;i<count;++i){
        const dtMeshTile* tile;const dtPoly* poly;
        if(dtStatusFailed(n->mesh->getTileAndPolyByRef(q->corridor[i],&tile,&poly)))return 0;
        if(poly->getType()!=DT_POLYTYPE_OFFMESH_CONNECTION)continue;
        if(i==0||i+1>=count)return 0;
        float x[3],y[3];if(dtStatusFailed(n->mesh->getOffMeshConnectionPolyEndPoints(q->corridor[i-1],q->corridor[i],x,y)))return 0;
        if(!straight(q,segment,x,q->corridor.data()+first,i-first))return 0;
        const auto* link=n->mesh->getOffMeshConnectionByRef(q->corridor[i]);if(!link)return 0;
        append(q,y,int(link->userId)-1);dtVcopy(segment,y);first=i+1;
    }
    if(!straight(q,segment,b,q->corridor.data()+first,count-first)){q->points.clear();q->legs.clear();return 0;}
    return int(q->points.size()/3);
}
extern "C" const float* tn_nav_points(const TnNavQuery* q){return q->points.data();}
extern "C" const int* tn_nav_legs(const TnNavQuery* q){return q->legs.data();}
extern "C" bool tn_nav_line(const TnNav* n,TnNavQuery* q,const float* from,const float* to,float* reached){
    dtVcopy(reached,from);if(!finite3(to)||!prepare(n,q))return false;
    dtPolyRef start;float a[3];if(!sample(n,q,from,std::max(n->config.climb+n->config.ch,.25f),start,a))return false;
    // Height snapping is allowed; moving a ray's X/Z start out of a blocked footprint is not.
    if(dtVdist2DSqr(a,from)>1e-6f)return false;
    auto f=filterFor(n,false);float t=0,normal[3];dtPolyRef path[4096];int count=0;
    auto cast=[&](dtPolyRef ref,float& fraction,int& lastCount)->dtStatus{return q->query.raycast(ref,a,to,&f,&fraction,normal,path,&lastCount,4096);};
    auto s=cast(start,t,count);dtPolyRef last=count>0?path[count-1]:start;
    if(dtStatusFailed(s)||(s&DT_BUFFER_TOO_SMALL))return false;
    // A vertex/edge belongs to several polygons. NearestPoly may choose the polygon behind the ray.
    // Retry only polygons containing the same start, never a point shifted across an obstacle.
    if(t<1e-5f){
        dtPolyRef candidates[64];int nc=0;const float ext[3]={.001f,.1f,.001f};
        auto status=q->query.queryPolygons(a,ext,&f,candidates,&nc,64);
        if(dtStatusFailed(status)||(status&DT_BUFFER_TOO_SMALL))return false;
        for(int i=0;i<nc;++i){
            float closest[3];bool over=false;
            if(dtStatusFailed(q->query.closestPointOnPoly(candidates[i],a,closest,&over))||dtVdist2DSqr(a,closest)>1e-8f||std::abs(closest[1]-a[1])>.1f)continue;
            float trial=0;int hits=0;auto result=cast(candidates[i],trial,hits);
            if(dtStatusSucceed(result)&&!(result&DT_BUFFER_TOO_SMALL)&&hits>0&&trial>t){t=trial;last=path[hits-1];count=hits;}
        }
    }
    if(count<=0)return false;
    float fraction=std::clamp(t,0.f,1.f);dtVlerp(reached,a,to,fraction);float height;
    if(dtStatusSucceed(q->query.getPolyHeight(last,reached,&height)))reached[1]=height;
    return t>=1-1e-5f&&std::abs(reached[1]-to[1])<=n->config.climb+n->config.ch+.05f;
}
// Portable geometry asset, rebuilt by Recast at load. Runtime annotations are scene-owned, not persisted.
static void put(std::vector<unsigned char>& out,unsigned v){for(int i=0;i<4;++i)out.push_back((unsigned char)(v>>(i*8)));}
static unsigned get(const unsigned char* data,size_t& at){unsigned v=0;for(int i=0;i<4;++i)v|=unsigned(data[at++])<<(i*8);return v;}
extern "C" int tn_nav_save_size(const TnNav* n){return n?int(56+n->triangles.size()*4):0;}
extern "C" bool tn_nav_save(const TnNav* n,unsigned char* data,int size){
    if(!n||size!=tn_nav_save_size(n))return false;std::vector<unsigned char> bytes;bytes.reserve(size);put(bytes,0x314D4E54u);float cfg[12];static_assert(sizeof(TnNavConfig)==sizeof(cfg));std::memcpy(cfg,&n->config,sizeof(cfg));
    for(int i=0;i<12;++i){unsigned word;std::memcpy(&word,cfg+i,4);put(bytes,word);}put(bytes,unsigned(n->triangles.size()));
    for(float f:n->triangles){unsigned word;std::memcpy(&word,&f,4);put(bytes,word);}std::memcpy(data,bytes.data(),bytes.size());return true;
}
extern "C" void* tn_nav_load(const unsigned char* bytes,int size){
    if(!bytes||size<56)return nullptr;size_t at=0;if(get(bytes,at)!=0x314D4E54u)return nullptr;std::unique_ptr<TnNav> n(new TnNav());
    float cfg[12];for(int i=0;i<12;++i){unsigned word=get(bytes,at);std::memcpy(cfg+i,&word,4);}std::memcpy(&n->config,cfg,sizeof(cfg));if(!valid(n->config))return nullptr;
    unsigned count=get(bytes,at);if(count>18000000||count%9||56ull+count*4ull!=unsigned(size))return nullptr;
    n->triangles.resize(count);for(auto& f:n->triangles){unsigned word=get(bytes,at);std::memcpy(&f,&word,4);if(!std::isfinite(f)||std::abs(f)>1e8f)return nullptr;}
    if(!meshBuild(*n,nullptr,0,nullptr,0))return nullptr;return n.release();
}
extern "C" void tn_nav_config(const TnNav* n,TnNavConfig* config){if(n&&config)*config=n->config;}
extern "C" int tn_nav_debug(const TnNav* n,float* vertices,int capacity){
    if(!n||!n->mesh)return 0;int count=0;
    const auto* tile=static_cast<const dtNavMesh*>(n->mesh)->getTile(0);
    for(int p=0;p<tile->header->polyCount;++p){const auto& poly=tile->polys[p];if(poly.getType()!=DT_POLYTYPE_GROUND)continue;
        for(int i=2;i<poly.vertCount;++i){if(vertices&&count+3<=capacity){dtVcopy(vertices+count*3,tile->verts+poly.verts[0]*3);dtVcopy(vertices+(count+1)*3,tile->verts+poly.verts[i-1]*3);dtVcopy(vertices+(count+2)*3,tile->verts+poly.verts[i]*3);}count+=3;}
    }return count;
}
