# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.102 ms | 1.105 ms | 1.120 ms | 1.127 ms | 1.222 ms | 0.932 ms |
| CPU main thread | 0.818 ms | 0.817 ms | 0.833 ms | 0.838 ms | 0.932 ms | 0.800 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 0.693 ms
- Other: 0.125 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 0.461 ms | 0.461 ms | 1000 | 0.476 ms | 64/64 |
| Frame | Other | 0.125 ms | 0.818 ms | 1 | 0.932 ms | 64/64 |
| Physics.Overlap | Physics | 0.108 ms | 0.657 ms | 1000 | 0.717 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.055 ms | 0.055 ms | 1000 | 0.066 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.036 ms | 0.036 ms | 1000 | 0.089 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.032 ms | 0.032 ms | 1000 | 0.059 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.222 ms, CPU 0.825 ms, GPU -

```
Frame  total 0.825 ms, self 0.126 ms
  Physics.Overlap  total 0.663 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.469 ms, self 0.469 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.054 ms, self 0.054 ms, 1000 calls
```

### Frame 42: interval 1.127 ms, CPU 0.822 ms, GPU -

```
Frame  total 0.822 ms, self 0.127 ms
  Physics.Overlap  total 0.660 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.464 ms, self 0.464 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.054 ms, self 0.054 ms, 1000 calls
```

### Frame 23: interval 1.124 ms, CPU 0.808 ms, GPU -

```
Frame  total 0.808 ms, self 0.125 ms
  Physics.Overlap  total 0.649 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.456 ms, self 0.456 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.053 ms, self 0.053 ms, 1000 calls
```

### Frame 21: interval 1.120 ms, CPU 0.818 ms, GPU -

```
Frame  total 0.818 ms, self 0.125 ms
  Physics.Overlap  total 0.658 ms, self 0.107 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.466 ms, self 0.466 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.054 ms, self 0.054 ms, 1000 calls
```

### Frame 39: interval 1.120 ms, CPU 0.824 ms, GPU -

```
Frame  total 0.824 ms, self 0.125 ms
  Physics.Overlap  total 0.664 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 0.468 ms, self 0.468 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.055 ms, self 0.055 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
