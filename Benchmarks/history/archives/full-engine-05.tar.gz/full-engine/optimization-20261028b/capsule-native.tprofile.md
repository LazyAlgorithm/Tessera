# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.447 ms | 3.449 ms | 3.482 ms | 3.486 ms | 3.596 ms | 3.266 ms |
| CPU main thread | 3.133 ms | 3.132 ms | 3.157 ms | 3.170 ms | 3.266 ms | 3.097 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 3.009 ms
- Other: 0.124 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.EPA | Physics | 2.033 ms | 2.033 ms | 1000 | 2.070 ms | 64/64 |
| Physics.Overlap.ConvexPair | Physics | 0.479 ms | 2.512 ms | 2000 | 2.547 ms | 64/64 |
| Physics.Overlap.NativeContacts | Physics | 0.244 ms | 2.756 ms | 1000 | 2.795 ms | 64/64 |
| Frame | Other | 0.124 ms | 3.133 ms | 1 | 3.266 ms | 64/64 |
| Physics.Overlap | Physics | 0.110 ms | 2.965 ms | 1000 | 3.091 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.061 ms | 0.061 ms | 1000 | 0.145 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.044 ms | 0.044 ms | 1000 | 0.050 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.038 ms | 0.038 ms | 1000 | 0.045 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.596 ms, CPU 3.116 ms, GPU -

```
Frame  total 3.116 ms, self 0.123 ms
  Physics.Overlap  total 2.952 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.745 ms, self 0.241 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 2.504 ms, self 0.476 ms, 2000 calls
        Physics.Overlap.EPA  total 2.029 ms, self 2.029 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 34: interval 3.486 ms, CPU 3.115 ms, GPU -

```
Frame  total 3.115 ms, self 0.123 ms
  Physics.Overlap  total 2.950 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.743 ms, self 0.241 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 2.502 ms, self 0.479 ms, 2000 calls
        Physics.Overlap.EPA  total 2.022 ms, self 2.022 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 44: interval 3.485 ms, CPU 3.116 ms, GPU -

```
Frame  total 3.115 ms, self 0.123 ms
  Physics.Overlap  total 2.950 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.739 ms, self 0.241 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 2.498 ms, self 0.478 ms, 2000 calls
        Physics.Overlap.EPA  total 2.021 ms, self 2.021 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.063 ms, self 0.063 ms, 1000 calls
```

### Frame 19: interval 3.482 ms, CPU 3.134 ms, GPU -

```
Frame  total 3.134 ms, self 0.124 ms
  Physics.Overlap  total 2.965 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.757 ms, self 0.247 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 2.510 ms, self 0.485 ms, 2000 calls
        Physics.Overlap.EPA  total 2.025 ms, self 2.025 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.063 ms, self 0.063 ms, 1000 calls
```

### Frame 24: interval 3.477 ms, CPU 3.122 ms, GPU -

```
Frame  total 3.122 ms, self 0.127 ms
  Physics.Overlap  total 2.950 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.746 ms, self 0.243 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 2.503 ms, self 0.477 ms, 2000 calls
        Physics.Overlap.EPA  total 2.026 ms, self 2.026 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
