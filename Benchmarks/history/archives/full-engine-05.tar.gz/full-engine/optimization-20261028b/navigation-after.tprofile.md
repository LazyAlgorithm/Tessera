# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.152 ms | 1.148 ms | 1.173 ms | 1.196 ms | 1.221 ms | 1.141 ms |
| CPU main thread | 1.089 ms | 1.084 ms | 1.112 ms | 1.133 ms | 1.144 ms | 1.078 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.069 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.LineClear | AI | 0.506 ms | 0.506 ms | 900 | 0.526 ms | 64/64 |
| Navigation.Search | AI | 0.417 ms | 0.508 ms | 100 | 0.531 ms | 64/64 |
| Navigation.Corridor | AI | 0.091 ms | 0.091 ms | 100 | 0.096 ms | 64/64 |
| Navigation.Smooth | AI | 0.033 ms | 0.539 ms | 100 | 0.559 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.089 ms | 1 | 1.144 ms | 64/64 |
| Navigation.Nearest | AI | 0.011 ms | 0.015 ms | 200 | 0.032 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.014 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.012 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.221 ms, CPU 1.089 ms, GPU -

```
Frame  total 1.088 ms, self 0.019 ms
  Navigation.Smooth  total 0.541 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.508 ms, self 0.508 ms, 900 calls
  Navigation.Search  total 0.507 ms, self 0.417 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 42: interval 1.196 ms, CPU 1.083 ms, GPU -

```
Frame  total 1.083 ms, self 0.019 ms
  Navigation.Smooth  total 0.537 ms, self 0.032 ms, 100 calls
    Navigation.LineClear  total 0.505 ms, self 0.505 ms, 900 calls
  Navigation.Search  total 0.504 ms, self 0.415 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 23: interval 1.174 ms, CPU 1.084 ms, GPU -

```
Frame  total 1.084 ms, self 0.019 ms
  Navigation.Smooth  total 0.535 ms, self 0.032 ms, 100 calls
    Navigation.LineClear  total 0.503 ms, self 0.503 ms, 900 calls
  Navigation.Search  total 0.508 ms, self 0.418 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 25: interval 1.173 ms, CPU 1.086 ms, GPU -

```
Frame  total 1.086 ms, self 0.019 ms
  Navigation.Smooth  total 0.541 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.508 ms, self 0.508 ms, 900 calls
  Navigation.Search  total 0.504 ms, self 0.415 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 58: interval 1.170 ms, CPU 1.086 ms, GPU -

```
Frame  total 1.086 ms, self 0.019 ms
  Navigation.Smooth  total 0.534 ms, self 0.033 ms, 100 calls
    Navigation.LineClear  total 0.501 ms, self 0.501 ms, 900 calls
  Navigation.Search  total 0.511 ms, self 0.420 ms, 100 calls
    Navigation.Corridor  total 0.091 ms, self 0.091 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
