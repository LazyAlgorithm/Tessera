# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.668 ms | 1.666 ms | 1.681 ms | 1.701 ms | 1.820 ms | 1.600 ms |
| CPU main thread | 1.452 ms | 1.448 ms | 1.467 ms | 1.474 ms | 1.600 ms | 1.441 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.386 ms
- Other: 0.066 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.113 ms | 1.113 ms | 1000 | 1.170 ms | 64/64 |
| Physics.Overlap | Physics | 0.112 ms | 1.350 ms | 1000 | 1.446 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.091 ms | 0.091 ms | 1000 | 0.096 ms | 64/64 |
| Frame | Other | 0.066 ms | 1.452 ms | 1 | 1.600 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.036 ms | 0.036 ms | 1000 | 0.086 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.033 ms | 0.033 ms | 1000 | 0.058 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.820 ms, CPU 1.467 ms, GPU -

```
Frame  total 1.467 ms, self 0.066 ms
  Physics.Overlap  total 1.366 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.130 ms, self 1.130 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.091 ms, self 0.091 ms, 1000 calls
```

### Frame 43: interval 1.701 ms, CPU 1.455 ms, GPU -

```
Frame  total 1.455 ms, self 0.069 ms
  Physics.Overlap  total 1.351 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.116 ms, self 1.116 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.091 ms, self 0.091 ms, 1000 calls
```

### Frame 13: interval 1.693 ms, CPU 1.461 ms, GPU -

```
Frame  total 1.461 ms, self 0.066 ms
  Physics.Overlap  total 1.361 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.125 ms, self 1.125 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.091 ms, self 0.091 ms, 1000 calls
```

### Frame 2: interval 1.681 ms, CPU 1.454 ms, GPU -

```
Frame  total 1.454 ms, self 0.070 ms
  Physics.Overlap  total 1.349 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.115 ms, self 1.115 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.091 ms, self 0.091 ms, 1000 calls
```

### Frame 47: interval 1.679 ms, CPU 1.453 ms, GPU -

```
Frame  total 1.453 ms, self 0.066 ms
  Physics.Overlap  total 1.352 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.117 ms, self 1.117 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.091 ms, self 0.091 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
