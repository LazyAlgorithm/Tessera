# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 9.313 ms | 9.315 ms | 9.370 ms | 9.388 ms | 9.776 ms | 8.681 ms |
| CPU main thread | 8.246 ms | 8.243 ms | 8.292 ms | 8.308 ms | 8.681 ms | 8.173 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 8.180 ms
- Other: 0.066 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.EPA | Physics | 3.930 ms | 3.930 ms | 1000 | 3.975 ms | 64/64 |
| Physics.Overlap.ConvexPair | Physics | 2.811 ms | 6.740 ms | 16820 | 7.074 ms | 64/64 |
| Physics.Overlap.NativeContacts | Physics | 1.141 ms | 7.882 ms | 1000 | 8.249 ms | 64/64 |
| Physics.Overlap | Physics | 0.118 ms | 8.136 ms | 1000 | 8.559 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.104 ms | 0.104 ms | 1000 | 0.153 ms | 64/64 |
| Frame | Other | 0.066 ms | 8.246 ms | 1 | 8.681 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.044 ms | 0.044 ms | 1000 | 0.052 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.033 ms | 0.033 ms | 1000 | 0.036 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 9.776 ms, CPU 8.275 ms, GPU -

```
Frame  total 8.275 ms, self 0.066 ms
  Physics.Overlap  total 8.165 ms, self 0.118 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 7.912 ms, self 1.151 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 6.761 ms, self 2.813 ms, 16820 calls
        Physics.Overlap.EPA  total 3.948 ms, self 3.948 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

### Frame 45: interval 9.388 ms, CPU 8.240 ms, GPU -

```
Frame  total 8.240 ms, self 0.066 ms
  Physics.Overlap  total 8.131 ms, self 0.118 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 7.877 ms, self 1.140 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 6.737 ms, self 2.811 ms, 16820 calls
        Physics.Overlap.EPA  total 3.926 ms, self 3.926 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

### Frame 56: interval 9.373 ms, CPU 8.211 ms, GPU -

```
Frame  total 8.211 ms, self 0.068 ms
  Physics.Overlap  total 8.099 ms, self 0.117 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 7.848 ms, self 1.139 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 6.709 ms, self 2.799 ms, 16820 calls
        Physics.Overlap.EPA  total 3.909 ms, self 3.909 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.102 ms, self 0.102 ms, 1000 calls
```

### Frame 23: interval 9.370 ms, CPU 8.228 ms, GPU -

```
Frame  total 8.228 ms, self 0.065 ms
  Physics.Overlap  total 8.119 ms, self 0.127 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 7.858 ms, self 1.132 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 6.726 ms, self 2.807 ms, 16820 calls
        Physics.Overlap.EPA  total 3.919 ms, self 3.919 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.102 ms, self 0.102 ms, 1000 calls
```

### Frame 35: interval 9.369 ms, CPU 8.237 ms, GPU -

```
Frame  total 8.237 ms, self 0.065 ms
  Physics.Overlap  total 8.128 ms, self 0.119 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 7.874 ms, self 1.144 ms, 1000 calls
      Physics.Overlap.ConvexPair  total 6.730 ms, self 2.798 ms, 16820 calls
        Physics.Overlap.EPA  total 3.932 ms, self 3.932 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
