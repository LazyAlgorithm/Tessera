# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 0.016 ms | 0.015 ms | 0.018 ms | 0.019 ms | 0.020 ms | 0.015 ms |
| CPU main thread | 0.014 ms | 0.013 ms | 0.016 ms | 0.017 ms | 0.017 ms | 0.013 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 0.013 ms
- Other: 0.000 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.LineClear | AI | 0.007 ms | 0.007 ms | 9 | 0.011 ms | 64/64 |
| Navigation.Search | AI | 0.004 ms | 0.006 ms | 1 | 0.008 ms | 64/64 |
| Navigation.Corridor | AI | 0.001 ms | 0.001 ms | 1 | 0.004 ms | 64/64 |
| Frame | Other | 0.000 ms | 0.013 ms | 1 | 0.017 ms | 64/64 |
| Navigation.Smooth | AI | 0.000 ms | 0.007 ms | 1 | 0.011 ms | 64/64 |
| Navigation.Nearest | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 64/64 |
| Navigation.Regions | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 64/64 |
| Navigation.Nodes | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 0.020 ms, CPU 0.014 ms, GPU -

```
```

### Frame 16: interval 0.019 ms, CPU 0.013 ms, GPU -

```
```

### Frame 62: interval 0.019 ms, CPU 0.014 ms, GPU -

```
```

### Frame 60: interval 0.018 ms, CPU 0.013 ms, GPU -

```
```

### Frame 15: interval 0.016 ms, CPU 0.017 ms, GPU -

```
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 1, 1, 1, 1, 1
- Path Search Visits: 25, 25, 25, 25, 25

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
