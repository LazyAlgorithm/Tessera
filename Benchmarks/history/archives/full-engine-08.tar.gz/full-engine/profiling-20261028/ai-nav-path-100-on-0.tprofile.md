# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.300 ms | 1.294 ms | 1.322 ms | 1.338 ms | 1.350 ms | 1.276 ms |
| CPU main thread | 1.239 ms | 1.233 ms | 1.260 ms | 1.276 ms | 1.279 ms | 1.231 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.220 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.LineClear | AI | 0.658 ms | 0.658 ms | 900 | 0.678 ms | 64/64 |
| Navigation.Search | AI | 0.416 ms | 0.505 ms | 100 | 0.524 ms | 64/64 |
| Navigation.Corridor | AI | 0.089 ms | 0.089 ms | 100 | 0.098 ms | 64/64 |
| Navigation.Smooth | AI | 0.035 ms | 0.693 ms | 100 | 0.714 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.239 ms | 1 | 1.279 ms | 64/64 |
| Navigation.Nearest | AI | 0.012 ms | 0.015 ms | 200 | 0.028 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.011 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.009 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.350 ms, CPU 1.238 ms, GPU -

```
Frame  total 1.238 ms, self 0.019 ms
  Navigation.Smooth  total 0.694 ms, self 0.035 ms, 100 calls
    Navigation.LineClear  total 0.659 ms, self 0.659 ms, 900 calls
  Navigation.Search  total 0.504 ms, self 0.414 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 47: interval 1.338 ms, CPU 1.233 ms, GPU -

```
Frame  total 1.233 ms, self 0.018 ms
  Navigation.Smooth  total 0.690 ms, self 0.035 ms, 100 calls
    Navigation.LineClear  total 0.655 ms, self 0.655 ms, 900 calls
  Navigation.Search  total 0.503 ms, self 0.413 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 60: interval 1.324 ms, CPU 1.232 ms, GPU -

```
Frame  total 1.232 ms, self 0.018 ms
  Navigation.Smooth  total 0.690 ms, self 0.035 ms, 100 calls
    Navigation.LineClear  total 0.655 ms, self 0.655 ms, 900 calls
  Navigation.Search  total 0.502 ms, self 0.413 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 51: interval 1.322 ms, CPU 1.233 ms, GPU -

```
Frame  total 1.233 ms, self 0.018 ms
  Navigation.Smooth  total 0.691 ms, self 0.039 ms, 100 calls
    Navigation.LineClear  total 0.652 ms, self 0.652 ms, 900 calls
  Navigation.Search  total 0.502 ms, self 0.413 ms, 100 calls
    Navigation.Corridor  total 0.088 ms, self 0.088 ms, 100 calls
```

### Frame 8: interval 1.321 ms, CPU 1.233 ms, GPU -

```
Frame  total 1.233 ms, self 0.018 ms
  Navigation.Smooth  total 0.691 ms, self 0.038 ms, 100 calls
    Navigation.LineClear  total 0.653 ms, self 0.653 ms, 900 calls
  Navigation.Search  total 0.502 ms, self 0.414 ms, 100 calls
    Navigation.Corridor  total 0.088 ms, self 0.088 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
