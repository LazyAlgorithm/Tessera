# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.349 ms | 1.349 ms | 1.353 ms | 1.354 ms | 1.397 ms | 1.323 ms |
| CPU main thread | 1.286 ms | 1.286 ms | 1.291 ms | 1.293 ms | 1.323 ms | 1.278 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.267 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.LineClear | AI | 0.683 ms | 0.683 ms | 900 | 0.690 ms | 64/64 |
| Navigation.Search | AI | 0.431 ms | 0.524 ms | 100 | 0.529 ms | 64/64 |
| Navigation.Corridor | AI | 0.093 ms | 0.093 ms | 100 | 0.097 ms | 64/64 |
| Navigation.Smooth | AI | 0.036 ms | 0.720 ms | 100 | 0.726 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.286 ms | 1 | 1.322 ms | 64/64 |
| Navigation.Nearest | AI | 0.013 ms | 0.016 ms | 200 | 0.030 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.012 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.009 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.397 ms, CPU 1.285 ms, GPU -

```
Frame  total 1.285 ms, self 0.019 ms
  Navigation.Smooth  total 0.720 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.684 ms, self 0.684 ms, 900 calls
  Navigation.Search  total 0.522 ms, self 0.429 ms, 100 calls
    Navigation.Corridor  total 0.093 ms, self 0.093 ms, 100 calls
```

### Frame 57: interval 1.354 ms, CPU 1.286 ms, GPU -

```
Frame  total 1.286 ms, self 0.019 ms
  Navigation.Smooth  total 0.719 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.683 ms, self 0.683 ms, 900 calls
  Navigation.Search  total 0.524 ms, self 0.431 ms, 100 calls
    Navigation.Corridor  total 0.094 ms, self 0.094 ms, 100 calls
```

### Frame 7: interval 1.354 ms, CPU 1.280 ms, GPU -

```
Frame  total 1.280 ms, self 0.019 ms
  Navigation.Smooth  total 0.717 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.681 ms, self 0.681 ms, 900 calls
  Navigation.Search  total 0.520 ms, self 0.428 ms, 100 calls
    Navigation.Corridor  total 0.092 ms, self 0.092 ms, 100 calls
```

### Frame 3: interval 1.353 ms, CPU 1.281 ms, GPU -

```
Frame  total 1.281 ms, self 0.019 ms
  Navigation.Smooth  total 0.717 ms, self 0.035 ms, 100 calls
    Navigation.LineClear  total 0.682 ms, self 0.682 ms, 900 calls
  Navigation.Search  total 0.522 ms, self 0.430 ms, 100 calls
    Navigation.Corridor  total 0.092 ms, self 0.092 ms, 100 calls
```

### Frame 36: interval 1.353 ms, CPU 1.285 ms, GPU -

```
Frame  total 1.285 ms, self 0.019 ms
  Navigation.Smooth  total 0.718 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.682 ms, self 0.682 ms, 900 calls
  Navigation.Search  total 0.525 ms, self 0.432 ms, 100 calls
    Navigation.Corridor  total 0.093 ms, self 0.093 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
