# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.309 ms | 1.302 ms | 1.337 ms | 1.348 ms | 1.364 ms | 1.287 ms |
| CPU main thread | 1.248 ms | 1.242 ms | 1.273 ms | 1.287 ms | 1.288 ms | 1.237 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.229 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.LineClear | AI | 0.662 ms | 0.662 ms | 900 | 0.688 ms | 64/64 |
| Navigation.Search | AI | 0.417 ms | 0.507 ms | 100 | 0.521 ms | 64/64 |
| Navigation.Corridor | AI | 0.090 ms | 0.090 ms | 100 | 0.096 ms | 64/64 |
| Navigation.Smooth | AI | 0.036 ms | 0.698 ms | 100 | 0.725 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.248 ms | 1 | 1.288 ms | 64/64 |
| Navigation.Nearest | AI | 0.012 ms | 0.016 ms | 200 | 0.032 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.012 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.013 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.364 ms, CPU 1.246 ms, GPU -

```
Frame  total 1.246 ms, self 0.019 ms
  Navigation.Smooth  total 0.698 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.662 ms, self 0.662 ms, 900 calls
  Navigation.Search  total 0.507 ms, self 0.417 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 11: interval 1.348 ms, CPU 1.238 ms, GPU -

```
Frame  total 1.238 ms, self 0.018 ms
  Navigation.Smooth  total 0.694 ms, self 0.038 ms, 100 calls
    Navigation.LineClear  total 0.656 ms, self 0.656 ms, 900 calls
  Navigation.Search  total 0.503 ms, self 0.414 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 3: interval 1.341 ms, CPU 1.238 ms, GPU -

```
Frame  total 1.238 ms, self 0.018 ms
  Navigation.Smooth  total 0.695 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.659 ms, self 0.659 ms, 900 calls
  Navigation.Search  total 0.502 ms, self 0.413 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 62: interval 1.337 ms, CPU 1.248 ms, GPU -

```
Frame  total 1.248 ms, self 0.018 ms
  Navigation.Smooth  total 0.699 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.663 ms, self 0.663 ms, 900 calls
  Navigation.Search  total 0.508 ms, self 0.418 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 39: interval 1.333 ms, CPU 1.243 ms, GPU -

```
Frame  total 1.243 ms, self 0.019 ms
  Navigation.Smooth  total 0.697 ms, self 0.036 ms, 100 calls
    Navigation.LineClear  total 0.661 ms, self 0.661 ms, 900 calls
  Navigation.Search  total 0.505 ms, self 0.415 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
