# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.220 ms | 1.219 ms | 1.227 ms | 1.231 ms | 1.263 ms | 1.211 ms |
| CPU main thread | 1.189 ms | 1.188 ms | 1.195 ms | 1.199 ms | 1.214 ms | 1.183 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.170 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Smooth | AI | 0.641 ms | 0.641 ms | 100 | 0.654 ms | 64/64 |
| Navigation.Search | AI | 0.416 ms | 0.506 ms | 100 | 0.513 ms | 64/64 |
| Navigation.Corridor | AI | 0.089 ms | 0.089 ms | 100 | 0.095 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.189 ms | 1 | 1.213 ms | 64/64 |
| Navigation.Nearest | AI | 0.012 ms | 0.016 ms | 200 | 0.017 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.008 ms | 64/64 |
| Navigation.Nodes | AI | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.263 ms, CPU 1.192 ms, GPU -

```
Frame  total 1.192 ms, self 0.019 ms
  Navigation.Smooth  total 0.644 ms, self 0.644 ms, 100 calls
  Navigation.Search  total 0.507 ms, self 0.414 ms, 100 calls
    Navigation.Corridor  total 0.092 ms, self 0.092 ms, 100 calls
```

### Frame 11: interval 1.231 ms, CPU 1.193 ms, GPU -

```
Frame  total 1.193 ms, self 0.019 ms
  Navigation.Smooth  total 0.641 ms, self 0.641 ms, 100 calls
  Navigation.Search  total 0.510 ms, self 0.420 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 38: interval 1.227 ms, CPU 1.186 ms, GPU -

```
Frame  total 1.186 ms, self 0.019 ms
  Navigation.Smooth  total 0.638 ms, self 0.638 ms, 100 calls
  Navigation.Search  total 0.505 ms, self 0.414 ms, 100 calls
    Navigation.Corridor  total 0.091 ms, self 0.091 ms, 100 calls
```

### Frame 57: interval 1.227 ms, CPU 1.192 ms, GPU -

```
Frame  total 1.192 ms, self 0.019 ms
  Navigation.Smooth  total 0.639 ms, self 0.639 ms, 100 calls
  Navigation.Search  total 0.510 ms, self 0.419 ms, 100 calls
    Navigation.Corridor  total 0.091 ms, self 0.091 ms, 100 calls
```

### Frame 59: interval 1.225 ms, CPU 1.184 ms, GPU -

```
Frame  total 1.184 ms, self 0.019 ms
  Navigation.Smooth  total 0.639 ms, self 0.639 ms, 100 calls
  Navigation.Search  total 0.502 ms, self 0.412 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
