# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.224 ms | 1.223 ms | 1.232 ms | 1.239 ms | 1.264 ms | 1.219 ms |
| CPU main thread | 1.194 ms | 1.193 ms | 1.199 ms | 1.208 ms | 1.220 ms | 1.187 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.175 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Smooth | AI | 0.642 ms | 0.642 ms | 100 | 0.655 ms | 64/64 |
| Navigation.Search | AI | 0.421 ms | 0.510 ms | 100 | 0.526 ms | 64/64 |
| Navigation.Corridor | AI | 0.088 ms | 0.088 ms | 100 | 0.095 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.194 ms | 1 | 1.220 ms | 64/64 |
| Navigation.Nearest | AI | 0.012 ms | 0.015 ms | 200 | 0.020 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.011 ms | 64/64 |
| Navigation.Nodes | AI | 0.004 ms | 0.004 ms | 100 | 0.004 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.264 ms, CPU 1.199 ms, GPU -

```
Frame  total 1.199 ms, self 0.019 ms
  Navigation.Smooth  total 0.642 ms, self 0.642 ms, 100 calls
  Navigation.Search  total 0.516 ms, self 0.428 ms, 100 calls
    Navigation.Corridor  total 0.088 ms, self 0.088 ms, 100 calls
```

### Frame 57: interval 1.239 ms, CPU 1.192 ms, GPU -

```
Frame  total 1.192 ms, self 0.019 ms
  Navigation.Smooth  total 0.639 ms, self 0.639 ms, 100 calls
  Navigation.Search  total 0.511 ms, self 0.422 ms, 100 calls
    Navigation.Corridor  total 0.089 ms, self 0.089 ms, 100 calls
```

### Frame 39: interval 1.236 ms, CPU 1.192 ms, GPU -

```
Frame  total 1.192 ms, self 0.019 ms
  Navigation.Smooth  total 0.644 ms, self 0.644 ms, 100 calls
  Navigation.Search  total 0.506 ms, self 0.419 ms, 100 calls
    Navigation.Corridor  total 0.087 ms, self 0.087 ms, 100 calls
```

### Frame 2: interval 1.232 ms, CPU 1.194 ms, GPU -

```
Frame  total 1.194 ms, self 0.019 ms
  Navigation.Smooth  total 0.640 ms, self 0.640 ms, 100 calls
  Navigation.Search  total 0.510 ms, self 0.423 ms, 100 calls
    Navigation.Corridor  total 0.088 ms, self 0.088 ms, 100 calls
```

### Frame 8: interval 1.230 ms, CPU 1.193 ms, GPU -

```
Frame  total 1.193 ms, self 0.019 ms
  Navigation.Smooth  total 0.641 ms, self 0.641 ms, 100 calls
  Navigation.Search  total 0.511 ms, self 0.423 ms, 100 calls
    Navigation.Corridor  total 0.088 ms, self 0.088 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
