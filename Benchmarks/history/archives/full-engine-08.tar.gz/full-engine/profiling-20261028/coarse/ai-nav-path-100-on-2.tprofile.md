# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.256 ms | 1.256 ms | 1.260 ms | 1.262 ms | 1.284 ms | 1.245 ms |
| CPU main thread | 1.225 ms | 1.225 ms | 1.229 ms | 1.231 ms | 1.245 ms | 1.218 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- AI: 1.206 ms
- Other: 0.019 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Navigation.Smooth | AI | 0.664 ms | 0.664 ms | 100 | 0.671 ms | 64/64 |
| Navigation.Search | AI | 0.430 ms | 0.520 ms | 100 | 0.529 ms | 64/64 |
| Navigation.Corridor | AI | 0.090 ms | 0.090 ms | 100 | 0.095 ms | 64/64 |
| Frame | Other | 0.019 ms | 1.225 ms | 1 | 1.245 ms | 64/64 |
| Navigation.Nearest | AI | 0.012 ms | 0.015 ms | 200 | 0.016 ms | 64/64 |
| Navigation.Regions | AI | 0.007 ms | 0.007 ms | 200 | 0.007 ms | 64/64 |
| Navigation.Nodes | AI | 0.003 ms | 0.003 ms | 100 | 0.005 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.284 ms, CPU 1.228 ms, GPU -

```
Frame  total 1.228 ms, self 0.019 ms
  Navigation.Smooth  total 0.665 ms, self 0.665 ms, 100 calls
  Navigation.Search  total 0.522 ms, self 0.432 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 13: interval 1.262 ms, CPU 1.218 ms, GPU -

```
Frame  total 1.218 ms, self 0.019 ms
  Navigation.Smooth  total 0.661 ms, self 0.661 ms, 100 calls
  Navigation.Search  total 0.516 ms, self 0.427 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 33: interval 1.260 ms, CPU 1.224 ms, GPU -

```
Frame  total 1.224 ms, self 0.019 ms
  Navigation.Smooth  total 0.660 ms, self 0.660 ms, 100 calls
  Navigation.Search  total 0.523 ms, self 0.431 ms, 100 calls
    Navigation.Corridor  total 0.091 ms, self 0.091 ms, 100 calls
```

### Frame 2: interval 1.260 ms, CPU 1.224 ms, GPU -

```
Frame  total 1.224 ms, self 0.019 ms
  Navigation.Smooth  total 0.664 ms, self 0.664 ms, 100 calls
  Navigation.Search  total 0.519 ms, self 0.429 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

### Frame 18: interval 1.260 ms, CPU 1.225 ms, GPU -

```
Frame  total 1.225 ms, self 0.019 ms
  Navigation.Smooth  total 0.665 ms, self 0.665 ms, 100 calls
  Navigation.Search  total 0.518 ms, self 0.428 ms, 100 calls
    Navigation.Corridor  total 0.090 ms, self 0.090 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)

AI:
- Paths Found: 100, 100, 100, 100, 100
- Path Search Visits: 2500, 2500, 2500, 2500, 2500

Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
