# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.914 ms | 1.913 ms | 1.922 ms | 1.924 ms | 2.034 ms | 1.820 ms |
| CPU main thread | 1.704 ms | 1.702 ms | 1.710 ms | 1.712 ms | 1.820 ms | 1.693 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.633 ms
- Other: 0.071 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.397 ms | 1.397 ms | 1000 | 1.415 ms | 64/64 |
| Physics.Overlap | Physics | 0.116 ms | 1.596 ms | 1000 | 1.658 ms | 64/64 |
| Frame | Other | 0.071 ms | 1.704 ms | 1 | 1.819 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.050 ms | 0.050 ms | 1000 | 0.056 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.037 ms | 0.037 ms | 1000 | 0.089 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.033 ms | 0.033 ms | 1000 | 0.058 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 2.034 ms, CPU 1.700 ms, GPU -

```
Frame  total 1.700 ms, self 0.071 ms
  Physics.Overlap  total 1.593 ms, self 0.116 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.393 ms, self 1.393 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.050 ms, self 0.050 ms, 1000 calls
```

### Frame 50: interval 1.924 ms, CPU 1.703 ms, GPU -

```
Frame  total 1.703 ms, self 0.071 ms
  Physics.Overlap  total 1.596 ms, self 0.117 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.398 ms, self 1.398 ms, 1000 calls
```

### Frame 60: interval 1.923 ms, CPU 1.706 ms, GPU -

```
Frame  total 1.706 ms, self 0.071 ms
  Physics.Overlap  total 1.599 ms, self 0.116 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.397 ms, self 1.397 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.053 ms, self 0.053 ms, 1000 calls
```

### Frame 28: interval 1.922 ms, CPU 1.700 ms, GPU -

```
Frame  total 1.700 ms, self 0.071 ms
  Physics.Overlap  total 1.593 ms, self 0.113 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.400 ms, self 1.400 ms, 1000 calls
```

### Frame 5: interval 1.922 ms, CPU 1.703 ms, GPU -

```
Frame  total 1.703 ms, self 0.071 ms
  Physics.Overlap  total 1.595 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.397 ms, self 1.397 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.050 ms, self 0.050 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
