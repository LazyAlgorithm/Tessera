# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.788 ms | 1.785 ms | 1.806 ms | 1.812 ms | 1.921 ms | 1.713 ms |
| CPU main thread | 1.582 ms | 1.579 ms | 1.594 ms | 1.601 ms | 1.713 ms | 1.566 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.514 ms
- Other: 0.067 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.288 ms | 1.288 ms | 1000 | 1.323 ms | 64/64 |
| Physics.Overlap | Physics | 0.111 ms | 1.479 ms | 1000 | 1.555 ms | 64/64 |
| Frame | Other | 0.067 ms | 1.582 ms | 1 | 1.713 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.047 ms | 0.047 ms | 1000 | 0.052 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.036 ms | 0.036 ms | 1000 | 0.090 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.032 ms | 0.032 ms | 1000 | 0.053 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.921 ms, CPU 1.570 ms, GPU -

```
Frame  total 1.570 ms, self 0.067 ms
  Physics.Overlap  total 1.468 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.284 ms, self 1.284 ms, 1000 calls
```

### Frame 49: interval 1.812 ms, CPU 1.593 ms, GPU -

```
Frame  total 1.593 ms, self 0.068 ms
  Physics.Overlap  total 1.490 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.300 ms, self 1.300 ms, 1000 calls
```

### Frame 38: interval 1.807 ms, CPU 1.581 ms, GPU -

```
Frame  total 1.581 ms, self 0.067 ms
  Physics.Overlap  total 1.479 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.289 ms, self 1.289 ms, 1000 calls
```

### Frame 36: interval 1.806 ms, CPU 1.583 ms, GPU -

```
Frame  total 1.583 ms, self 0.070 ms
  Physics.Overlap  total 1.478 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.286 ms, self 1.286 ms, 1000 calls
```

### Frame 51: interval 1.805 ms, CPU 1.585 ms, GPU -

```
Frame  total 1.584 ms, self 0.067 ms
  Physics.Overlap  total 1.482 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.296 ms, self 1.296 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
