# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.801 ms | 1.797 ms | 1.828 ms | 1.943 ms | 1.995 ms | 1.728 ms |
| CPU main thread | 1.595 ms | 1.591 ms | 1.616 ms | 1.728 ms | 1.792 ms | 1.567 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.526 ms
- Other: 0.068 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.295 ms | 1.295 ms | 1000 | 1.326 ms | 64/64 |
| Physics.Overlap | Physics | 0.111 ms | 1.490 ms | 1000 | 1.690 ms | 64/64 |
| Frame | Other | 0.068 ms | 1.595 ms | 1 | 1.791 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.052 ms | 0.052 ms | 1000 | 0.262 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.036 ms | 0.036 ms | 1000 | 0.114 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.032 ms | 0.032 ms | 1000 | 0.063 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 32: interval 1.995 ms, CPU 1.593 ms, GPU -

```
Frame  total 1.593 ms, self 0.068 ms
  Physics.Overlap  total 1.491 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.300 ms, self 1.300 ms, 1000 calls
```

### Frame 1: interval 1.943 ms, CPU 1.596 ms, GPU -

```
Frame  total 1.596 ms, self 0.068 ms
  Physics.Overlap  total 1.492 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.303 ms, self 1.303 ms, 1000 calls
```

### Frame 22: interval 1.829 ms, CPU 1.576 ms, GPU -

```
Frame  total 1.576 ms, self 0.067 ms
  Physics.Overlap  total 1.474 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.285 ms, self 1.285 ms, 1000 calls
```

### Frame 43: interval 1.828 ms, CPU 1.580 ms, GPU -

```
Frame  total 1.580 ms, self 0.068 ms
  Physics.Overlap  total 1.477 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.291 ms, self 1.291 ms, 1000 calls
```

### Frame 50: interval 1.825 ms, CPU 1.569 ms, GPU -

```
Frame  total 1.569 ms, self 0.067 ms
  Physics.Overlap  total 1.468 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.279 ms, self 1.279 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
