# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.120 ms | 3.117 ms | 3.153 ms | 3.172 ms | 3.238 ms | 3.020 ms |
| CPU main thread | 2.913 ms | 2.907 ms | 2.942 ms | 2.969 ms | 3.020 ms | 2.885 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.790 ms
- Other: 0.123 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 2.538 ms | 2.538 ms | 1000 | 2.596 ms | 64/64 |
| Frame | Other | 0.123 ms | 2.912 ms | 1 | 3.020 ms | 64/64 |
| Physics.Overlap | Physics | 0.121 ms | 2.755 ms | 1000 | 2.811 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.063 ms | 0.063 ms | 1000 | 0.067 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.035 ms | 0.035 ms | 1000 | 0.100 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.033 ms | 0.033 ms | 1000 | 0.061 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.238 ms, CPU 2.929 ms, GPU -

```
Frame  total 2.929 ms, self 0.122 ms
  Physics.Overlap  total 2.773 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.556 ms, self 2.556 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.063 ms, self 0.063 ms, 1000 calls
```

### Frame 25: interval 3.172 ms, CPU 2.887 ms, GPU -

```
Frame  total 2.887 ms, self 0.121 ms
  Physics.Overlap  total 2.731 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.513 ms, self 2.513 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.064 ms, self 0.064 ms, 1000 calls
```

### Frame 13: interval 3.156 ms, CPU 2.897 ms, GPU -

```
Frame  total 2.897 ms, self 0.121 ms
  Physics.Overlap  total 2.741 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.525 ms, self 2.525 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

### Frame 18: interval 3.153 ms, CPU 2.911 ms, GPU -

```
Frame  total 2.911 ms, self 0.125 ms
  Physics.Overlap  total 2.752 ms, self 0.120 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.537 ms, self 2.537 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.064 ms, self 0.064 ms, 1000 calls
```

### Frame 34: interval 3.151 ms, CPU 2.896 ms, GPU -

```
Frame  total 2.895 ms, self 0.122 ms
  Physics.Overlap  total 2.740 ms, self 0.119 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.526 ms, self 2.526 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.063 ms, self 0.063 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
