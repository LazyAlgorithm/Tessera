# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.225 ms | 3.225 ms | 3.233 ms | 3.241 ms | 3.328 ms | 3.111 ms |
| CPU main thread | 3.014 ms | 3.012 ms | 3.019 ms | 3.027 ms | 3.111 ms | 2.997 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.886 ms
- Other: 0.128 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 2.626 ms | 2.626 ms | 1000 | 2.641 ms | 64/64 |
| Frame | Other | 0.128 ms | 3.013 ms | 1 | 3.110 ms | 64/64 |
| Physics.Overlap | Physics | 0.126 ms | 2.849 ms | 1000 | 2.891 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.064 ms | 0.064 ms | 1000 | 0.068 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.037 ms | 0.037 ms | 1000 | 0.090 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.033 ms | 0.033 ms | 1000 | 0.057 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.328 ms, CPU 3.009 ms, GPU -

```
Frame  total 3.009 ms, self 0.127 ms
  Physics.Overlap  total 2.846 ms, self 0.124 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.624 ms, self 2.624 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.065 ms, self 0.065 ms, 1000 calls
```

### Frame 38: interval 3.241 ms, CPU 3.014 ms, GPU -

```
Frame  total 3.014 ms, self 0.127 ms
  Physics.Overlap  total 2.851 ms, self 0.124 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.630 ms, self 2.630 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.064 ms, self 0.064 ms, 1000 calls
```

### Frame 18: interval 3.241 ms, CPU 3.008 ms, GPU -

```
Frame  total 3.008 ms, self 0.127 ms
  Physics.Overlap  total 2.845 ms, self 0.125 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.622 ms, self 2.622 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.065 ms, self 0.065 ms, 1000 calls
```

### Frame 7: interval 3.233 ms, CPU 3.012 ms, GPU -

```
Frame  total 3.012 ms, self 0.127 ms
  Physics.Overlap  total 2.849 ms, self 0.125 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.627 ms, self 2.627 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.064 ms, self 0.064 ms, 1000 calls
```

### Frame 29: interval 3.232 ms, CPU 3.019 ms, GPU -

```
Frame  total 3.019 ms, self 0.127 ms
  Physics.Overlap  total 2.856 ms, self 0.125 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.634 ms, self 2.634 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.064 ms, self 0.064 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
