# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.098 ms | 3.099 ms | 3.118 ms | 3.121 ms | 3.231 ms | 3.014 ms |
| CPU main thread | 2.892 ms | 2.892 ms | 2.908 ms | 2.909 ms | 3.014 ms | 2.869 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.769 ms
- Other: 0.123 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 2.518 ms | 2.518 ms | 1000 | 2.537 ms | 64/64 |
| Frame | Other | 0.123 ms | 2.892 ms | 1 | 3.014 ms | 64/64 |
| Physics.Overlap | Physics | 0.122 ms | 2.734 ms | 1000 | 2.787 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.061 ms | 0.061 ms | 1000 | 0.065 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.035 ms | 0.035 ms | 1000 | 0.099 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.032 ms | 0.032 ms | 1000 | 0.061 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.231 ms, CPU 2.909 ms, GPU -

```
Frame  total 2.909 ms, self 0.123 ms
  Physics.Overlap  total 2.752 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.537 ms, self 2.537 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.062 ms, self 0.062 ms, 1000 calls
```

### Frame 53: interval 3.121 ms, CPU 2.872 ms, GPU -

```
Frame  total 2.872 ms, self 0.121 ms
  Physics.Overlap  total 2.716 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.503 ms, self 2.503 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

### Frame 26: interval 3.119 ms, CPU 2.894 ms, GPU -

```
Frame  total 2.894 ms, self 0.122 ms
  Physics.Overlap  total 2.737 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.523 ms, self 2.523 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.062 ms, self 0.062 ms, 1000 calls
```

### Frame 41: interval 3.118 ms, CPU 2.900 ms, GPU -

```
Frame  total 2.900 ms, self 0.123 ms
  Physics.Overlap  total 2.743 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.529 ms, self 2.529 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

### Frame 20: interval 3.117 ms, CPU 2.876 ms, GPU -

```
Frame  total 2.876 ms, self 0.121 ms
  Physics.Overlap  total 2.721 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.504 ms, self 2.504 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.063 ms, self 0.063 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
