# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 7.333 ms | 7.331 ms | 7.342 ms | 7.401 ms | 7.467 ms | 7.241 ms |
| CPU main thread | 7.115 ms | 7.113 ms | 7.123 ms | 7.129 ms | 7.241 ms | 7.105 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 7.046 ms
- Other: 0.069 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 6.735 ms | 6.735 ms | 1000 | 6.757 ms | 64/64 |
| Physics.Overlap | Physics | 0.125 ms | 7.003 ms | 1000 | 7.071 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.105 ms | 0.105 ms | 1000 | 0.114 ms | 64/64 |
| Frame | Other | 0.069 ms | 7.115 ms | 1 | 7.241 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.043 ms | 0.043 ms | 1000 | 0.100 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.037 ms | 0.037 ms | 1000 | 0.063 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 7.467 ms, CPU 7.129 ms, GPU -

```
Frame  total 7.129 ms, self 0.068 ms
  Physics.Overlap  total 7.018 ms, self 0.125 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.749 ms, self 6.749 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.107 ms, self 0.107 ms, 1000 calls
```

### Frame 26: interval 7.401 ms, CPU 7.108 ms, GPU -

```
Frame  total 7.108 ms, self 0.069 ms
  Physics.Overlap  total 6.997 ms, self 0.125 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.730 ms, self 6.730 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 2: interval 7.356 ms, CPU 7.123 ms, GPU -

```
Frame  total 7.123 ms, self 0.069 ms
  Physics.Overlap  total 7.012 ms, self 0.128 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.741 ms, self 6.741 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.106 ms, self 0.106 ms, 1000 calls
```

### Frame 3: interval 7.342 ms, CPU 7.117 ms, GPU -

```
Frame  total 7.117 ms, self 0.069 ms
  Physics.Overlap  total 7.006 ms, self 0.124 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.740 ms, self 6.740 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 60: interval 7.342 ms, CPU 7.111 ms, GPU -

```
Frame  total 7.111 ms, self 0.069 ms
  Physics.Overlap  total 6.999 ms, self 0.124 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.736 ms, self 6.736 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.104 ms, self 0.104 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
