# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 7.247 ms | 7.245 ms | 7.262 ms | 7.270 ms | 7.381 ms | 7.163 ms |
| CPU main thread | 7.032 ms | 7.029 ms | 7.043 ms | 7.051 ms | 7.163 ms | 7.021 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 6.964 ms
- Other: 0.068 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 6.660 ms | 6.660 ms | 1000 | 6.695 ms | 64/64 |
| Physics.Overlap | Physics | 0.122 ms | 6.922 ms | 1000 | 6.995 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.104 ms | 0.104 ms | 1000 | 0.108 ms | 64/64 |
| Frame | Other | 0.068 ms | 7.032 ms | 1 | 7.163 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.043 ms | 0.043 ms | 1000 | 0.098 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.036 ms | 0.036 ms | 1000 | 0.057 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 7.381 ms, CPU 7.051 ms, GPU -

```
Frame  total 7.050 ms, self 0.068 ms
  Physics.Overlap  total 6.941 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.680 ms, self 6.680 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.104 ms, self 0.104 ms, 1000 calls
```

### Frame 2: interval 7.270 ms, CPU 7.040 ms, GPU -

```
Frame  total 7.040 ms, self 0.068 ms
  Physics.Overlap  total 6.931 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.669 ms, self 6.669 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 8: interval 7.269 ms, CPU 7.033 ms, GPU -

```
Frame  total 7.033 ms, self 0.068 ms
  Physics.Overlap  total 6.924 ms, self 0.122 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.663 ms, self 6.663 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.104 ms, self 0.104 ms, 1000 calls
```

### Frame 36: interval 7.262 ms, CPU 7.034 ms, GPU -

```
Frame  total 7.034 ms, self 0.072 ms
  Physics.Overlap  total 6.920 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.659 ms, self 6.659 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 3: interval 7.260 ms, CPU 7.037 ms, GPU -

```
Frame  total 7.036 ms, self 0.068 ms
  Physics.Overlap  total 6.927 ms, self 0.122 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.666 ms, self 6.666 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.104 ms, self 0.104 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
