# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 7.031 ms | 7.024 ms | 7.066 ms | 7.233 ms | 7.235 ms | 6.964 ms |
| CPU main thread | 6.816 ms | 6.813 ms | 6.854 ms | 6.867 ms | 7.013 ms | 6.758 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 6.751 ms
- Other: 0.065 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 6.455 ms | 6.455 ms | 1000 | 6.526 ms | 64/64 |
| Physics.Overlap | Physics | 0.116 ms | 6.709 ms | 1000 | 6.830 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.105 ms | 0.105 ms | 1000 | 0.111 ms | 64/64 |
| Frame | Other | 0.065 ms | 6.816 ms | 1 | 7.012 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.042 ms | 0.042 ms | 1000 | 0.112 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.033 ms | 0.033 ms | 1000 | 0.064 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 32: interval 7.235 ms, CPU 6.803 ms, GPU -

```
Frame  total 6.803 ms, self 0.065 ms
  Physics.Overlap  total 6.697 ms, self 0.114 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.445 ms, self 6.445 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 1: interval 7.233 ms, CPU 6.826 ms, GPU -

```
Frame  total 6.826 ms, self 0.065 ms
  Physics.Overlap  total 6.720 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.468 ms, self 6.468 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 15: interval 7.081 ms, CPU 6.827 ms, GPU -

```
Frame  total 6.827 ms, self 0.065 ms
  Physics.Overlap  total 6.722 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.469 ms, self 6.469 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.104 ms, self 0.104 ms, 1000 calls
```

### Frame 30: interval 7.066 ms, CPU 6.758 ms, GPU -

```
Frame  total 6.758 ms, self 0.064 ms
  Physics.Overlap  total 6.654 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.403 ms, self 6.403 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

### Frame 43: interval 7.065 ms, CPU 6.827 ms, GPU -

```
Frame  total 6.827 ms, self 0.065 ms
  Physics.Overlap  total 6.721 ms, self 0.116 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.467 ms, self 6.467 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
