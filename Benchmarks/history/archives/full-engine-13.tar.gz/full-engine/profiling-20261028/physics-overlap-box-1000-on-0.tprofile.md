# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.903 ms | 1.896 ms | 1.910 ms | 2.032 ms | 2.207 ms | 1.801 ms |
| CPU main thread | 1.688 ms | 1.682 ms | 1.695 ms | 1.827 ms | 1.886 ms | 1.617 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.617 ms
- Other: 0.071 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.371 ms | 1.371 ms | 1000 | 1.500 ms | 64/64 |
| Physics.Overlap | Physics | 0.114 ms | 1.579 ms | 1000 | 1.760 ms | 64/64 |
| Frame | Other | 0.071 ms | 1.688 ms | 1 | 1.885 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.052 ms | 0.052 ms | 1000 | 0.070 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.041 ms | 0.041 ms | 1000 | 0.065 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.038 ms | 0.038 ms | 1000 | 0.091 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 62: interval 2.207 ms, CPU 1.827 ms, GPU -

```
Frame  total 1.827 ms, self 0.074 ms
  Physics.Overlap  total 1.706 ms, self 0.131 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.468 ms, self 1.468 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.058 ms, self 0.058 ms, 1000 calls
```

### Frame 63: interval 2.032 ms, CPU 1.617 ms, GPU -

```
Frame  total 1.617 ms, self 0.070 ms
  Physics.Overlap  total 1.511 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.316 ms, self 1.316 ms, 1000 calls
```

### Frame 1: interval 2.018 ms, CPU 1.686 ms, GPU -

```
Frame  total 1.686 ms, self 0.075 ms
  Physics.Overlap  total 1.575 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.367 ms, self 1.367 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.051 ms, self 0.051 ms, 1000 calls
```

### Frame 28: interval 1.910 ms, CPU 1.679 ms, GPU -

```
Frame  total 1.678 ms, self 0.070 ms
  Physics.Overlap  total 1.572 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.368 ms, self 1.368 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.052 ms, self 0.052 ms, 1000 calls
```

### Frame 16: interval 1.910 ms, CPU 1.686 ms, GPU -

```
Frame  total 1.686 ms, self 0.071 ms
  Physics.Overlap  total 1.578 ms, self 0.113 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.369 ms, self 1.369 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.056 ms, self 0.056 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
