# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.821 ms | 1.821 ms | 1.828 ms | 1.831 ms | 1.940 ms | 1.720 ms |
| CPU main thread | 1.612 ms | 1.611 ms | 1.618 ms | 1.620 ms | 1.720 ms | 1.593 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.544 ms
- Other: 0.069 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.318 ms | 1.318 ms | 1000 | 1.327 ms | 64/64 |
| Physics.Overlap | Physics | 0.108 ms | 1.508 ms | 1000 | 1.553 ms | 64/64 |
| Frame | Other | 0.069 ms | 1.612 ms | 1 | 1.719 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.047 ms | 0.047 ms | 1000 | 0.054 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.036 ms | 0.036 ms | 1000 | 0.096 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.034 ms | 0.034 ms | 1000 | 0.057 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 1.940 ms, CPU 1.613 ms, GPU -

```
Frame  total 1.613 ms, self 0.068 ms
  Physics.Overlap  total 1.510 ms, self 0.107 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.322 ms, self 1.322 ms, 1000 calls
```

### Frame 60: interval 1.831 ms, CPU 1.611 ms, GPU -

```
Frame  total 1.610 ms, self 0.068 ms
  Physics.Overlap  total 1.509 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.319 ms, self 1.319 ms, 1000 calls
```

### Frame 41: interval 1.830 ms, CPU 1.610 ms, GPU -

```
Frame  total 1.610 ms, self 0.068 ms
  Physics.Overlap  total 1.507 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.315 ms, self 1.315 ms, 1000 calls
```

### Frame 45: interval 1.828 ms, CPU 1.607 ms, GPU -

```
Frame  total 1.607 ms, self 0.068 ms
  Physics.Overlap  total 1.504 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.317 ms, self 1.317 ms, 1000 calls
```

### Frame 58: interval 1.828 ms, CPU 1.608 ms, GPU -

```
Frame  total 1.608 ms, self 0.069 ms
  Physics.Overlap  total 1.505 ms, self 0.107 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.319 ms, self 1.319 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
