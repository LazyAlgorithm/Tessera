# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.885 ms | 1.884 ms | 1.896 ms | 1.902 ms | 2.013 ms | 1.796 ms |
| CPU main thread | 1.675 ms | 1.672 ms | 1.683 ms | 1.686 ms | 1.796 ms | 1.657 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 1.605 ms
- Other: 0.070 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 1.362 ms | 1.362 ms | 1000 | 1.380 ms | 64/64 |
| Physics.Overlap | Physics | 0.113 ms | 1.567 ms | 1000 | 1.633 ms | 64/64 |
| Frame | Other | 0.070 ms | 1.675 ms | 1 | 1.796 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.052 ms | 0.052 ms | 1000 | 0.060 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.040 ms | 0.040 ms | 1000 | 0.066 ms | 64/64 |
| Physics.Query.BoxShape | Physics | 0.038 ms | 0.038 ms | 1000 | 0.091 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 2.013 ms, CPU 1.661 ms, GPU -

```
Frame  total 1.661 ms, self 0.069 ms
  Physics.Overlap  total 1.556 ms, self 0.116 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.355 ms, self 1.355 ms, 1000 calls
```

### Frame 45: interval 1.902 ms, CPU 1.669 ms, GPU -

```
Frame  total 1.669 ms, self 0.070 ms
  Physics.Overlap  total 1.563 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.361 ms, self 1.361 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.053 ms, self 0.053 ms, 1000 calls
```

### Frame 56: interval 1.898 ms, CPU 1.665 ms, GPU -

```
Frame  total 1.665 ms, self 0.069 ms
  Physics.Overlap  total 1.559 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.360 ms, self 1.360 ms, 1000 calls
```

### Frame 34: interval 1.896 ms, CPU 1.682 ms, GPU -

```
Frame  total 1.682 ms, self 0.070 ms
  Physics.Overlap  total 1.575 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.369 ms, self 1.369 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.052 ms, self 0.052 ms, 1000 calls
```

### Frame 60: interval 1.895 ms, CPU 1.683 ms, GPU -

```
Frame  total 1.683 ms, self 0.070 ms
  Physics.Overlap  total 1.576 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 1.367 ms, self 1.367 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.052 ms, self 0.052 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
