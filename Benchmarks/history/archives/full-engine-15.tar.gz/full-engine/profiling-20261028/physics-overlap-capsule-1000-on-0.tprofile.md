# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.266 ms | 3.265 ms | 3.282 ms | 3.286 ms | 3.396 ms | 3.173 ms |
| CPU main thread | 3.053 ms | 3.051 ms | 3.062 ms | 3.075 ms | 3.173 ms | 3.042 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.923 ms
- Other: 0.130 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 2.648 ms | 2.648 ms | 1000 | 2.671 ms | 64/64 |
| Frame | Other | 0.130 ms | 3.053 ms | 1 | 3.172 ms | 64/64 |
| Physics.Overlap | Physics | 0.123 ms | 2.876 ms | 1000 | 2.933 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.061 ms | 0.061 ms | 1000 | 0.068 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.047 ms | 0.047 ms | 1000 | 0.105 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.044 ms | 0.044 ms | 1000 | 0.069 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.396 ms, CPU 3.054 ms, GPU -

```
Frame  total 3.054 ms, self 0.130 ms
  Physics.Overlap  total 2.877 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.650 ms, self 2.650 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

### Frame 20: interval 3.286 ms, CPU 3.053 ms, GPU -

```
Frame  total 3.053 ms, self 0.129 ms
  Physics.Overlap  total 2.877 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.649 ms, self 2.649 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

### Frame 16: interval 3.285 ms, CPU 3.051 ms, GPU -

```
Frame  total 3.051 ms, self 0.130 ms
  Physics.Overlap  total 2.874 ms, self 0.122 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.648 ms, self 2.648 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 42: interval 3.282 ms, CPU 3.054 ms, GPU -

```
Frame  total 3.054 ms, self 0.130 ms
  Physics.Overlap  total 2.878 ms, self 0.121 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.648 ms, self 2.648 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.060 ms, self 0.060 ms, 1000 calls
```

### Frame 59: interval 3.279 ms, CPU 3.053 ms, GPU -

```
Frame  total 3.053 ms, self 0.131 ms
  Physics.Overlap  total 2.876 ms, self 0.127 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.646 ms, self 2.646 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.060 ms, self 0.060 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
