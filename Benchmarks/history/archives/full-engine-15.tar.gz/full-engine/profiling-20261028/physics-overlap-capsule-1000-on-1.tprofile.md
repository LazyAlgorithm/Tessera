# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.148 ms | 3.151 ms | 3.180 ms | 3.196 ms | 3.276 ms | 3.066 ms |
| CPU main thread | 2.944 ms | 2.946 ms | 2.972 ms | 2.977 ms | 3.066 ms | 2.899 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.818 ms
- Other: 0.125 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 2.557 ms | 2.557 ms | 1000 | 2.592 ms | 64/64 |
| Frame | Other | 0.125 ms | 2.944 ms | 1 | 3.066 ms | 64/64 |
| Physics.Overlap | Physics | 0.116 ms | 2.773 ms | 1000 | 2.829 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.060 ms | 0.060 ms | 1000 | 0.064 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.045 ms | 0.045 ms | 1000 | 0.111 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.040 ms | 0.040 ms | 1000 | 0.072 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.276 ms, CPU 2.972 ms, GPU -

```
Frame  total 2.972 ms, self 0.126 ms
  Physics.Overlap  total 2.802 ms, self 0.117 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.587 ms, self 2.587 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 24: interval 3.196 ms, CPU 2.957 ms, GPU -

```
Frame  total 2.957 ms, self 0.125 ms
  Physics.Overlap  total 2.788 ms, self 0.116 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.572 ms, self 2.572 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.060 ms, self 0.060 ms, 1000 calls
```

### Frame 21: interval 3.180 ms, CPU 2.944 ms, GPU -

```
Frame  total 2.944 ms, self 0.125 ms
  Physics.Overlap  total 2.774 ms, self 0.116 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.558 ms, self 2.558 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 33: interval 3.180 ms, CPU 2.939 ms, GPU -

```
Frame  total 2.939 ms, self 0.124 ms
  Physics.Overlap  total 2.771 ms, self 0.117 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.555 ms, self 2.555 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 2: interval 3.178 ms, CPU 2.953 ms, GPU -

```
Frame  total 2.953 ms, self 0.127 ms
  Physics.Overlap  total 2.782 ms, self 0.115 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.564 ms, self 2.564 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.063 ms, self 0.063 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
