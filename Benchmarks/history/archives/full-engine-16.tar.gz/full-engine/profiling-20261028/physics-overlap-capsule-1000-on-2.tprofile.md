# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 3.157 ms | 3.159 ms | 3.173 ms | 3.185 ms | 3.280 ms | 3.065 ms |
| CPU main thread | 2.954 ms | 2.955 ms | 2.968 ms | 2.973 ms | 3.065 ms | 2.927 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.830 ms
- Other: 0.124 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 2.561 ms | 2.561 ms | 1000 | 2.581 ms | 64/64 |
| Frame | Other | 0.124 ms | 2.954 ms | 1 | 3.065 ms | 64/64 |
| Physics.Overlap | Physics | 0.123 ms | 2.784 ms | 1000 | 2.829 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.060 ms | 0.060 ms | 1000 | 0.063 ms | 64/64 |
| Physics.Query.CapsuleShape | Physics | 0.046 ms | 0.046 ms | 1000 | 0.110 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.039 ms | 0.039 ms | 1000 | 0.068 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 3.280 ms, CPU 2.973 ms, GPU -

```
Frame  total 2.973 ms, self 0.123 ms
  Physics.Overlap  total 2.803 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.581 ms, self 2.581 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.060 ms, self 0.060 ms, 1000 calls
```

### Frame 2: interval 3.185 ms, CPU 2.968 ms, GPU -

```
Frame  total 2.968 ms, self 0.124 ms
  Physics.Overlap  total 2.799 ms, self 0.124 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.573 ms, self 2.573 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.062 ms, self 0.062 ms, 1000 calls
```

### Frame 30: interval 3.175 ms, CPU 2.959 ms, GPU -

```
Frame  total 2.959 ms, self 0.124 ms
  Physics.Overlap  total 2.790 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.564 ms, self 2.564 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

### Frame 56: interval 3.173 ms, CPU 2.957 ms, GPU -

```
Frame  total 2.957 ms, self 0.124 ms
  Physics.Overlap  total 2.788 ms, self 0.125 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.566 ms, self 2.566 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.059 ms, self 0.059 ms, 1000 calls
```

### Frame 33: interval 3.173 ms, CPU 2.959 ms, GPU -

```
Frame  total 2.959 ms, self 0.123 ms
  Physics.Overlap  total 2.790 ms, self 0.123 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 2.568 ms, self 2.568 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.061 ms, self 0.061 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
