# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 6.960 ms | 6.951 ms | 6.995 ms | 7.111 ms | 7.139 ms | 6.896 ms |
| CPU main thread | 6.754 ms | 6.747 ms | 6.784 ms | 6.880 ms | 6.896 ms | 6.712 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 6.687 ms
- Other: 0.067 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 6.403 ms | 6.403 ms | 1000 | 6.529 ms | 64/64 |
| Physics.Overlap | Physics | 0.110 ms | 6.652 ms | 1000 | 6.779 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.101 ms | 0.101 ms | 1000 | 0.108 ms | 64/64 |
| Frame | Other | 0.067 ms | 6.754 ms | 1 | 6.896 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.038 ms | 0.038 ms | 1000 | 0.061 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.035 ms | 0.035 ms | 1000 | 0.104 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 33: interval 7.139 ms, CPU 6.747 ms, GPU -

```
Frame  total 6.747 ms, self 0.071 ms
  Physics.Overlap  total 6.643 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.394 ms, self 6.394 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.104 ms, self 0.104 ms, 1000 calls
```

### Frame 1: interval 7.111 ms, CPU 6.742 ms, GPU -

```
Frame  total 6.742 ms, self 0.067 ms
  Physics.Overlap  total 6.641 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.390 ms, self 6.390 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.105 ms, self 0.105 ms, 1000 calls
```

### Frame 52: interval 7.090 ms, CPU 6.712 ms, GPU -

```
Frame  total 6.712 ms, self 0.067 ms
  Physics.Overlap  total 6.612 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.367 ms, self 6.367 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.100 ms, self 0.100 ms, 1000 calls
```

### Frame 36: interval 6.995 ms, CPU 6.777 ms, GPU -

```
Frame  total 6.777 ms, self 0.067 ms
  Physics.Overlap  total 6.677 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.429 ms, self 6.429 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.100 ms, self 0.100 ms, 1000 calls
```

### Frame 6: interval 6.990 ms, CPU 6.768 ms, GPU -

```
Frame  total 6.768 ms, self 0.067 ms
  Physics.Overlap  total 6.667 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.416 ms, self 6.416 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.101 ms, self 0.101 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
