# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 7.023 ms | 7.011 ms | 7.068 ms | 7.198 ms | 7.211 ms | 6.967 ms |
| CPU main thread | 6.811 ms | 6.806 ms | 6.858 ms | 6.966 ms | 6.980 ms | 6.760 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 6.745 ms
- Other: 0.066 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 6.461 ms | 6.461 ms | 1000 | 6.617 ms | 64/64 |
| Physics.Overlap | Physics | 0.112 ms | 6.709 ms | 1000 | 6.865 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.102 ms | 0.102 ms | 1000 | 0.110 ms | 64/64 |
| Frame | Other | 0.066 ms | 6.811 ms | 1 | 6.980 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.036 ms | 0.036 ms | 1000 | 0.110 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.035 ms | 0.035 ms | 1000 | 0.070 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 31: interval 7.211 ms, CPU 6.775 ms, GPU -

```
Frame  total 6.775 ms, self 0.066 ms
  Physics.Overlap  total 6.675 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.429 ms, self 6.429 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.101 ms, self 0.101 ms, 1000 calls
```

### Frame 1: interval 7.198 ms, CPU 6.803 ms, GPU -

```
Frame  total 6.803 ms, self 0.066 ms
  Physics.Overlap  total 6.702 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.456 ms, self 6.456 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.101 ms, self 0.101 ms, 1000 calls
```

### Frame 7: interval 7.177 ms, CPU 6.792 ms, GPU -

```
Frame  total 6.792 ms, self 0.065 ms
  Physics.Overlap  total 6.692 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.445 ms, self 6.445 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

### Frame 52: interval 7.068 ms, CPU 6.835 ms, GPU -

```
Frame  total 6.835 ms, self 0.066 ms
  Physics.Overlap  total 6.734 ms, self 0.112 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.486 ms, self 6.486 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

### Frame 24: interval 7.067 ms, CPU 6.835 ms, GPU -

```
Frame  total 6.835 ms, self 0.066 ms
  Physics.Overlap  total 6.734 ms, self 0.111 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.486 ms, self 6.486 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.103 ms, self 0.103 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
