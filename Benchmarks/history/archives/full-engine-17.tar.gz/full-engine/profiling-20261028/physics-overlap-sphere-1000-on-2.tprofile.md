# Tessera Profiler report

Frames 0 to 63 (64 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 7.002 ms | 7.006 ms | 7.031 ms | 7.038 ms | 7.152 ms | 6.934 ms |
| CPU main thread | 6.799 ms | 6.800 ms | 6.828 ms | 6.834 ms | 6.934 ms | 6.751 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 6.731 ms
- Other: 0.068 ms

## Thread 'Benchmark Main': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Overlap.NativeContacts | Physics | 6.451 ms | 6.451 ms | 1000 | 6.490 ms | 64/64 |
| Physics.Overlap | Physics | 0.109 ms | 6.695 ms | 1000 | 6.763 ms | 64/64 |
| Physics.Overlap.MapContacts | Physics | 0.100 ms | 0.100 ms | 1000 | 0.105 ms | 64/64 |
| Frame | Other | 0.068 ms | 6.798 ms | 1 | 6.934 ms | 64/64 |
| Physics.Query.SphereShape | Physics | 0.035 ms | 0.035 ms | 1000 | 0.101 ms | 64/64 |
| Physics.Query.Prepare | Physics | 0.035 ms | 0.035 ms | 1000 | 0.067 ms | 64/64 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 7.152 ms, CPU 6.817 ms, GPU -

```
Frame  total 6.817 ms, self 0.068 ms
  Physics.Overlap  total 6.715 ms, self 0.110 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.470 ms, self 6.470 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.100 ms, self 0.100 ms, 1000 calls
```

### Frame 16: interval 7.038 ms, CPU 6.822 ms, GPU -

```
Frame  total 6.822 ms, self 0.067 ms
  Physics.Overlap  total 6.721 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.476 ms, self 6.476 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.101 ms, self 0.101 ms, 1000 calls
```

### Frame 53: interval 7.034 ms, CPU 6.771 ms, GPU -

```
Frame  total 6.771 ms, self 0.068 ms
  Physics.Overlap  total 6.669 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.428 ms, self 6.428 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.099 ms, self 0.099 ms, 1000 calls
```

### Frame 5: interval 7.031 ms, CPU 6.758 ms, GPU -

```
Frame  total 6.758 ms, self 0.067 ms
  Physics.Overlap  total 6.657 ms, self 0.108 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.416 ms, self 6.416 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.100 ms, self 0.100 ms, 1000 calls
```

### Frame 43: interval 7.031 ms, CPU 6.802 ms, GPU -

```
Frame  total 6.802 ms, self 0.067 ms
  Physics.Overlap  total 6.701 ms, self 0.109 ms, 1000 calls
    Physics.Overlap.NativeContacts  total 6.458 ms, self 6.458 ms, 1000 calls
    Physics.Overlap.MapContacts  total 0.100 ms, self 0.100 ms, 1000 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
