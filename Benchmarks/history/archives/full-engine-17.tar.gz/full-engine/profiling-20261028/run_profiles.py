#!/usr/bin/env python3
"""Sequential Release captures using Tessera's profiler; reports and raw captures retained."""
from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
jobs=[('tessera','physics-overlap-sphere',1000),('tessera','physics-overlap-capsule',1000),('tessera','physics-overlap-box',1000),('features','ai-nav-path',1),('features','ai-nav-path',100)]
manifest={'started':datetime.datetime.now().isoformat(),'jobs':[]}
for project,case,count in jobs:
 binary=R/project/'build/Release_Linux64/Benchmark/Benchmark'
 for mode in ['off','on']:
  for repeat in range(3):
   stem=f'{case}-{count}-{mode}-{repeat}';args=[str(binary),case,str(count),'120','64']
   if mode=='on':args+=['--capture',str(OUT/(stem+'.tprofile'))]
   print(stem,flush=True)
   run=subprocess.run(args,cwd=R,capture_output=True,text=True,timeout=180)
   (OUT/(stem+'.log')).write_text(run.stdout+'\n'+run.stderr)
   entry={'case':case,'count':count,'mode':mode,'repeat':repeat,'args':args,'exit':run.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
   manifest['jobs'].append(entry)
   (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
   if run.returncode:raise RuntimeError(stem+' failed')
manifest['completed']=datetime.datetime.now().isoformat();(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
