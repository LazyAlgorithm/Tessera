#!/usr/bin/env python3
from pathlib import Path
import statistics as st,json,re,csv,hashlib,shutil
O=Path(__file__).resolve().parent;R=O.parents[2]
M=json.loads((O/'manifest.json').read_text());assert len(M['jobs'])==30 and all(x['exit']==0 for x in M['jobs'])
groups={};checks={};markers={}
for j in M['jobs']:
 key=(j['case'],j['count']);stem=f"{j['case']}-{j['count']}-{j['mode']}-{j['repeat']}";log=(O/(stem+'.log')).read_text()
 times=[float(x.rsplit(',',1)[1]) for x in log.splitlines() if x.startswith('BENCH,tessera,')];assert len(times)==64
 groups.setdefault((*key,j['mode']),[]).append(st.median(times))
 c={x.split(',')[1]:x.split(',',2)[2] for x in log.splitlines() if x.startswith('CHECK,')};checks.setdefault(key,[]).append(c)
 if j['mode']=='on':
  report=(O/(stem+'.tprofile.md')).read_text();assert '64 recorded' in report
  for line in report.splitlines():
   a=[x.strip() for x in line.strip('|').split('|')]
   if len(a)==7 and a[1] in ['AI','Physics','Other'] and a[2].endswith(' ms'):
    markers.setdefault((*key,a[0]),[]).append((float(a[2][:-3]),float(a[3][:-3]),float(a[4])))
for k,cs in checks.items():
 for name in ['hits','path_waypoints','path_length','checksum']:
  values={c[name] for c in cs if name in c};assert len(values)<=1,(k,name,values)
def metric(key,name,col=1):return st.median([r[col] for r in markers[(*key,name)]])
lines=['# Profiling the remaining desktop gaps','','Captured with the engine profiler in Release Linux standalone workloads. Three fresh recording-off processes and three recording-on processes per case; 120 warmup batches, then 64 measured batches per process. One profiler frame is one workload batch, not a rendered gameplay frame. All warmup and scene setup are excluded from captures. No Unity process ran. No optimization algorithm changed in this pass.','','## Recording overhead','','Batch values are medians of process medians from BENCH rows, excluding EndFrame collection and report/file writing. On/off differences include recording overhead and process-to-process clock or scheduling variation; they do not isolate instrumentation cost or replace the earlier unprofiled engine comparison.','','| Workload | N | Recording off ms | Recording on ms | Increase |','|---|---:|---:|---:|---:|']
for key in sorted(checks):
 a=st.median(groups[(*key,'off')]);b=st.median(groups[(*key,'on')]);lines.append(f'| {key[0]} | {key[1]} | {a:.6f} | {b:.6f} | {(b/a-1)*100:.1f}% |')
lines+=['','## Physics','','Each batch contains 1,000 overlap queries against 1,000 box bodies. Markers report median across three captures of average per-frame times, rounded to the engine report’s 0.001 ms precision. The native marker includes broadphase/narrowphase traversal and full contact collection; it does not separately resolve GJK, EPA or individual native shape-pair routines.','','| Query | Native contacts ms | Hit mapping ms | Query preparation ms | Shape cache ms | Native / recorded frame |','|---|---:|---:|---:|---:|---:|']
for case,shape in [('sphere','Sphere'),('capsule','Capsule'),('box','Box')]:
 k=('physics-overlap-'+case,1000);native=metric(k,'Physics.Overlap.NativeContacts');frame=metric(k,'Frame');lines.append(f'| {case} | {native:.3f} | {metric(k,"Physics.Overlap.MapContacts"):.3f} | {metric(k,"Physics.Query.Prepare"):.3f} | {metric(k,"Physics.Query."+shape+"Shape"):.3f} | {native/frame*100:.1f}% |')
lines+=['','The measured bottleneck is inside the native contact query. Shape caching, engine preparation and mapping hits back to objects are small contributors. Specialized sphere–box and capsule–box contact paths are therefore better candidates than further list-copy changes. This is a priority inference from these workloads; the capture does not prove which internal native algorithm dominates. Further native sampling or markers would be needed before choosing that implementation.','','## Navigation','','100 paths per frame on the existing maze; no route cache. Search total includes corridor construction. Smoothing total includes line checks: do not add these nested totals together.','','| Marker | Self ms / 100 paths | Total ms / 100 paths | Calls / batch |','|---|---:|---:|---:|']
k=('ai-nav-path',100)
for name in ['Navigation.Smooth','Navigation.LineClear','Navigation.Search','Navigation.Corridor','Navigation.Nearest','Navigation.Regions','Navigation.Nodes']:
 lines.append(f'| {name} | {metric(k,name,0):.3f} | {metric(k,name):.3f} | {metric(k,name,2):.0f} |')
frame=metric(k,'Frame');smooth=metric(k,'Navigation.Smooth');clear=metric(k,'Navigation.LineClear');search=metric(k,'Navigation.Search');corridor=metric(k,'Navigation.Corridor')
lines += ['',f'Smoothing is {smooth/frame*100:.1f}% of the recorded CPU frame; line checks account for {clear/smooth*100:.1f}% of smoothing time. There are 900 LineClear calls per 100 paths (nine per path). The capture reports 2,500 search visits per batch, or 25 nodes per path. Search including its corridor is {search:.3f} ms; corridor construction alone is {corridor:.3f} ms. Region labels and quadtree revision checks are not the dominant work in this steady-state workload.','','The first navigation optimization should target repeated line-of-sight traversal during smoothing. LineClear currently advances in quarter-cell increments and validates the surrounding linked cells. An exact grid-boundary traversal or reuse of already verified corridor segments could reduce redundant work, but must retain clearance, diagonal-link, ledge and height checks. Adding another graph hierarchy is a lower priority for this particular maze. Skipping smoothing would change path behavior and is not a demonstrated equivalent optimization.','','## Validation and artifacts','','Profiler, Navigation, ShapeQueries and Layers: four suites passed. All 30 processes exited successfully, every process emitted all 64 samples, all 15 captures contain 64 frames, and hits/path length/waypoint counts/checksums match between recording modes. This profiles warmed serial queries and paths; it does not establish cold-bake, moving-obstacle, crowds, worker scaling, rendering, skinning or audio bottlenecks.','','- [Test results](tests.log), [run manifest](manifest.json), [runner](run_profiles.py).','- [Sphere capture report](physics-overlap-sphere-1000-on-0.tprofile.md), [capsule report](physics-overlap-capsule-1000-on-0.tprofile.md), [box report](physics-overlap-box-1000-on-0.tprofile.md).','- [100-path capture report](ai-nav-path-100-on-0.tprofile.md), [single-path report](ai-nav-path-1-on-0.tprofile.md).','- Matching `.tprofile` files open in Window > Profiler > Load. All process logs, repeats and an earlier coarse capture pass are retained here.','- Source snapshots and SHA-256 hashes are in source/ and source-sha256.json. Instrumentation is opt-in through the engine’s recording switch; the benchmark harness accepts `SCENARIO COUNT WARMUP SAMPLES --capture /absolute/path.tprofile`.','']
(O/'REPORT.md').write_text('\n'.join(lines))
files=['Engine/src/AI/NavigationData.bf','Engine/src/AI/NavigationNodes.bf','Engine/src/Physics/PhysicsWorld.bf','Benchmarks/full-engine/features/src/Program.bf','Benchmarks/full-engine/tessera/src/Program.bf']
hashes={}
for name in files:
 src=R/name;dest=O/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);hashes[name]=hashlib.sha256(src.read_bytes()).hexdigest()
(O/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
# A concise front section keeps the desktop results useful without replacing historical timings.
p=Path('/home/zerker24/Desktop/Tessera Benchmark Results.md');s=p.read_text();start='<!-- profiling-20261028:start -->';end='<!-- profiling-20261028:end -->'
if start in s:s=s.split(end,1)[1].lstrip()
p.write_text(start+'\n# Profiler findings — 28 October 2026\n\n'+f'Native contact collection dominates physics overlap time. Navigation smoothing consumes {smooth/frame*100:.0f}% of its recorded frame; {clear/smooth*100:.0f}% of smoothing is LineClear traversal (nine calls per path). Optimize native contacts and repeated smoothing line checks first.\n\n'+f'Full report, recording overhead, raw captures and validation: {O}/REPORT.md\n\nFour regression suites passed; 30 standalone processes completed. Profiler timings include recording overhead and do not replace the historical unprofiled comparison below.\n'+end+'\n\n'+s)
print('\n'.join(lines[:35]))
