#!/usr/bin/env python3
"""Report rebuilt Tessera timings against frozen, previously measured baselines."""
from pathlib import Path
import csv,json,statistics,datetime,hashlib
R=Path(__file__).resolve().parent
manifest=json.loads((R/'RERUN_MANIFEST.json').read_text());baseline=json.loads((R/'confirmation-baseline.json').read_text())
lines=['# Tessera performance confirmation','','Updated '+datetime.datetime.now().isoformat(timespec='seconds'),'',
'Tessera was rebuilt in Release and rerun in fresh sequential standalone processes. Unity was not rebuilt or rerun after the user requested Tessera-only measurements; its previously saved results are frozen in confirmation-baseline.json. The earlier interrupted paired attempt is excluded.',
'', 'Five processes per workload. Each process warms up for 120 iterations and records 300 samples, except audio/image decoding (30 warmup, 100 samples). Values below are medians of process medians, in milliseconds; lower is better. Queries contain 1,000 queries per sample. Rendering measures whole-frame intervals, not isolated GPU execution. A positive reduction means Tessera took less time than previously.', '',
'| Workload | N | Previous Tessera ms | Rebuilt Tessera ms | Tessera time reduction | Saved Unity ms | Rebuilt Tessera / Unity |',
'|---|---:|---:|---:|---:|---:|---:|']
details=[];failures=[]
for job in manifest['jobs']:
 folder=Path(job['results']);env=json.loads((folder/'environment.json').read_text())['arguments'];w=str(env.get('width',1280));h=str(env.get('height',720))
 groups={}
 for row in csv.DictReader((folder/'summary.csv').open()):groups.setdefault((row['scenario'],row['count']),[]).append(row)
 failures.extend(job['failures'])
 for (scenario,n),rows in groups.items():
  med=lambda data,field='median_ms':statistics.median(float(x[field]) for x in data)
  previous=baseline.get('|'.join([scenario,n,'tessera',w,h]));unity=baseline.get('|'.join([scenario,n,'unity',w,h]))
  current=med(rows);p=med(previous['rows']) if previous else None;u=med(unity['rows']) if unity else None
  label=scenario+(f' @{w}x{h}' if (w,h)!=('1280','720') else '')
  fmt=lambda x:f'{x:.4f}' if x is not None else '—'
  reduction=f'{100*(1-current/p):.1f}%' if p else '—';ratio=f'{current/u:.2f}×' if u else '—'
  lines.append(f'| {label} | {n} | {fmt(p)} | {current:.4f} | {reduction} | {fmt(u)} | {ratio} |')
  per=[float(x['median_ms']) for x in rows]
  details.append(f'| {label} | {n} | {len(rows)} | {min(per):.4f}–{max(per):.4f} | {med(rows,"p95_ms"):.4f} | [{folder.name}](results/{folder.name}/report.md) |')
lines+=['','A ratio above 1 means Tessera took longer than the saved Unity measurement; below 1 means less time. These ratios apply only to the listed workloads.','',
'## Repeatability and provenance','','| Workload | N | Processes | Range of process medians ms | Median process p95 ms | Raw results |','|---|---:|---:|---:|---:|---|',*details,'',
'## Interpretation limits','',
'- CheckSphere/CheckBox/CheckCapsule are new any-hit queries. They stop at the first contact and have no matching saved Unity Check* measurement. They are reported separately from full contact-collecting overlaps; no cross-engine ratio is assigned.',
'- Existing overlap comparisons retain the original operations: Tessera collects shape contacts while Unity Overlap*NonAlloc collects colliders. Contact detail differs even where query geometry matches.',
'- Navigation compares Tessera grid paths with Unity polygon NavMesh paths. Path shape and representation differ; this is not an equal-quality pathfinding ranking.',
'- Rendering pipelines, lighting and effects differ. Tessera rendering controls are antialiasing off, render scale 1, VSync off; framebuffer dimensions are checked. Skinning forces all characters to deform. CPU/GPU skinning use separate saved Unity builds.',
'- N means bodies for physics, objects for rendering, characters for skinning/animators, path requests for navigation, voices for audio, and image decodes for image loading. Audio captures 1,024 stereo frames at 48 kHz per sample.',
'- Old and new runs occurred at different times. Ratios against frozen Unity baselines do not control changes in machine load, temperature or clocks between sessions. Per-run environment and logs remain available.',
'- Only performance measurements and checks that timed work occurred were run. Existing Unity projects and engine source were not modified by this rerun; no changes were pushed.',
'', '## Build and validation','',
'Release builds succeeded for tessera, features, extended and animation. The additional physics-checks project was built against the captured engine snapshot: concurrent live profiler additions caused a compile failure in its first attempt, and were left untouched. The successful snapshot build includes the new Check* methods. CMake/Ninja reported native libraries up to date. GNU linking was used; ThinLTO tools are unavailable. See confirmation-*-build.log, confirmation-build-manifest.json, confirmation-engine-source/, RERUN_MANIFEST.json and each result folder for build hashes, settings, source snapshots, raw samples and validation checks.',
'',f'Completed jobs: {len(manifest["jobs"])}. Recorded failed runs: {len(failures)}.',json.dumps(failures,indent=2)]
(R/'CONFIRMATION.md').write_text('\n'.join(lines)+'\n')
# Add a compact, easily found update without discarding the existing inventory.
note=['<!-- confirmation:start -->','# Latest Tessera-only performance rerun','',f'Updated {datetime.datetime.now().isoformat(timespec="seconds")}.', '',f'Results and before/after comparison: {R}/CONFIRMATION.md','',f'Completed groups: {len(manifest["jobs"])}. Failed runs: {len(failures)}. Unity baseline reused; Unity was not rebuilt or rerun.','',*lines[8:next(i for i,x in enumerate(lines) if x.startswith('A ratio above'))], '<!-- confirmation:end -->','']
for path in [R/'TEST_STATUS.md',Path.home()/'Desktop/Tessera Benchmark Results.md']:
 text=path.read_text() if path.exists() else ''
 if '<!-- confirmation:end -->' in text:text=text.split('<!-- confirmation:end -->',1)[1].lstrip('\n')
 path.write_text('\n'.join(note)+'\n'+text)
print('Wrote CONFIRMATION.md and updated Desktop results.')
