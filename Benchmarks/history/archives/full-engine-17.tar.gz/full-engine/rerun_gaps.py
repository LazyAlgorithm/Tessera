#!/usr/bin/env python3
"""Confirm performance gaps with Tessera-only fresh processes against frozen Unity baselines."""
import subprocess,sys,json,datetime,csv,statistics
from pathlib import Path
R=Path(__file__).resolve().parent
jobs=[
 ('physics',['--scenarios','physics-overlap-sphere','physics-overlap-capsule','physics-overlap-box','physics-boxcast','physics-capsulecast','physics-spherecast','physics-mesh-raycast','--counts','1000']),
 ('materials-culling',['--scenarios','render-materials','render-culling','--counts','1000','10000']),
 ('transparency',['--features','--native-project','extended','--unity-variant','unity-extras','--scenarios','render-transparency','--counts','1000']),
 ('skinning',['--features','--scenarios','render-skinning-cpu','render-skinning-gpu','--counts','100']),
 ('skinning-1080',['--features','--native-project','extended','--unity-variant','unity-features','--fullscreen','--width','1920','--height','1080','--scenarios','render-skinning-gpu','--counts','1000']),
 ('animator',['--features','--native-project','animation','--unity-variant','unity-animation','--scenarios','animator-clips','animator-layered','--counts','100','1000']),
 ('navigation',['--features','--scenarios','ai-nav-path','--counts','1','100']),
 ('audio-image',['--features','--native-project','extended','--unity-variant','unity-extras','--scenarios','audio-mix','asset-image-decode','--counts','100','--warmup','30','--samples','100']),
]
manifest={'started':datetime.datetime.now().isoformat(),'description':'Rebuilt Tessera only, five fresh sequential processes per case. Unity baseline frozen from prior runs; Unity is not rebuilt or executed.','jobs':[]}
mp=R/'RERUN_MANIFEST.json'
# Freeze all previously complete per-engine datasets before this confirmation.
baseline={}
for folder in sorted((R/'results').iterdir()):
 if folder.name>='20261027-211752' or (folder/'EXCLUDED.md').exists() or not(folder/'summary.csv').exists():continue
 env=json.loads((folder/'environment.json').read_text())['arguments']
 if env['samples']<100 or env.get('screenshots'):continue
 groups={}
 for row in csv.DictReader((folder/'summary.csv').open()):
  key=(row['scenario'],row['count'],row['engine'],str(env.get('width',1280)),str(env.get('height',720)))
  groups.setdefault(key,[]).append(row)
 for key,rows in groups.items():
  if len(rows)==env['repeats']:baseline['|'.join(key)]={'folder':folder.name,'rows':rows}
(R/'confirmation-baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
for name,args in jobs:
 print('START '+name,flush=True)
 log=R/('confirmation-'+name+'.log')
 with log.open('w') as f:
  result=subprocess.run([sys.executable,str(R/'run.py'),'--engines','tessera','--repeats','5','--warmup','120','--samples','300','--timeout','240',*args],stdout=f,stderr=subprocess.STDOUT)
 lines=log.read_text().splitlines();out=next((x.split('Results: ',1)[1] for x in lines if x.startswith('Results: ')),None)
 failures=json.loads((Path(out)/'failures.json').read_text()) if out and (Path(out)/'failures.json').exists() else ['runner did not finish']
 manifest['jobs'].append({'name':name,'args':args,'results':out,'exit':result.returncode,'failures':failures})
 mp.write_text(json.dumps(manifest,indent=2)+'\n')
 print('DONE '+name+' failures='+str(len(failures)),flush=True)
manifest['finished']=datetime.datetime.now().isoformat();mp.write_text(json.dumps(manifest,indent=2)+'\n')
