# Standalone engine benchmark results

Milliseconds; lower is better. Median of per-run medians. Query timings are per batch of 1,000 queries. Whole-frame intervals include CPU/GPU synchronization and pacing; they are not GPU timestamps.

| Workload | Population | Tessera ms | Unity ms | Unity / Tessera |
|---|---:|---:|---:|---:|
| physics-raycast | 100 | 0.1548 | 0.1823 | 1.18 |
| scene-scripts | 100 | 0.0029 | 0.0039 | — |
| render-shared | 100 | 0.1527 | 0.2035 | 1.33 |
| render-particles | 100 | 0.1471 | 0.2017 | 1.37 |

Read ../../README.md for scope and interpretation. Rendering uses different native pipelines and is not an equal-image-quality ranking. Scene-empty/scripts are native traversal versus explicit C# calls and are not ranked. CCD and character results require behavior checks.

## Failures

[]
