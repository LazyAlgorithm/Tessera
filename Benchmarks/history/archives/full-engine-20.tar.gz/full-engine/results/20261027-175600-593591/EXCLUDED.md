Excluded from matched-resolution comparison: the desktop window manager clamped Tessera to 1920x1012, while Unity retained the requested resolution. Raw measurements are retained for diagnostics.
