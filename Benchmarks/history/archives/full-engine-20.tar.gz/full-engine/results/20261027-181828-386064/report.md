# Standalone engine benchmark results

Milliseconds; lower is better. Median of per-run medians. Query timings are per batch of 1,000 queries. Whole-frame intervals include CPU/GPU synchronization and pacing; they are not GPU timestamps.

| Workload | Population | Tessera ms | Unity ms | Unity / Tessera |
|---|---:|---:|---:|---:|
| render-skinning-gpu | 1 | 0.1194 | incomplete | — |
| render-skinning-gpu | 10 | 0.1828 | incomplete | — |
| render-skinning-gpu | 100 | 0.8586 | incomplete | — |
| render-skinning-cpu | 1 | 0.2421 | incomplete | — |
| render-skinning-cpu | 10 | 1.3314 | incomplete | — |
| render-skinning-cpu | 100 | 12.9152 | incomplete | — |

Read ../../README.md for scope and interpretation. Rendering uses different native pipelines and is not an equal-image-quality ranking. Scene-empty/scripts are native traversal versus explicit C# calls and are not ranked. CCD and character results require behavior checks.

## Failures

[]
