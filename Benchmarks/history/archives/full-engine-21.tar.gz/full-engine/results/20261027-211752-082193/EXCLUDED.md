Interrupted paired confirmation before rebuilding. User requested Tessera-only rebuild and reruns, retaining the original Unity baseline. Do not aggregate this partial run.
