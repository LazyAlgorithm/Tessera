# Standalone engine benchmark results

Milliseconds; lower is better. Median of per-run medians. Query timings are per batch of 1,000 queries. Whole-frame intervals include CPU/GPU synchronization and pacing; they are not GPU timestamps.

| Workload | Population | Tessera ms | Unity ms | Unity / Tessera |
|---|---:|---:|---:|---:|
| ai-nav-path | 1 | 0.0066 | incomplete | — |
| ai-nav-path | 100 | 0.6447 | incomplete | — |
| ai-nav-path | 1000 | 6.4145 | incomplete | — |
| ai-nav-path-batch | 1 | 0.0065 | incomplete | — |
| ai-nav-path-batch | 100 | 0.0800 | incomplete | — |
| ai-nav-path-batch | 1000 | 0.6414 | incomplete | — |

Read ../../README.md for scope and interpretation. Rendering uses different native pipelines and is not an equal-image-quality ranking. Scene-empty/scripts are native traversal versus explicit C# calls and are not ranked. CCD and character results require behavior checks.

## Failures

[]
