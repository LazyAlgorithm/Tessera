#!/usr/bin/env python3
"""Sequential standalone benchmark runner. Keeps raw samples and rejects incomplete runs."""
import datetime
import atexit,sys
import argparse,csv,hashlib,json,math,os,platform,statistics,subprocess,time,shutil,signal
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PHYSICS=['physics-free','physics-pile','physics-mixed-shapes','physics-mesh','physics-raycast','physics-mesh-raycast','physics-spherecast','physics-capsulecast','physics-boxcast','physics-overlap-sphere','physics-overlap-capsule','physics-overlap-box','physics-discrete','physics-ccd','physics-characters-flat','physics-characters-steps']
RENDER=['render-shared','render-materials','render-moving','render-culling','render-shadows','render-spheres','render-lights','render-physics','render-particles']
SCENE=['scene-empty','scene-scripts','scene-transforms','scene-hierarchy','scene-churn']
p=argparse.ArgumentParser();p.add_argument('--features',action='store_true');p.add_argument('--fullscreen',action='store_true');p.add_argument('--width',type=int,default=1280);p.add_argument('--height',type=int,default=720);p.add_argument('--native-project');p.add_argument('--unity-variant');p.add_argument('--suite',choices=['all','physics','render','scene'],default='all');p.add_argument('--scenarios',nargs='+');p.add_argument('--counts',nargs='+',type=int,default=[100,1000,10000]);p.add_argument('--warmup',type=int,default=120);p.add_argument('--samples',type=int,default=300);p.add_argument('--repeats',type=int,default=3);p.add_argument('--timeout',type=int,default=180);p.add_argument('--engines',nargs='+',default=['tessera','unity']);p.add_argument('--screenshots',action='store_true');a=p.parse_args()
cases=a.scenarios or {'all':PHYSICS+RENDER+SCENE,'physics':PHYSICS,'render':RENDER,'scene':SCENE}[a.suite]
server=None
if 'http-local' in cases:
 server=subprocess.Popen([sys.executable,str(ROOT/'http_server.py')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);atexit.register(server.terminate);time.sleep(.2)
 if server.poll() is not None:raise RuntimeError('Could not start loopback HTTP fixture on 127.0.0.1:39439')
out=ROOT/'results'/datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');out.mkdir(parents=True)
commands={'tessera':[str(ROOT/(a.native_project or ('features' if a.features else 'tessera'))/'build/Release_Linux64/Benchmark/Benchmark')],'unity':[str(ROOT/'builds/unity/Benchmark')]}
def capture(cmd):
 try:return subprocess.run(cmd,capture_output=True,text=True,timeout=15).stdout
 except Exception as e:return str(e)
meta={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'arguments':vars(a),'platform':platform.platform(),'cpu':capture(['lscpu']),'gpu':capture(['nvidia-smi']),'glxinfo':capture(['glxinfo','-B']),'display':{k:os.getenv(k) for k in ['DISPLAY','WAYLAND_DISPLAY','XDG_SESSION_TYPE']},'engine_source_git':capture(['git','-C',str(ROOT.parents[1]),'status','--short']),'native_build_type':'Release (-O3 -DNDEBUG)','tessera_build':'Beef Release; GNU linker; ThinLTO unavailable','unity_build':'6000.3.27f1 Mono standalone, BuildOptions.None, development=false, Vulkan, linear color, no MSAA, vsync=0','sources':{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for pattern in ['tessera/src/*.bf','features/src/*.bf','extras/src/*.bf','deep/src/*.bf','animation/src/*.bf','editor-perf/src/*.bf','extended/src/*.bf','physics-checks/src/*.bf','unity/Assets/*.cs','unity/Assets/Editor/*.cs','*.py'] for x in ROOT.glob(pattern)}}
(out/'environment.json').write_text(json.dumps(meta,indent=2))
for name in meta['sources']:
 dest=out/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,dest)
artifacts=[Path(c[0]) for c in commands.values()]
if a.features:
 variants={a.unity_variant} if a.unity_variant else {'unity-cpu' if 'skinning-cpu' in c else 'unity-ai' if c.startswith('ai-') else 'unity-features' for c in cases}
 artifacts=[Path(commands['tessera'][0])]+[ROOT/'builds'/v/'Benchmark' for v in variants]
for binary in list(artifacts):
 artifacts.extend(binary.parent.glob('*_Data/Managed/Assembly-CSharp.dll'))
 if (binary.parent/'UnityPlayer.so').exists():artifacts.append(binary.parent/'UnityPlayer.so')
meta['binary_sha256']={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in artifacts if x.exists()}
(out/'environment.json').write_text(json.dumps(meta,indent=2))
rows=[];summaries=[];checks=[];failures=[];telemetry=[]
print('Results: '+str(out),flush=True)
for case in cases:
 for count in a.counts:
  for rep in range(a.repeats):
   for engine in (a.engines if rep%2==0 else list(reversed(a.engines))):
    name=f'{engine}-{case}-{count}-{rep}';print(name,flush=True);raw=out/(name+'.raw.csv');log=out/(name+'.log');shot=out/(name+'.png');cmd=commands[engine].copy()
    if a.features and engine=='unity':cmd=[str(ROOT/'builds'/(a.unity_variant or ('unity-cpu' if 'skinning-cpu' in case else 'unity-ai' if case.startswith('ai-') else 'unity-features'))/'Benchmark')]
    if engine=='tessera':
     cmd += [case,str(count),str(a.warmup),str(a.samples)]
     if a.width!=1280 or a.height!=720 or a.fullscreen:cmd += [str(a.width),str(a.height)]
     if a.fullscreen:cmd += ["--fullscreen"]
     if a.screenshots and rep==0 and case.startswith('render-'):cmd += [str(shot)]
    else:
     if not case.startswith('render-') and case!='audio-mix':cmd+=['-batchmode','-nographics']
     cmd+=['-screen-fullscreen','1' if a.fullscreen else '0','-screen-width',str(a.width),'-screen-height',str(a.height),'--scenario',case,'--count',str(count),'--warmup',str(a.warmup),'--samples',str(a.samples),'--output',str(raw),'-logFile',str(log)]
     if a.screenshots and rep==0 and case.startswith('render-'):cmd+=['--screenshot',str(shot)]
    cmd=['/usr/bin/time','-f','RESOURCE,peak_rss_kib,%M',*cmd];start=time.monotonic()
    try:
     proc=subprocess.Popen(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
     try:stdout,stderr=proc.communicate(timeout=a.timeout)
     except subprocess.TimeoutExpired:
      os.killpg(proc.pid,signal.SIGKILL);stdout,stderr=proc.communicate();(out/(name+'.process.log')).write_text(stdout+'\n'+stderr);raise ValueError(f'timeout after {a.timeout}s; process group terminated')
     run=subprocess.CompletedProcess(cmd,proc.returncode,stdout,stderr)
     (out/(name+'.process.log')).write_text(run.stdout+'\n'+run.stderr)
     data=run.stdout if engine=='tessera' else raw.read_text() if raw.exists() else ''
     if engine=='tessera':log.write_text(data+'\n'+run.stderr)
     if run.returncode:raise ValueError('exit '+str(run.returncode))
     combined=log.read_text(errors='replace')
     if any(x in combined for x in ['Exception:','[Physics] Step threw','Raycast correctness failed','Nonfinite position']):raise ValueError('engine error in log')
     samples=[];metric=''
     for line in data.splitlines():
      if line.startswith('TELEMETRY,'):
       _,index,key,value=line.split(',');telemetry.append([engine,case,count,rep,index,key,value])
      if line.startswith('CHECK,'):
       _,key,value=line.split(',',2);checks.append([engine,case,count,rep,key,value])
      if line.startswith('BENCH,'+engine+','):
       _,eng,scenario,n,index,metric,value=line.split(',');v=float(value)
       if scenario!=case or int(n)!=count or int(index)!=len(samples) or not math.isfinite(v) or v<0:raise ValueError('invalid sample')
       samples.append(v)
     if case.startswith('render-'):
      for k,expected in [('framebuffer_width',a.width),('framebuffer_height',a.height)]:
       actual=next((int(line.split(',')[2]) for line in data.splitlines() if line.startswith('CHECK,'+k+',')),None)
       if actual!=expected:raise ValueError(f'{k}: requested {expected}, got {actual}')
     if len(samples)!=a.samples:raise ValueError(f'expected {a.samples} samples, got {len(samples)}')
     if engine=='unity' and case.startswith('render-') and 'CHECK,graphics_device,NVIDIA' not in data:raise ValueError('not verified NVIDIA hardware')
     for i,v in enumerate(samples):rows.append([engine,case,count,rep,i,metric,v])
     ordered=sorted(samples);q=lambda p:ordered[max(0,math.ceil(p*len(ordered))-1)]
     summaries.append([engine,case,count,rep,metric,statistics.mean(samples),statistics.median(samples),q(.95),q(.99)])
     for line in run.stderr.splitlines():
      if line.startswith('RESOURCE,'):_,k,v=line.split(',');checks.append([engine,case,count,rep,k,v])
     checks.append([engine,case,count,rep,'process_wall_seconds',time.monotonic()-start])
    except Exception as e:
     failures.append({'run':name,'error':str(e)});print('FAILED '+str(e),flush=True)
    for filename,header,table in [('samples.csv',['engine','scenario','count','repeat','sample','metric','ms'],rows),('summary.csv',['engine','scenario','count','repeat','metric','mean_ms','median_ms','p95_ms','p99_ms'],summaries),('checks.csv',['engine','scenario','count','repeat','check','value'],checks),('telemetry.csv',['engine','scenario','count','repeat','sample','metric','value'],telemetry)]:
     with (out/filename).open('w') as f:w=csv.writer(f);w.writerow(header);w.writerows(table)
    (out/'failures.json').write_text(json.dumps(failures,indent=2))
report=['# Standalone engine benchmark results','','Milliseconds; lower is better. Median of per-run medians. Query timings are per batch of 1,000 queries. Whole-frame intervals include CPU/GPU synchronization and pacing; they are not GPU timestamps.','','| Workload | Population | Tessera ms | Unity ms | Unity / Tessera |','|---|---:|---:|---:|---:|']
for case in cases:
 for n in a.counts:
  m={e:[r[6] for r in summaries if r[0]==e and r[1]==case and r[2]==n] for e in a.engines};v={e:statistics.median(t) if len(t)==a.repeats else None for e,t in m.items()};fmt=lambda e:f'{v[e]:.4f}' if v.get(e) is not None else 'incomplete'
  ratio=f'{v["unity"]/v["tessera"]:.2f}' if all(v.get(e) for e in ['unity','tessera']) and not ('characters' in case or case in ['scene-empty','scene-scripts']) else '—'
  report.append(f'| {case} | {n} | {fmt("tessera")} | {fmt("unity")} | {ratio} |')
report+=['','Read ../../README.md for scope and interpretation. Rendering uses different native pipelines and is not an equal-image-quality ranking. Scene-empty/scripts are native traversal versus explicit C# calls and are not ranked. CCD and character results require behavior checks.','','## Failures','',json.dumps(failures,indent=2)]
(out/'report.md').write_text('\n'.join(report)+'\n');print('Completed: '+str(out),flush=True)
