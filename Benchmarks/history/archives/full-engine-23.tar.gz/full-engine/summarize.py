#!/usr/bin/env python3
"""Aggregate measured workloads without inventing a universal engine score."""
from pathlib import Path
import csv,json,statistics,time
R=Path(__file__).resolve().parent
runs={};sources=[]
for folder in sorted((R/'results').iterdir()):
 if not (folder/'summary.csv').exists() or (folder/'EXCLUDED.md').exists():continue
 env=json.loads((folder/'environment.json').read_text());args=env['arguments']
 if (args['samples']<100 and not(args.get('scenarios') and all(c.endswith('-cold') for c in args['scenarios']) and args['repeats']>=3)) or args.get('screenshots'):continue
 sources.append(folder)
 grouped={}
 for x in csv.DictReader((folder/'summary.csv').open()):grouped.setdefault((x['scenario'],int(x['count']),x['engine']),[]).append(x)
 for key,rows in grouped.items():
  case,n,engine=key
  if case.startswith('render-') and (args.get('width',1280),args.get('height',720))!=(1280,720):key=(case+f'@{args["width"]}x{args["height"]}',n,engine)
  if case.startswith('model-') and not case.startswith('model-object-'):
   key=('model-algorithm-'+case[6:] if engine=='tessera' else 'model-object-'+case[6:],n,engine)
  # Keep the newest independently complete set for this workload/engine/population.
  if len(rows)==args['repeats']:runs[key]={'folder':folder.name,'rows':rows,'samples':args['samples'],'repeats':args['repeats']}
def med(key,metric='median_ms'):
 v=runs.get(key);return statistics.median(float(x[metric]) for x in v['rows']) if v else None
def fmt(v):return f'{v:.4f}' if v is not None else '—'
lines=['# Tessera performance comparison', '',f'Updated {time.strftime("%Y-%m-%d %H:%M:%S %Z")}. Performance measurements only.','', 'Builds: Tessera Beef Release/native -O3 (ThinLTO unavailable); Unity 6000.3.27f1 LTS, nondevelopment Mono standalone, Vulkan. Hardware: see per-run environment.json.','', 'Results are medians of per-process medians, in milliseconds. Query samples contain 1,000 queries. Tail columns are the median of each process’s p95. Native rendering differs in image quality; these intervals are not GPU-only times. Missing values mean no complete measurement, not zero.','']
groups=[('Physics',lambda x:x.startswith('physics-')),('Rendering',lambda x:x.startswith('render-') and 'skinning' not in x),('Skinned meshes',lambda x:'skinning' in x),('AI',lambda x:x.startswith('ai-')),('Scene and other subsystems',lambda x:not(x.startswith('physics-')or x.startswith('render-')or x.startswith('ai-')))]
for title,predicate in groups:
 cases=sorted({(k[0],k[1]) for k in runs if predicate(k[0])})
 lines+=['## '+title,'','| Workload | Population / batch size | Tessera median ms | Unity median ms | Tessera p95 ms | Unity p95 ms |','|---|---:|---:|---:|---:|---:|']
 for case,n in cases:lines.append(f'| {case} | {n} | {fmt(med((case,n,"tessera")))} | {fmt(med((case,n,"unity")))} | {fmt(med((case,n,"tessera"),"p95_ms"))} | {fmt(med((case,n,"unity"),"p95_ms"))} |')
 if not cases:lines+=['','Pending.']
 lines+=['']
lines+=['## Interpretation','','Compare the same row, then check its workload definition, correctness observations and memory. No overall engine score is calculated. Solver defaults differ; CCD timings require tunneling counts. Character motors and scene callback dispatch differ. Render-physics advances different numbers of simulation steps per rendered second. Rendering uses native pipeline settings and different sky/lighting/shadow/particle material implementations. Skinning forces all characters to deform every frame; Unity CPU and GPUBatched are separate builds. Navigation uses native grid search versus native polygon NavMesh search; path shapes and quality differ.','','## Sources','']+[f'- `{f.name}`: [environment](results/{f.name}/environment.json), [samples](results/{f.name}/samples.csv), [summary](results/{f.name}/summary.csv), [checks](results/{f.name}/checks.csv), [failures](results/{f.name}/failures.json)' for f in sources]
(R/'COMPARISON.md').write_text('\n'.join(lines)+'\n')
# Standalone scientific figures for the initial comparable workload groups.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
for title,cases,name in [('Physics at 1,000 objects (native solver defaults)',['physics-free','physics-pile','physics-mixed-shapes','physics-mesh'],'physics-1000.png'),('Native rendering at 1,000 objects (different image quality)',['render-shared','render-moving','render-culling','render-shadows','render-spheres','render-lights'],'rendering-1000.png')]:
 fig,ax=plt.subplots(figsize=(10,4.8));positions=list(range(len(cases)))
 for engine,offset,color in [('tessera',-.2,'#257b9c'),('unity',.2,'#d18a2d')]:
  vals=[med((c,1000,engine)) for c in cases]
  if any(v is None for v in vals):continue
  ax.barh([p+offset for p in positions],vals,height=.36,label=engine.capitalize(),color=color)
 ax.set_yticks(positions,[c.split('-',1)[1] for c in cases]);ax.invert_yaxis();ax.set_xlabel('Milliseconds (median of process medians; lower is better)');ax.set_title(title);ax.legend();ax.grid(axis='x',alpha=.2);fig.tight_layout();fig.savefig(R/name,dpi=160);plt.close(fig)
print('Updated COMPARISON.md and figures')
