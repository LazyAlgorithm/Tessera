#!/usr/bin/env python3
"""Refresh the repository and Desktop inventory using available result files."""
from pathlib import Path
import csv,json,statistics,time
R=Path(__file__).resolve().parent;E=R.parents[1]
lines=['# Tessera engine testing — live inventory','',f'Updated: {time.strftime("%Y-%m-%d %H:%M:%S %Z")}','','Status: expanded feature testing in progress. Available measurements below are provisional until the suite completes.','',f'Repository: {R}', '', 'Unity: 6000.3.27f1 LTS Linux x86_64 installed. Standalone nondevelopment Mono/Vulkan player. Tessera: Beef Release + native -O3.','', '## Feature checklist','','Performance tests only, per request. No functional regression suite is being run. Small validation checks only verify that timed work really happened.','', '| Feature | Performance status | Performance coverage | Unity comparison |','|---|---|---|---|']
functional={}
completed_scenarios=set()
for f in (R/'results').glob('*/summary.csv'):
 for row in csv.DictReader(f.open()):completed_scenarios.add(row['scenario'])
for f in sorted((R/'functional').glob('*/results.json')):
 for row in json.loads(f.read_text()):functional[row['name']]=row
mapping={'GpuSkinning':('GPU/CPU skinned-mesh crowd benchmark planned','Matching generated rig/mesh planned'),'Modeling':('Topology/primitive/mesh edit operations planned','Unity Mesh API where equivalent; editor tools separate'),'Animator':('Track interpolation added; full rig planned','Rig comparison planned'),'AnimationLayers':('Layer blending planned','Animator comparison planned'),'Scenes':('Empty/scripts/transforms/hierarchy/churn; save/load','Available; dispatch differences flagged'),'ShapeQueries':('8 query cases, 1,000 queries/sample','Available'),'CharacterController':('Flat/step capsule motors','Behavior differs; not ranked'),'Joints':('Constraint workload planned','Rigidbody joints planned'),'Audio':('Playback/mixing workload planned','AudioSource equivalent planned'),'Navigation':('Bake/pathfinding workload planned','NavMesh package if available'),'Network':('Native packet codec added; transport planned','No built-in matching transport; explicitly identify package'),'Textures':('Texture workload planned','Texture upload/decode planned'),'Material':('Shared/unique materials','Available native pipeline comparison'),'Lighting':('16 point lights; directional shadows','Available native pipeline comparison'),'Culling':('90% behind-camera population','Available'),'Foliage':('Instancing workload planned','Mesh instancing equivalent'),'PostProcessing':('Effect workload planned','Pipeline-specific comparison'),'Terrain':('Mesh collision; terrain generation planned','Mesh collision available'),'AsyncLoading':('Asset loading workload planned','Loading equivalents planned'),'PhysicsPrediction':('Network prediction planned','Requires matched implementation')}
for f in sorted((E/'Tests').iterdir()):
 if not f.is_dir() or f.name.startswith('.'):continue
 info=functional.get(f.name);status='Pending performance measurement'
 prefixes={'ShapeQueries':'physics-','Scenes':'scene-','CharacterController':'physics-characters','Culling':'render-culling','Material':'render-materials','Lighting':'render-lights','GpuSkinning':'render-skinning','Animator':'scene-animation','Audio':'audio-','Navigation':'ai-nav','Modeling':'model-','UIDocuments':'ui-'}
 if f.name in prefixes and any(x.startswith(prefixes[f.name]) for x in completed_scenarios):status='Measurements available / expanding'
 perf,unity=mapping.get(f.name,('Feature-specific test planned','Assess equivalent API/package'))
 lines.append(f'| {f.name} | {status} | {perf} | {unity} |')
lines+=['','## Available standalone timing results','','Median of completed process medians, in milliseconds; lower is better. Partial runs are labeled by repetition count. Query values are per 1,000-query batch, not individual query. Render intervals are native whole-frame measurements, not equal-quality GPU comparisons.','', '| Workload | Objects | Tessera ms (runs) | Unity ms (runs) |','|---|---:|---:|---:|']
values={}
for d in sorted((R/'results').glob('*')):
 if not (d/'summary.csv').exists() or (d/'EXCLUDED.md').exists():continue
 # Exclude short validation runs from performance summary.
 env=json.loads((d/'environment.json').read_text());args=env['arguments']
 if args['samples']<100 and not(args.get('scenarios') and all(c.endswith('-cold') for c in args['scenarios']) and args['repeats']>=3):continue
 for row in csv.DictReader((d/'summary.csv').open()):
  case=row['scenario']
  if case.startswith('render-') and (args.get('width',1280),args.get('height',720))!=(1280,720):case+=f'@{args["width"]}x{args["height"]}'
  if case.startswith('model-') and not case.startswith('model-object-'):case=('model-algorithm-' if row['engine']=='tessera' else 'model-object-')+case[6:]
  key=(case,int(row['count']),row['engine']);v=values.setdefault(key,{'folder':d.name,'data':[]})
  if v['folder']!=d.name:v['folder']=d.name;v['data']=[]
  v['data'].append(float(row['median_ms']))
for scenario,n in sorted({(k[0],k[1]) for k in values}):
 def fmt(e):
  v=values.get((scenario,n,e));return f'{statistics.median(v["data"]):.4f} ({len(v["data"])})' if v else 'Pending / no equivalent'
 lines.append(f'| {scenario} | {n} | {fmt("tessera")} | {fmt("unity")} |')
lines+=['','## Result locations','']+[f'- {d.name}: {d}/report.md' for d in sorted((R/'results').glob('*')) if (d/'environment.json').exists()]
lines+=['','## Scope and interpretation','','Every discovered feature area is listed above. Pending means it has not yet been performance-tested in this study. No absent result is a pass. No universal engine speed score is assigned. Full engine feature coverage is being expanded following the request to include GPU skinning, modeling and all comparable subsystems.','',f'Methodology and limitations: {R}/README.md']
text='\n'.join(lines)+'\n';(R/'TEST_STATUS.md').write_text(text);(Path.home()/'Desktop/Tessera Benchmark Results.md').write_text(text)
print('Updated Desktop/Tessera Benchmark Results.md')
