# Latest soft-body benchmark

[Results](/home/zerker24/BeefProjects/Tessera/Benchmarks/softbody/results-20261029-094437/REPORT.md)

Fixed Release engine snapshot; cloth, jelly, shells and ropes, with mesh/segment density, object count, collision, sleeping, solver and geometry checks.
