"""Post-sweep geometry checks with an otherwise equivalent diagnostic executable."""
from pathlib import Path
import subprocess,json,statistics as st,math,sys,hashlib
O=Path(sys.argv[1]);D=O/'snapshot/diagnostic';B=D/'build/Release_Linux64/Benchmark/Benchmark'
with (O/'diagnostic-build.log').open('w') as f:r=subprocess.run(['BeefBuild','-workspace='+str(D),'-config=Release'],stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0,'diagnostic build failed'
results=[]
def run(k,n,res,it,mode='cpu',warm=60,samples=120,rep=0,state='active'):
 name=f'diagnostic-{k}-{res}-{it}-{n}-{state}-{mode}-{rep}';args=[str(B),k,str(n),str(res),str(it),state,mode,str(warm),str(samples)];p=subprocess.run(args,capture_output=True,text=True,timeout=180);(O/(name+'.log')).write_text(p.stdout+p.stderr)
 checks={x.split(',')[1]:x.split(',',2)[2] for x in p.stdout.splitlines() if x.startswith('CHECK,')};vs=[list(map(float,x.split(',')[2:])) for x in p.stdout.splitlines() if x.startswith('SAMPLE,')];frames=[float(x.split(',')[2]) for x in p.stdout.splitlines() if x.startswith('FRAME,')]
 pct=lambda data,p:sorted(data)[math.ceil(len(data)*p)-1] if data else None
 valid=p.returncode==0 and checks.get('valid')=='True' and len(vs)==samples and (mode=='cpu' or len(frames)==samples)
 item={'name':name,'args':args,'exit':p.returncode,'finite_valid':valid,'checks':checks,'cpu_median_ms':st.median(x[3] for x in vs) if vs else None,'cpu_p95_ms':pct([x[3] for x in vs],.95),'frame_median_ms':st.median(frames) if frames else None,'frame_p95_ms':pct(frames,.95),'cpu_max_ms':max((x[3] for x in vs),default=None),'frame_max_ms':max(frames,default=None)}
 results.append(item);(O/'diagnostics.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'runs':results},indent=2));print('DIAGNOSTIC',name,valid,checks,flush=True);return item
for case,res,n in [('jelly',4,10),('jelly',8,10),('jelly',16,1),('jelly',16,10),('jelly-ball',8,10),('jelly-ball',16,10)]:run(case,n,res,5)
for res in [16,32,64]:run('rope-wrap',10,res,8)
for case in ['shell-impacts','shell-surface','shell-convex']:run(case,11,8,5,mode='render',warm=0,samples=180)
for n in [25,50,75,100]:
 for rep in range(3):run('shell-surface',n,8,5,mode='render',samples=180,rep=rep)
# The actual built-in sphere retains its poles: include it alongside the evenly meshed sphere sweep.
measured=[]
for n in [1,10,25,50,100,250]:
 a=run('jelly-builtin',n,1,5)
 if not a['finite_valid']:break
 measured.append(a)
 if a['cpu_p95_ms']>12:break
selected={1}
for budget in [4,10]:
 below=[a for a in measured if a['cpu_p95_ms']<=budget];above=[a for a in measured if a['cpu_p95_ms']>budget]
 if below:selected.add(int(below[-1]['args'][2]))
 if above and above[0]['cpu_p95_ms']<=30:selected.add(int(above[0]['args'][2]))
for n in sorted(selected):
 for rep in range(3):
  a=run('jelly-builtin',n,1,5,mode='render',samples=180,rep=rep)
  if not a['finite_valid']:break
for k in ['cloth','jelly','shell-impacts','shell-surface','rope','rope-load']:
 res=16 if k=='cloth' else 32 if k.startswith('rope') else 8;it=8 if k.startswith('rope') else 5
 for rep in range(3):run(k,100,res,it,mode='render',samples=180,rep=rep,state='rest')
print('DIAGNOSTICS COMPLETE',len(results),flush=True)
