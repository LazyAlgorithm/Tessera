"""Additional safe-density probes, refined practical counts, and screenshot checks after main sweeps."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
prefix=(root/'run.py').read_text().split("run('cloth',0,8,5)")[0]
exec(compile(prefix,str(root/'run.py'),'exec'))
manifest=json.loads((O/'manifest.json').read_text());assert manifest.get('finished'),'Main sweep did not finish';rows=list(csv.DictReader((O/'processes.csv').open()));aggregate=list(csv.DictReader((O/'summary.csv').open()))
# These are stability probes, not a solver-quality recommendation.
for it in [12,24]:
 for mode in ['cpu','render']:run('cloth',1,32,it,mode=mode)
# Refine the 4 ms rendered budget at common practical resolutions.
refinements=[('cloth',8,5),('cloth',16,5),('cloth-contact',16,5),('jelly',8,5),('jelly-ball',8,5),('jelly-contact',8,5),('shell-impacts',8,5),('shell-surface',8,5),('shell-convex',8,5),('rope',32,8),('rope-load',32,8),('rope-wrap',32,8)]
for k,res,it in [('rope',64,8),('rope-load',64,8),('rope-wrap',64,8)]:refinements.append((k,res,it))
for k,res,it in refinements:
 for step in range(2):
  points=[r for r in aggregate if r['case']==k and int(float(r['resolution']))==res and int(float(r['iterations']))==it and r['mode']=='render' and r['state']=='active' and str(r['profile'])=='False']
  below=[r for r in points if float(r['frame_p95_ms'])<=4];above=[r for r in points if float(r['frame_p95_ms'])>4]
  if not below or not above:break
  lo=max(int(float(r['count'])) for r in below);higher=[int(float(r['count'])) for r in above if int(float(r['count']))>lo]
  if not higher:break
  hi=min(higher)
  if hi-lo<=max(2,lo*.15):break
  count=(lo+hi)//2
  if run(k,count,res,it,mode='render') is None:break
# Visual smoke checks are separate, untimed and not included in capacity statistics.
for k,res,it in [('cloth',8,5),('jelly',8,5),('shell-impacts',8,5),('rope-wrap',32,8)]:
 args=[str(B),k,'10',str(res),str(it),'active','render','60','10','',str(O/(k+'.png'))]
 p=subprocess.run(args,capture_output=True,text=True,timeout=90);(O/(k+'-screenshot.log')).write_text(p.stdout+p.stderr)
manifest['finished']=datetime.datetime.now().isoformat();save();print('EXTRAS COMPLETE',len(manifest['jobs']),flush=True)
