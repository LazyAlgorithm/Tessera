"""Wait for the main sequential sweep, then run supplementary checks without competing with it."""
from pathlib import Path
import os,time,sys,subprocess,shutil
O=Path(sys.argv[1]).resolve();root=Path(__file__).resolve().parent
while True:
 running=False
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:a=(p/'cmdline').read_bytes().split(b'\0')
  except OSError:continue
  if len(a)>1 and a[0].endswith(b'python3') and a[1]==b'Benchmarks/softbody/resume.py':running=True
 if not running:break
 time.sleep(1)
for step in ['extra.py','diagnostics.py','plot.py','report.py']:
 print('START',step,flush=True)
 with (O/(step+'.log')).open('w') as f:p=subprocess.run([sys.executable,str(root/step),str(O)],stdout=f,stderr=subprocess.STDOUT)
 print('FINISH',step,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for name in ['run.py','resume.py','extra.py','diagnostics.py','report.py','plot.py','finish.py','README.md']:shutil.copy(root/name,O/name)
(O/'COMPLETE').write_text('All sequential sweeps, additional probes and reports completed.\n')
