from pathlib import Path
import csv,sys,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(sys.argv[1]);rows=list(csv.DictReader((O/'summary.csv').open()));cases=list(dict.fromkeys(r['case'] for r in rows if r['state']=='active' and int(float(r['count']))>0 and r['profile']=='False'))
diag=json.loads((O/'diagnostics.json').read_text()) if (O/'diagnostics.json').exists() else {'runs':[]}
blocked={(d['args'][1],int(d['args'][3])) for d in diag['runs'] if d['args'][1].startswith('jelly') and (float(d['checks'].get('max_body_extent_m',0))>3 or float(d['checks'].get('max_edge_length_ratio',0))>5)}
fig,axes=plt.subplots(4,3,figsize=(15,15));axes=axes.ravel()
for ax,k in zip(axes,cases):
 for res in dict.fromkeys(r['resolution'] for r in rows if r['case']==k and r['state']=='active' and r['profile']=='False'):
  data=sorted([r for r in rows if r['case']==k and r['resolution']==res and r['state']=='active' and r['mode']=='render' and r['profile']=='False' and int(float(r['count']))>0 and int(float(r['iterations']))==(8 if k.startswith('rope') else 5)],key=lambda r:int(float(r['count'])))
  if (k,int(float(res))) in blocked:data=[]
  if data:ax.plot([int(float(r['count'])) for r in data],[float(r['frame_p95_ms']) for r in data],marker='o',label='resolution '+res)
 ax.axhline(4,color='green',ls='--',lw=1,label='4 ms working budget');ax.axhline(16.667,color='red',ls=':',lw=1,label='16.67 ms whole frame');ax.set_xscale('log');ax.set_yscale('log');ax.set_title(k);ax.set_xlabel('objects');ax.set_ylabel('rendered frame p95 (ms)');ax.grid(True,alpha=.2);ax.legend(fontsize=7)
for ax in axes[len(cases):]:ax.axis('off')
fig.suptitle('Tessera soft bodies and ropes — measured simple-scene frame cost\nRyzen 9 7900X / RTX 3070, 720p, no shadows/AA, one 60 Hz physics tick per frame',fontsize=14);fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(O/'capacity.png',dpi=160);fig.savefig(O/'capacity.svg');plt.close(fig)
