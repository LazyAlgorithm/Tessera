from pathlib import Path
import sys
prefix=(Path(__file__).parent/'run.py').read_text().split("run('cloth',0,8,5)")[0]
exec(compile(prefix,'run.py','exec'))
manifest=json.loads((O/'manifest.json').read_text());rows=list(csv.DictReader((O/'processes.csv').open()));aggregate=list(csv.DictReader((O/'summary.csv').open()))
for k in ['shell-impacts','shell-surface']:
 for n in [100,175]:run(k,n,4,5,mode='render',warm=60,samples=180)
manifest['finished']=datetime.datetime.now().isoformat();save()
# Extra shape/engagement validation on the diagnostic binary, after all timed sweeps have stopped.
source=(Path(__file__).parent/'diagnostics.py').read_text();function=source[source.index('def run('):source.index('for case,res,n in')]
B=O/'snapshot/diagnostic/build/Release_Linux64/Benchmark/Benchmark';results=json.loads((O/'diagnostics.json').read_text())['runs'];exec(compile(function,'diagnostics.py','exec'))
for it in [12,24]:run('cloth',1,32,it,warm=120,samples=240)
run('cloth',43,16,5,samples=180);run('jelly-contact',7,8,5,samples=180);run('jelly-contact',1,16,5,samples=180);run('rope-wrap',137,32,8,samples=180)
print('POST VALIDATION COMPLETE',flush=True)
