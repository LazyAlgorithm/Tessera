# Tessera Profiler report

Frames 0 to 119 (120 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 8.110 ms | 8.085 ms | 8.373 ms | 8.791 ms | 8.973 ms | 7.826 ms |
| CPU main thread | 8.076 ms | 8.050 ms | 8.338 ms | 8.760 ms | 8.931 ms | 7.797 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 6.726 ms
- Other: 1.312 ms
- Scripts: 0.025 ms
- Rendering: 0.013 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- Networking: 0.000 ms
- AI: 0.000 ms

## Thread 'Softbody Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Step | Physics | 6.726 ms | 6.726 ms | 1 | 7.257 ms | 120/120 |
| SoftBody.LateUpdate() | Other | 1.299 ms | 1.299 ms | 100 | 1.739 ms | 120/120 |
| FixedUpdate (every component) | Scripts | 0.007 ms | 0.013 ms | 1 | 0.024 ms | 120/120 |
| OnFrame (every component) | Scripts | 0.007 ms | 0.013 ms | 1 | 0.017 ms | 120/120 |
| LateUpdate (every component) | Scripts | 0.006 ms | 1.308 ms | 1 | 1.750 ms | 120/120 |
| Update (every component) | Scripts | 0.005 ms | 0.011 ms | 1 | 0.021 ms | 120/120 |
| SoftBody.Update() | Other | 0.003 ms | 0.003 ms | 100 | 0.013 ms | 120/120 |
| Frame | Other | 0.003 ms | 8.075 ms | 1 | 8.931 ms | 120/120 |
| SoftBody.FixedUpdate() | Other | 0.003 ms | 0.003 ms | 100 | 0.007 ms | 120/120 |
| SoftBody.OnFrame() | Other | 0.003 ms | 0.003 ms | 100 | 0.006 ms | 120/120 |
| MeshRenderer.OnFrame() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.006 ms | 120/120 |
| MeshRenderer.LateUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.Update() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.FixedUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| Start | Scripts | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 120/120 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| WindZone.OnFrame() | Other | 0.000 ms | 0.000 ms | 1 | 0.001 ms | 120/120 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| WindZone.FixedUpdate() | Other | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| WindZone.Update() | Other | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| WindZone.LateUpdate() | Other | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 60: interval 8.973 ms, CPU 8.007 ms, GPU -

```
Frame  total 8.007 ms, self 0.003 ms
  Physics.Step  total 6.723 ms, self 6.723 ms
  LateUpdate (every component)  total 1.240 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 1.231 ms, self 1.231 ms, 100 calls
```

### Frame 59: interval 8.057 ms, CPU 8.931 ms, GPU -

```
Frame  total 8.931 ms, self 0.004 ms
  Physics.Step  total 7.257 ms, self 7.257 ms
  LateUpdate (every component)  total 1.627 ms, self 0.007 ms
    SoftBody.LateUpdate()  total 1.616 ms, self 1.616 ms, 100 calls
```

### Frame 99: interval 8.791 ms, CPU 7.908 ms, GPU -

```
Frame  total 7.908 ms, self 0.003 ms
  Physics.Step  total 6.561 ms, self 6.561 ms
  LateUpdate (every component)  total 1.307 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 1.298 ms, self 1.298 ms, 100 calls
```

### Frame 98: interval 8.008 ms, CPU 8.760 ms, GPU -

```
Frame  total 8.760 ms, self 0.004 ms
  Physics.Step  total 6.963 ms, self 6.963 ms
  LateUpdate (every component)  total 1.750 ms, self 0.007 ms
    SoftBody.LateUpdate()  total 1.739 ms, self 1.739 ms, 100 calls
```

### Frame 23: interval 8.521 ms, CPU 8.135 ms, GPU -

```
Frame  total 8.134 ms, self 0.003 ms
  Physics.Step  total 6.725 ms, self 6.725 ms
  LateUpdate (every component)  total 1.369 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 1.359 ms, self 1.359 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
