using System;
using System.Collections;
using Tessera;
using Bgfx;
namespace SoftBench;
class Program
{
 public static int Main(String[] args)
 {
  if(args.Count<8)return 1;
  let app=scope Bench();app.Kind.Set(args[0]);app.N=SceneSerializer.ParseInt(args[1]);app.Res=SceneSerializer.ParseInt(args[2]);app.Iter=SceneSerializer.ParseInt(args[3]);app.Rest=args[4]=="rest";app.Headless=args[5]=="cpu";app.Warm=SceneSerializer.ParseInt(args[6]);app.Samples=SceneSerializer.ParseInt(args[7]);
  if(args.Count>8)app.Profile.Set(args[8]);
  app.Width=1280;app.Height=720;Gfx.ResetFlags=0;
  if(args.Count>9)return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera","--frames",scope $"{app.Warm+app.Samples+1}","--screenshot",args[9]));
  return app.Run(scope String[]("--engine-root","/home/zerker24/BeefProjects/Tessera"));
 }
}
class Bench : Application
{
 public String Kind=new .() ~ delete _;
 public String Profile=new .() ~ delete _;
 public int N,Res,Iter,Warm,Samples,Frame;
 public bool Rest;
 Scene scene=new .() ~ delete _;
 Mesh shape ~ delete _;
 RenderView view ~ delete _;
 Camera camera;
 List<SoftBody> softs=new .() ~ delete _;
 List<Rope> ropes=new .() ~ delete _;
 List<GameObject> movers=new .() ~ delete _;
 List<GameObject> shots=new .() ~ delete _;
 List<Vector3> shotBases=new .() ~ delete _;
 List<Vector3> bases=new .() ~ delete _;
 uint64 previous;
 bool valid=true;
	static Mesh Sheet(int cells, float size)
	{
		let mesh = new Mesh();
		for (int z <= cells)
		{
			for (int x <= cells)
				mesh.AddVertex(.((x / (float)cells - 0.5f) * size, 0, (z / (float)cells - 0.5f) * size), .Up, .White, .(x / (float)cells, z / (float)cells));
		}
		for (int z < cells)
		{
			for (int x < cells)
			{
				let a = (uint32)(z * (cells + 1) + x);
				mesh.AddTriangle(a, a + (uint32)cells + 1, a + 1);
				mesh.AddTriangle(a + 1, a + (uint32)cells + 1, a + (uint32)cells + 2);
			}
		}
		return mesh;
	}

	/// A level sheet pinned along its far edge (its last row, z = +size/2): the rest swings down and hangs from it.
	/// A box, half its size each way, each face cut into `cells` squares across (so it can dent and bend).
	static Mesh Box(Vector3 half, int cells)
	{
		let mesh = new Mesh();
		for (int face < 6)
		{
			let axis = face / 2;
			let sign = (face % 2 == 0) ? 1.0f : -1.0f;
			let start = (uint32)mesh.Vertices.Count;
			for (int j <= cells)
			{
				for (int i <= cells)
				{
					float[3] p = default;
					p[axis] = sign;
					p[(axis + 1) % 3] = i / (float)cells * 2 - 1;
					p[(axis + 2) % 3] = j / (float)cells * 2 - 1;
					float[3] n = default;
					n[axis] = sign;
					mesh.AddVertex(.(p[0] * half.x, p[1] * half.y, p[2] * half.z), .(n[0], n[1], n[2]), .White, .(i / (float)cells, j / (float)cells));
				}
			}
			for (int j < cells)
			{
				for (int i < cells)
				{
					let a = start + (uint32)(j * (cells + 1) + i);
					let c = a + (uint32)cells + 1;
					// Wound to face outward on either side.
					if (sign > 0)
					{
						mesh.AddTriangle(a, a + 1, c);
						mesh.AddTriangle(a + 1, c + 1, c);
					}
					else
					{
						mesh.AddTriangle(a, c, a + 1);
						mesh.AddTriangle(a + 1, c, c + 1);
					}
				}
			}
		}
		return mesh;
	}


 protected override bool LoadsPlayerQuality=>false;
 GameObject Crate(Vector3 at,float mass)
 {
  let o=scene.CreateGameObject("Load");o.Transform.Position=at;o.AddComponent<BoxCollider>().size=.(0.6f,0.6f,0.6f);o.AddComponent<Rigidbody>().mass=mass;return o;
 }
 protected override bool OnInit()
 {
  Audio.NoDevice=true;RenderView.Antialias=false;RenderView.RenderScale=1;RenderView.MaxSceneHeight=0;Gfx.SetVsync(false);
  Time.DeltaTime=1/60.0f;Time.UnscaledDeltaTime=1/60.0f;
  Scene.Active=scene;
  let setup=SDL.SDL_GetTicksNS();
  let floor=scene.CreateGameObject("Floor");floor.Transform.Position=.(0,-0.5f,0);floor.AddComponent<BoxCollider>().size=.(2048,1,2048);
  if(!Rest && (Kind.StartsWith("cloth") || Kind=="rope")) {let wind=scene.CreateGameObject("Wind").AddComponent<WindZone>();wind.strength=3;wind.gusts=0.5f;wind.Transform.Rotation=Quaternion.LookRotation(.(1,0,0),.Up);}
  if(!Kind.StartsWith("rope"))shape=Kind.StartsWith("cloth") ? Sheet(Res,2) : Box(.(0.5f,0.5f,0.5f),Res);
  if(Kind=="jelly-ball")for(int v<shape.Vertices.Count){shape.Vertices[v].position=shape.Vertices[v].position.Normalized*0.5f;shape.Vertices[v].normal=shape.Vertices[v].position.Normalized;}
  for(int i<N)
  {
   let spacing=Kind=="jelly-contact" ? 1.0f : 4.0f;
   let cols=(int)Math.Ceiling(Math.Sqrt((double)Math.Max(N,1)));
   let at=Vector3((i%cols-(cols-1)*0.5f)*spacing,0,(i/cols-(cols-1)*0.5f)*spacing);
   if(Kind.StartsWith("rope"))
   {
    let hook=scene.CreateGameObject("Hook");hook.Transform.Position=at+Vector3(0,4,0);
    let rope=hook.AddComponent<Rope>();rope.length=3;rope.segments=(int32)Res;rope.iterations=(int32)Iter;rope.windDrag=Rest ? 0 : 1;
    if(Kind=="rope-load" || Kind=="rope-wrap")
    {
     let load=Crate(at+Vector3(0,1,0),10);rope.endAttachedTo=load.Transform;rope.endOffset=.(0,0.3f,0);
     if(!Rest){movers.Add(hook);bases.Add(hook.Transform.Position);}
     if(Kind=="rope-wrap")
     {
      let beam=scene.CreateGameObject("Beam");beam.Transform.Position=at+Vector3(0,2.5f,0);beam.AddComponent<BoxCollider>().size=.(0.4f,0.3f,2);
      hook.Transform.Position=at+Vector3(-0.8f,1.5f,0);hook.AddComponent<BoxCollider>().size=.(0.6f,0.6f,0.6f);hook.AddComponent<Rigidbody>().mass=13;load.Transform.Position=at+Vector3(0.8f,1.5f,0);beam.Transform.Position=at+Vector3(0,4,0);beam.GetComponent<BoxCollider>().size=.(0.3f,0.3f,2);rope.startOffset=.(0,0.3f,0);rope.wrapsAround=true;if(!Rest)bases[bases.Count-1]=hook.Transform.Position;
     }
    }
    ropes.Add(rope);
   }
   else
   {
    let o=scene.CreateGameObject("Soft");o.Transform.Position=at+Vector3(0,Kind.StartsWith("cloth") ? 3.0f : 0.6f,0);let renderer=o.AddComponent<MeshRenderer>();if(Kind=="jelly-builtin")renderer.mesh.Set("builtin:sphere");else renderer.RuntimeMesh=shape;
    let soft=o.AddComponent<SoftBody>();soft.iterations=(int32)Iter;soft.windDrag=Rest ? 0 : 1;
    if(Kind.StartsWith("cloth")){soft.pins.Set(scope $"{Res*(Res+1)}-{(Res+1)*(Res+1)-1}");}
    else if(Kind.StartsWith("shell"))
    {
     soft.kind=.Shell;soft.dentMode=Kind=="shell-surface" ? .FromSurface : .FromImpacts;soft.mass=100;
     if(Kind=="shell-convex")o.AddComponent<ConvexCollider>();else o.AddComponent<BoxCollider>().size=Kind=="shell-surface" ? Vector3(0.7f,0.7f,0.7f) : Vector3(1,1,1);o.AddComponent<Rigidbody>().mass=100;
    }
    else {soft.kind=.Jelly;if(Kind=="jelly-ball" || Kind=="jelly-builtin")soft.pressure=300;}
    softs.Add(soft);
    if(!Rest && !Kind.StartsWith("cloth")){movers.Add(o);bases.Add(o.Transform.Position);}
    if(Kind=="cloth-contact" || Kind.StartsWith("shell"))
    {
     let hit=scene.CreateGameObject("Pusher");hit.Transform.Position=at+Vector3(0,Kind=="cloth-contact" ? 2.4f : 0.6f,1);
     hit.AddComponent<SphereCollider>().radius=0.35f;let rb=hit.AddComponent<Rigidbody>();rb.mass=10;rb.isKinematic=(Kind!="shell-impacts" && Kind!="shell-convex");if(!Rest && (Kind=="shell-impacts" || Kind=="shell-convex")){shots.Add(hit);shotBases.Add(hit.Transform.Position);}
     if(!Rest && (Kind!="shell-impacts" && Kind!="shell-convex")){movers.Add(hit);bases.Add(hit.Transform.Position);}
    }
   }
  }
  scene.StartPlay();scene.FixedUpdate();scene.Update();
  if(Kind=="rope-wrap")for(let rope in ropes){let at=rope.Transform.Position;Vector3[4] path=.(at,at+Vector3(0.6f,2.7f,0),at+Vector3(1.0f,2.7f,0),at+Vector3(1.6f,0.3f,0));rope.LayAlong(path);}
  int vertices=0,renderVertices=0;for(let s in softs){if(!s.HasBody)return false;vertices+=s.SimulatedVertexCount;renderVertices+=s.GetComponent<MeshRenderer>().RuntimeMesh.Vertices.Count;}for(let r in ropes){if(!r.HasBody)return false;vertices+=r.Points.Count;renderVertices+=r.GetComponent<MeshRenderer>().RuntimeMesh.Vertices.Count;}
  Console.WriteLine(scope $"CHECK,tick_hz,{Time.TickRate}");Console.WriteLine(scope $"CHECK,physics_workers,3");
  Console.WriteLine(scope $"CHECK,sim_vertices,{vertices}");Console.WriteLine(scope $"CHECK,render_vertices,{renderVertices}");Console.WriteLine(scope $"CHECK,setup_ms,{(double)(SDL.SDL_GetTicksNS()-setup)/1e6}");
  if(Rest)for(int tick<900){scene.FixedUpdate();scene.Update();if(!Headless)bgfx.frame(0);}
  if(!Headless)
  {
   camera=scene.CreateGameObject("Camera").AddComponent<Camera>();let distance=(float)Math.Max(12,Math.Sqrt((double)Math.Max(N,1))*4);camera.Transform.Position=.(0,distance*0.7f,-distance);camera.Transform.Rotation=Quaternion.LookRotation(Vector3(0,1.5f,0)-camera.Transform.Position,.Up);camera.farClip=2000;
   let sun=scene.CreateGameObject("Sun").AddComponent<Light>();sun.Transform.Rotation=Quaternion.Euler(45,-45,0);view=new .(10);view.ToBackbuffer=true;view.DrawShadows=false;
  }
  if(Headless)
  {
   if(!Profile.IsEmpty){Profiler.NameThread("Softbody Benchmark");Profiler.Local.Clear();Profiler.Local.limit=(int32)Samples;Profiler.ComponentSamples=true;}
   for(int i<Warm+Samples){Frame=i;if(!Profile.IsEmpty && i>=Warm){Profiler.Enabled=true;Time.FrameCount=i-Warm;Profiler.BeginFrame();}Tick();if(!Profile.IsEmpty && i>=Warm)Profiler.EndFrame();}
   if(!Profile.IsEmpty){Profiler.Enabled=false;Profiler.Local.Save(Profile);Profiler.Local.SaveReport(scope $"{Profile}.md");}
   Finish();Running=false;
  }
  previous=SDL.SDL_GetTicksNS();return true;
 }
 void Tick()
 {
  let a=SDL.SDL_GetTicksNS();
  for(int i<movers.Count){var p=bases[i];p.y+=0.15f*Math.Sin(Frame*0.12f);p.z+=0.4f*Math.Sin(Frame*0.2f);movers[i].Transform.Position=p;}
  if(Frame%45==0)for(int i<shots.Count){let o=shots[i];o.Transform.Position=shotBases[i];o.GetComponent<Rigidbody>().Velocity=.(0,0,-10);}
  let b=SDL.SDL_GetTicksNS();scene.FixedUpdate();let c=SDL.SDL_GetTicksNS();scene.Update();let d=SDL.SDL_GetTicksNS();
  if(scene.Physics.LastStepError!=0)valid=false;
  if(Frame>=Warm)Console.WriteLine(scope $"SAMPLE,{Frame-Warm},{(double)(b-a)/1e6},{(double)(c-b)/1e6},{(double)(d-c)/1e6},{(double)(d-a)/1e6}");
 }
 void Finish()
 {
  int wrapped=0;float pull=0;for(let r in ropes){if(r.IsWrapped)wrapped++;pull=Math.Max(pull,r.Pull);}
  Console.WriteLine(scope $"CHECK,wrapped_ropes,{wrapped}");Console.WriteLine(scope $"CHECK,max_rope_pull_n,{pull}");
  float maxExtent=0,maxEdgeRatio=0;
  for(let body in softs)
  {
   var lo=Vector3(float.MaxValue,float.MaxValue,float.MaxValue);var hi=Vector3(float.MinValue,float.MinValue,float.MinValue);
   for(let p in body.Positions){lo.x=Math.Min(lo.x,p.x);lo.y=Math.Min(lo.y,p.y);lo.z=Math.Min(lo.z,p.z);hi.x=Math.Max(hi.x,p.x);hi.y=Math.Max(hi.y,p.y);hi.z=Math.Max(hi.z,p.z);}
   let span=hi-lo;maxExtent=Math.Max(maxExtent,Math.Max(span.x,Math.Max(span.y,span.z)));
   for(int t=0;t+2<body.[Friend]mTriangles.Count;t+=3)for(int edge<3)
   {
    let a=body.[Friend]mTriangles[t+edge],b=body.[Friend]mTriangles[t+(edge+1)%3];let rest=(body.[Friend]mRest[a]-body.[Friend]mRest[b]).Length;
    if(rest>0.00001f)maxEdgeRatio=Math.Max(maxEdgeRatio,(body.Positions[a]-body.Positions[b]).Length/rest);
   }
  }
  Console.WriteLine(scope $"CHECK,max_body_extent_m,{maxExtent}");Console.WriteLine(scope $"CHECK,max_edge_length_ratio,{maxEdgeRatio}");
  int sleeping=0,contacts=0;double checksum=0;float dent=0;let touched=scope List<uint32>();
  for(let s in softs){s.TouchingBodies(touched);contacts+=touched.Count;if(s.IsSleeping)sleeping++;if(s.kind==.Shell)dent=Math.Max(dent,s.DeepestDent());for(let p in s.Positions){if(!p.x.IsFinite || !p.y.IsFinite || !p.z.IsFinite)valid=false;checksum+=p.y;}}
  for(let r in ropes)for(let p in r.Points){if(!p.x.IsFinite || !p.y.IsFinite || !p.z.IsFinite)valid=false;checksum+=p.y;}
  if(!Headless){let stats=bgfx.get_stats();if(stats!=null)Console.WriteLine(scope $"CHECK,draws,{stats.numDraw}");}
  Console.WriteLine(scope $"CHECK,contact_bodies,{contacts}");
  Console.WriteLine(scope $"CHECK,deepest_dent,{dent}");
  Console.WriteLine(scope $"CHECK,sleeping_softs,{sleeping}");Console.WriteLine(scope $"CHECK,checksum,{checksum}");Console.WriteLine(scope $"CHECK,valid,{valid}");
 }
 protected override void OnUpdate(){if(!Headless && Frame<Warm+Samples)Tick();}
 protected override void OnRender()
 {
  if(Frame>=Warm+Samples){Finish();Running=false;return;}
  let now=SDL.SDL_GetTicksNS();if(Frame>=Warm && Frame>0)Console.WriteLine(scope $"FRAME,{Frame-Warm},{(double)(now-previous)/1e6}");previous=now;
  Frame++;
  view.Resize(Width,Height);view.Render(scene,camera.GetCameraData((float)Width/Height));
 }
 protected override void OnShutdown(){scene.StopPlay();Audio.Shutdown();}
}
