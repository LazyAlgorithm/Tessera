# Tessera Profiler report

Frames 0 to 119 (120 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 44.121 ms | 45.207 ms | 47.758 ms | 48.274 ms | 48.301 ms | 35.032 ms |
| CPU main thread | 44.160 ms | 45.263 ms | 47.760 ms | 48.250 ms | 48.273 ms | 35.007 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 41.983 ms
- Other: 2.138 ms
- Scripts: 0.025 ms
- Rendering: 0.013 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- AI: 0.000 ms
- Networking: 0.000 ms

## Thread 'Softbody Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Step | Physics | 41.983 ms | 41.983 ms | 1 | 46.051 ms | 120/120 |
| SoftBody.LateUpdate() | Other | 2.122 ms | 2.122 ms | 100 | 2.236 ms | 120/120 |
| OnFrame (every component) | Scripts | 0.008 ms | 0.014 ms | 1 | 0.023 ms | 120/120 |
| Frame | Other | 0.007 ms | 44.160 ms | 1 | 48.273 ms | 120/120 |
| LateUpdate (every component) | Scripts | 0.006 ms | 2.131 ms | 1 | 2.246 ms | 120/120 |
| FixedUpdate (every component) | Scripts | 0.006 ms | 0.012 ms | 1 | 0.023 ms | 120/120 |
| Update (every component) | Scripts | 0.005 ms | 0.011 ms | 1 | 0.014 ms | 120/120 |
| SoftBody.OnFrame() | Other | 0.003 ms | 0.003 ms | 100 | 0.007 ms | 120/120 |
| SoftBody.FixedUpdate() | Other | 0.003 ms | 0.003 ms | 100 | 0.007 ms | 120/120 |
| MeshRenderer.OnFrame() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| SoftBody.Update() | Other | 0.003 ms | 0.003 ms | 100 | 0.006 ms | 120/120 |
| MeshRenderer.Update() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.LateUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.003 ms | 120/120 |
| MeshRenderer.FixedUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.001 ms | 120/120 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.001 ms | 120/120 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.001 ms | 120/120 |
| Start | Scripts | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 120/120 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 118: interval 48.301 ms, CPU 47.622 ms, GPU -

```
Frame  total 47.622 ms, self 0.009 ms
  Physics.Step  total 45.441 ms, self 45.441 ms
  LateUpdate (every component)  total 2.132 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 2.123 ms, self 2.123 ms, 100 calls
```

### Frame 79: interval 48.274 ms, CPU 47.881 ms, GPU -

```
Frame  total 47.881 ms, self 0.006 ms
  Physics.Step  total 45.608 ms, self 45.608 ms
  LateUpdate (every component)  total 2.230 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 2.220 ms, self 2.220 ms, 100 calls
```

### Frame 117: interval 47.111 ms, CPU 48.273 ms, GPU -

```
Frame  total 48.273 ms, self 0.009 ms
  Physics.Step  total 46.051 ms, self 46.051 ms
  LateUpdate (every component)  total 2.164 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 2.154 ms, self 2.154 ms, 100 calls
```

### Frame 78: interval 46.968 ms, CPU 48.250 ms, GPU -

```
Frame  total 48.249 ms, self 0.007 ms
  Physics.Step  total 45.963 ms, self 45.963 ms
  LateUpdate (every component)  total 2.242 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 2.232 ms, self 2.232 ms, 100 calls
```

### Frame 33: interval 48.121 ms, CPU 45.181 ms, GPU -

```
Frame  total 45.181 ms, self 0.009 ms
  Physics.Step  total 43.004 ms, self 43.004 ms
  LateUpdate (every component)  total 2.128 ms, self 0.006 ms
    SoftBody.LateUpdate()  total 2.119 ms, self 2.119 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
