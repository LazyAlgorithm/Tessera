"""Resume saved sweep checkpoints with short CPU exploration and repeated rendered confirmation."""
from pathlib import Path
import sys
prefix=(Path(__file__).parent/'run.py').read_text().split("run('cloth',0,8,5)")[0]
exec(compile(prefix,'run.py','exec'))
manifest=json.loads((O/'manifest.json').read_text());rows=list(csv.DictReader((O/'processes.csv').open()));aggregate=list(csv.DictReader((O/'summary.csv').open()))
for r in rows+aggregate:
 for key in r:
  if key not in ['case','state','mode','profile']:r[key]=float(r[key])
def key(k,n,res,it,state,mode,profile):return (k,int(float(n)),int(float(res)),int(float(it)),state,mode,str(profile))
def rk(r):return key(*(r[x] for x in ['case','count','resolution','iterations','state','mode','profile']))
cache={rk(r):r for r in aggregate}
partial=[r for r in rows if rk(r) not in cache]
(O/'excluded-partial-processes.json').write_text(json.dumps(partial,indent=2));rows=[r for r in rows if rk(r) in cache]
partialnames={f'{r["case"]}-{int(r["resolution"])}-{int(r["iterations"])}-{int(r["count"])}-{r["state"]}-{r["mode"]}-{int(r["repeat"])}' for r in partial};manifest['jobs']=[j for j in manifest['jobs'] if j['name'] not in partialnames]
failed={key(j['args'][1],j['args'][2],j['args'][3],j['args'][4],j['args'][5],j['args'][6],j['name'].endswith('-profile')) for j in manifest['jobs'] if not j['valid']}
run_new=run
def run(k,n,res,it,state='active',mode='cpu',reps=3,warm=60,samples=180,profile=False):
 identity=key(k,n,res,it,state,mode,profile)
 if identity in cache:return cache[identity]
 if identity in failed:return None
 a=run_new(k,n,res,it,state=state,mode=mode,reps=reps,warm=warm,samples=samples,profile=profile)
 if a:cache[identity]=a
 else:failed.add(identity)
 return a
for k,res,it in configs:
 measured=[]
 for n in [1,10,25,50,100,250,500,1000,2000]:
  a=run(k,n,res,it,reps=1,warm=60,samples=120)
  if a is None:break
  measured.append(a)
  if a['total_p95_ms']>12:break
 selected={1}
 for budget in [4,10]:
  below=[x for x in measured if x['total_p95_ms']<=budget];above=[x for x in measured if x['total_p95_ms']>budget]
  if below:selected.add(int(below[-1]['count']))
  if above:selected.add(int(above[0]['count']))
 for n in sorted(selected):run(k,n,res,it,mode='render')
for k in ['cloth','jelly','shell-impacts','shell-surface','rope','rope-load']:
 res=16 if k=='cloth' else 32 if k.startswith('rope') else 8;it=8 if k.startswith('rope') else 5
 run(k,100,res,it,state='rest');run(k,100,res,it,state='rest',mode='render')
for k,res in [('cloth',16),('jelly',8),('rope-load',32)]:
 for it in [2,12,24]:run(k,100,res,it)
for k,res,it in [('cloth',16,5),('jelly-contact',8,5),('shell-convex',8,5),('rope-load',32,8)]:run(k,100,res,it,reps=1,samples=120,profile=True)
manifest['finished']=datetime.datetime.now().isoformat();save();print('COMPLETE',len(manifest['jobs']),flush=True)
