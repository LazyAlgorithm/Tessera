# Tessera Profiler report

Frames 0 to 119 (120 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 2.212 ms | 2.213 ms | 2.250 ms | 2.267 ms | 2.302 ms | 2.155 ms |
| CPU main thread | 2.150 ms | 2.152 ms | 2.184 ms | 2.205 ms | 2.218 ms | 2.095 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Other: 1.631 ms
- Physics: 0.457 ms
- Scripts: 0.048 ms
- Rendering: 0.013 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- Networking: 0.000 ms
- AI: 0.000 ms

## Thread 'Softbody Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Rope.LateUpdate() | Other | 1.617 ms | 1.617 ms | 100 | 1.644 ms | 120/120 |
| Physics.Step | Physics | 0.431 ms | 0.431 ms | 1 | 0.482 ms | 120/120 |
| OnFrame (every component) | Scripts | 0.013 ms | 0.026 ms | 1 | 0.033 ms | 120/120 |
| FixedUpdate (every component) | Scripts | 0.012 ms | 0.025 ms | 1 | 0.051 ms | 120/120 |
| LateUpdate (every component) | Scripts | 0.012 ms | 1.639 ms | 1 | 1.666 ms | 120/120 |
| Update (every component) | Scripts | 0.011 ms | 0.024 ms | 1 | 0.035 ms | 120/120 |
| Frame | Other | 0.004 ms | 2.149 ms | 1 | 2.218 ms | 120/120 |
| Rope.Update() | Other | 0.003 ms | 0.003 ms | 100 | 0.012 ms | 120/120 |
| BoxCollider.OnFrame() | Physics | 0.003 ms | 0.003 ms | 101 | 0.009 ms | 120/120 |
| Rope.OnFrame() | Other | 0.003 ms | 0.003 ms | 100 | 0.007 ms | 120/120 |
| BoxCollider.Update() | Physics | 0.003 ms | 0.003 ms | 101 | 0.004 ms | 120/120 |
| Rigidbody.FixedUpdate() | Physics | 0.003 ms | 0.003 ms | 100 | 0.009 ms | 120/120 |
| Rigidbody.LateUpdate() | Physics | 0.003 ms | 0.003 ms | 100 | 0.007 ms | 120/120 |
| BoxCollider.LateUpdate() | Physics | 0.003 ms | 0.003 ms | 101 | 0.004 ms | 120/120 |
| Rigidbody.Update() | Physics | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.LateUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.007 ms | 120/120 |
| MeshRenderer.OnFrame() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.Update() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| BoxCollider.FixedUpdate() | Physics | 0.003 ms | 0.003 ms | 101 | 0.003 ms | 120/120 |
| Rigidbody.OnFrame() | Physics | 0.003 ms | 0.003 ms | 100 | 0.003 ms | 120/120 |
| Rope.FixedUpdate() | Other | 0.003 ms | 0.003 ms | 100 | 0.005 ms | 120/120 |
| MeshRenderer.FixedUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.003 ms | 120/120 |
| Start | Scripts | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 120/120 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 1: interval 2.302 ms, CPU 2.150 ms, GPU -

```
Frame  total 2.150 ms, self 0.005 ms
  LateUpdate (every component)  total 1.638 ms, self 0.012 ms
    Rope.LateUpdate()  total 1.617 ms, self 1.617 ms, 100 calls
  Physics.Step  total 0.433 ms, self 0.433 ms
```

### Frame 98: interval 2.267 ms, CPU 2.138 ms, GPU -

```
Frame  total 2.138 ms, self 0.004 ms
  LateUpdate (every component)  total 1.638 ms, self 0.012 ms
    Rope.LateUpdate()  total 1.616 ms, self 1.616 ms, 100 calls
  Physics.Step  total 0.422 ms, self 0.422 ms
```

### Frame 93: interval 2.260 ms, CPU 2.164 ms, GPU -

```
Frame  total 2.164 ms, self 0.004 ms
  LateUpdate (every component)  total 1.636 ms, self 0.012 ms
    Rope.LateUpdate()  total 1.614 ms, self 1.614 ms, 100 calls
  Physics.Step  total 0.450 ms, self 0.450 ms
```

### Frame 56: interval 2.257 ms, CPU 2.162 ms, GPU -

```
Frame  total 2.161 ms, self 0.005 ms
  LateUpdate (every component)  total 1.635 ms, self 0.012 ms
    Rope.LateUpdate()  total 1.613 ms, self 1.613 ms, 100 calls
  Physics.Step  total 0.448 ms, self 0.448 ms
```

### Frame 6: interval 2.255 ms, CPU 2.150 ms, GPU -

```
Frame  total 2.150 ms, self 0.004 ms
  LateUpdate (every component)  total 1.647 ms, self 0.012 ms
    Rope.LateUpdate()  total 1.626 ms, self 1.626 ms, 100 calls
  Physics.Step  total 0.422 ms, self 0.422 ms
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
