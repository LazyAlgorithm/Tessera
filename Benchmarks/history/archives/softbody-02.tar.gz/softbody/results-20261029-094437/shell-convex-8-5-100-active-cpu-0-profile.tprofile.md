# Tessera Profiler report

Frames 0 to 119 (120 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 5.106 ms | 4.979 ms | 5.365 ms | 9.200 ms | 9.488 ms | 4.715 ms |
| CPU main thread | 5.006 ms | 4.882 ms | 5.268 ms | 9.091 ms | 9.394 ms | 4.623 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Physics: 2.661 ms
- Other: 2.266 ms
- Scripts: 0.067 ms
- Rendering: 0.013 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- Networking: 0.000 ms
- AI: 0.000 ms

## Thread 'Softbody Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Physics.Step | Physics | 2.610 ms | 2.610 ms | 1 | 3.112 ms | 120/120 |
| SoftBody.LateUpdate() | Other | 2.135 ms | 2.135 ms | 100 | 2.422 ms | 120/120 |
| SoftBody.FixedUpdate() | Other | 0.119 ms | 0.119 ms | 100 | 4.367 ms | 120/120 |
| OnFrame (every component) | Scripts | 0.018 ms | 0.037 ms | 1 | 0.065 ms | 120/120 |
| LateUpdate (every component) | Scripts | 0.017 ms | 2.167 ms | 1 | 2.459 ms | 120/120 |
| FixedUpdate (every component) | Scripts | 0.016 ms | 0.150 ms | 1 | 4.399 ms | 120/120 |
| Update (every component) | Scripts | 0.016 ms | 0.035 ms | 1 | 0.051 ms | 120/120 |
| Rigidbody.Update() | Physics | 0.006 ms | 0.006 ms | 200 | 0.009 ms | 120/120 |
| Rigidbody.OnFrame() | Physics | 0.006 ms | 0.006 ms | 200 | 0.010 ms | 120/120 |
| Rigidbody.LateUpdate() | Physics | 0.006 ms | 0.006 ms | 200 | 0.024 ms | 120/120 |
| Rigidbody.FixedUpdate() | Physics | 0.006 ms | 0.006 ms | 200 | 0.017 ms | 120/120 |
| Frame | Other | 0.006 ms | 5.006 ms | 1 | 9.394 ms | 120/120 |
| SoftBody.OnFrame() | Other | 0.003 ms | 0.003 ms | 100 | 0.020 ms | 120/120 |
| SoftBody.Update() | Other | 0.003 ms | 0.003 ms | 100 | 0.013 ms | 120/120 |
| ConvexCollider.Update() | Physics | 0.003 ms | 0.003 ms | 100 | 0.011 ms | 120/120 |
| MeshRenderer.OnFrame() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.006 ms | 120/120 |
| SphereCollider.Update() | Physics | 0.003 ms | 0.003 ms | 100 | 0.005 ms | 120/120 |
| ConvexCollider.OnFrame() | Physics | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| SphereCollider.OnFrame() | Physics | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.Update() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| MeshRenderer.LateUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.005 ms | 120/120 |
| SphereCollider.LateUpdate() | Physics | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| ConvexCollider.LateUpdate() | Physics | 0.003 ms | 0.003 ms | 100 | 0.004 ms | 120/120 |
| ConvexCollider.FixedUpdate() | Physics | 0.003 ms | 0.003 ms | 100 | 0.008 ms | 120/120 |
| MeshRenderer.FixedUpdate() | Rendering | 0.003 ms | 0.003 ms | 100 | 0.003 ms | 120/120 |
| SphereCollider.FixedUpdate() | Physics | 0.003 ms | 0.003 ms | 100 | 0.003 ms | 120/120 |
| Start | Scripts | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 120/120 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| IK | Animation | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 120/120 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 28: interval 9.488 ms, CPU 4.915 ms, GPU -

```
Frame  total 4.915 ms, self 0.005 ms
  Physics.Step  total 2.711 ms, self 2.711 ms
  LateUpdate (every component)  total 2.094 ms, self 0.016 ms
    SoftBody.LateUpdate()  total 2.062 ms, self 2.062 ms, 100 calls
```

### Frame 27: interval 5.003 ms, CPU 9.394 ms, GPU -

```
Frame  total 9.394 ms, self 0.007 ms
  FixedUpdate (every component)  total 4.399 ms, self 0.017 ms
    SoftBody.FixedUpdate()  total 4.367 ms, self 4.367 ms, 100 calls
  Physics.Step  total 2.804 ms, self 2.804 ms
  LateUpdate (every component)  total 2.110 ms, self 0.016 ms
    SoftBody.LateUpdate()  total 2.078 ms, self 2.078 ms, 100 calls
```

### Frame 91: interval 9.200 ms, CPU 4.851 ms, GPU -

```
Frame  total 4.851 ms, self 0.005 ms
  Physics.Step  total 2.537 ms, self 2.537 ms
  LateUpdate (every component)  total 2.204 ms, self 0.016 ms
    SoftBody.LateUpdate()  total 2.172 ms, self 2.172 ms, 100 calls
```

### Frame 90: interval 6.048 ms, CPU 9.091 ms, GPU -

```
Frame  total 9.091 ms, self 0.005 ms
  FixedUpdate (every component)  total 4.299 ms, self 0.018 ms
    SoftBody.FixedUpdate()  total 4.265 ms, self 4.265 ms, 100 calls
  Physics.Step  total 2.512 ms, self 2.512 ms
  LateUpdate (every component)  total 2.206 ms, self 0.017 ms
    SoftBody.LateUpdate()  total 2.169 ms, self 2.169 ms, 100 calls
```

### Frame 47: interval 8.840 ms, CPU 4.860 ms, GPU -

```
Frame  total 4.859 ms, self 0.005 ms
  Physics.Step  total 2.537 ms, self 2.537 ms
  LateUpdate (every component)  total 2.211 ms, self 0.017 ms
    SoftBody.LateUpdate()  total 2.179 ms, self 2.179 ms, 100 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
