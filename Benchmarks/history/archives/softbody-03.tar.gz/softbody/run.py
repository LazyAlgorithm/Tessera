#!/usr/bin/env python3
"""Sequential Release soft-body capacity sweeps. Run after building the frozen snapshot."""
from pathlib import Path
import subprocess,statistics as st,json,csv,math,datetime,hashlib,sys
O=Path(sys.argv[1]).resolve();S=O/'snapshot';B=S/'bench/build/Release_Linux64/Benchmark/Benchmark'
(O/'source-sha256.json').write_text(json.dumps({str(f.relative_to(S)):hashlib.sha256(f.read_bytes()).hexdigest() for f in S.rglob('*') if f.is_file() and 'build' not in f.relative_to(S).parts},indent=2))
manifest={'started':datetime.datetime.now().isoformat(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'jobs':[]};rows=[];aggregate=[]
configs=[(k,res,8 if k.startswith('rope') else 5) for k in ['cloth','cloth-contact','jelly','jelly-ball','jelly-contact','shell-impacts','shell-surface','shell-convex','rope','rope-load','rope-wrap'] for res in ([8,16,32] if k.startswith('cloth') else [16,32,64] if k.startswith('rope') else [4,8,16])]
def pct(v,p):return sorted(v)[math.ceil(len(v)*p)-1]
def save():
 (O/'manifest.json').write_text(json.dumps(manifest,indent=2))
 if rows:
  with (O/'processes.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 if aggregate:
  with (O/'summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(aggregate[0]));w.writeheader();w.writerows(aggregate)
def run(k,n,res,it,state='active',mode='cpu',reps=3,warm=120,samples=240,profile=False):
 vals=[]
 for rep in range(reps):
  name=f'{k}-{res}-{it}-{n}-{state}-{mode}-{rep}'+('-profile' if profile else '')
  args=[str(B),k,str(n),str(res),str(it),state,mode,str(warm),str(samples)];args+= [str(O/(name+'.tprofile'))] if profile else []
  started=datetime.datetime.now().isoformat()
  try:
   p=subprocess.run(['/usr/bin/time','-f','RESOURCE,%M,%e',*args],capture_output=True,text=True,timeout=180);out=p.stdout+'\n'+p.stderr;code=p.returncode
  except subprocess.TimeoutExpired:out='TIMEOUT';code=-1
  (O/(name+'.log')).write_text(out)
  check={x.split(',')[1]:x.split(',',2)[2] for x in out.splitlines() if x.startswith('CHECK,')}
  v=[list(map(float,x.split(',')[2:])) for x in out.splitlines() if x.startswith('SAMPLE,')];frames=[float(x.split(',')[2]) for x in out.splitlines() if x.startswith('FRAME,')]
  valid=code==0 and len(v)==samples and check.get('valid')=='True' and 'capacity exceeded' not in out.lower() and (mode=='cpu' or len(frames)==samples) and all(math.isfinite(y) and y>=0 for x in v for y in x)
  if mode=='render':valid=valid and int(check.get('draws',0))>0
  entry={'name':name,'args':args,'exit':code,'valid':valid,'checks':check,'started':started};manifest['jobs'].append(entry)
  if not valid:print('INVALID',name,code,check,flush=True);save();return None
  metrics={}
  for i,label in enumerate(['drive','physics','update','total']):metrics[label+'_median_ms']=st.median(x[i] for x in v);metrics[label+'_p95_ms']=pct([x[i] for x in v],.95);metrics[label+'_p99_ms']=pct([x[i] for x in v],.99)
  for label,data in [('frame',frames)]:
   for suffix,value in [('median',st.median(data) if data else 0),('p95',pct(data,.95) if data else 0),('p99',pct(data,.99) if data else 0)]:metrics[label+'_'+suffix+'_ms']=value
  resource=next((x.split(',') for x in out.splitlines() if x.startswith('RESOURCE,')),['',0,0]);row={'case':k,'count':n,'resolution':res,'iterations':it,'state':state,'mode':mode,'repeat':rep,'profile':profile,'vertices':int(check['sim_vertices']),'render_vertices':int(check['render_vertices']),'sleeping':int(check['sleeping_softs']),'contacts':int(check['contact_bodies']),'dent_m':float(check['deepest_dent']),'setup_ms':float(check['setup_ms']),'max_rss_kb':int(resource[1]),**metrics};rows.append(row);vals.append(row);save()
 a={key:vals[0][key] for key in ['case','count','resolution','iterations','state','mode','profile','vertices','render_vertices']};a.update({key:st.median(x[key] for x in vals) for key in ['sleeping','contacts','dent_m','setup_ms','max_rss_kb',*metrics]});a['repeats']=len(vals);aggregate.append(a);save();print('DONE',k,res,it,n,state,mode,'p95',round(a['frame_p95_ms'] if mode=='render' else a['total_p95_ms'],3),flush=True);return a
run('cloth',0,8,5);run('cloth',0,8,5,mode='render')
for k,res,it in configs:
 measured=[]
 for n in [1,10,25,50,100,250,500,1000,2000]:
  a=run(k,n,res,it)
  if a is None:break
  measured.append(a)
  if a['total_p95_ms']>20:break
 # Render baseline and both sides of practical (4ms) and whole-frame (16.67ms) thresholds.
 selected={1}
 for budget in [4,16.667]:
  below=[x for x in measured if x['total_p95_ms']<=budget];above=[x for x in measured if x['total_p95_ms']>budget]
  if below:selected.add(below[-1]['count'])
  if above:selected.add(above[0]['count'])
 for n in sorted(selected):run(k,n,res,it,mode='render')
# Resting/sleeping at representative population and mesh sizes, plus solver-quality sensitivity.
for k in ['cloth','jelly','shell-impacts','shell-surface','rope','rope-load']:
 res=16 if k=='cloth' else 32 if k.startswith('rope') else 8;it=8 if k.startswith('rope') else 5
 run(k,100,res,it,state='rest');run(k,100,res,it,state='rest',mode='render')
for k,res in [('cloth',16),('jelly',8),('rope-load',32)]:
 for it in [2,12,24]:run(k,100,res,it)
for k,res,it in [('cloth',16,5),('jelly-contact',8,5),('shell-convex',8,5),('rope-load',32,8)]:run(k,100,res,it,reps=1,samples=120,profile=True)
manifest['finished']=datetime.datetime.now().isoformat();save();print('COMPLETE',len(manifest['jobs']),flush=True)
