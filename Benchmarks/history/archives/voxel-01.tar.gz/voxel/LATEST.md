# Latest voxel shooter benchmark

[Full report](/home/zerker24/BeefProjects/Tessera/Benchmarks/voxel/results-20261029-191142/REPORT.md)

Intact maps, carving bullets, digging, explosion fan-out, benchmark-only edit coalescing, fragments, debris and imported-model startup.
