# Tessera Profiler report

Frames 0 to 0 (40 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 35.492 ms | 35.484 ms | 35.799 ms | 35.933 ms | 35.933 ms | 35.291 ms |
| CPU main thread | 35.480 ms | 35.472 ms | 35.788 ms | 35.919 ms | 35.919 ms | 35.280 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Other: 35.454 ms
- Scripts: 0.011 ms
- Rendering: 0.007 ms
- Physics: 0.007 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- AI: 0.000 ms
- Networking: 0.000 ms

## Thread 'Voxel Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Frame | Other | 35.454 ms | 35.479 ms | 1 | 35.918 ms | 40/40 |
| OnFrame (every component) | Scripts | 0.003 ms | 0.006 ms | 2 | 0.015 ms | 40/40 |
| Physics.Step | Physics | 0.003 ms | 0.003 ms | 1 | 0.007 ms | 40/40 |
| LateUpdate (every component) | Scripts | 0.002 ms | 0.005 ms | 2 | 0.007 ms | 40/40 |
| Update (every component) | Scripts | 0.002 ms | 0.005 ms | 2 | 0.006 ms | 40/40 |
| FixedUpdate (every component) | Scripts | 0.002 ms | 0.004 ms | 1 | 0.010 ms | 40/40 |
| VoxelObject.OnFrame() | Rendering | 0.001 ms | 0.001 ms | 32 | 0.002 ms | 40/40 |
| MeshRenderer.LateUpdate() | Rendering | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| VoxelObject.LateUpdate() | Rendering | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| MeshCollider.LateUpdate() | Physics | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| MeshRenderer.OnFrame() | Rendering | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| MeshCollider.OnFrame() | Physics | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| VoxelObject.Update() | Rendering | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| MeshCollider.Update() | Physics | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| MeshRenderer.Update() | Rendering | 0.001 ms | 0.001 ms | 32 | 0.001 ms | 40/40 |
| VoxelObject.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 16 | 0.001 ms | 40/40 |
| MeshRenderer.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 16 | 0.001 ms | 40/40 |
| MeshCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 16 | 0.001 ms | 40/40 |
| Start | Scripts | 0.000 ms | 0.000 ms | 3 | 0.001 ms | 40/40 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| IK | Animation | 0.000 ms | 0.000 ms | 2 | 0.001 ms | 40/40 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.001 ms | 40/40 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.001 ms | 40/40 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 2 | 0.001 ms | 40/40 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 0: interval 35.933 ms, CPU 35.788 ms, GPU -

```
Frame  total 35.788 ms, self 35.764 ms
```

### Frame 0: interval 35.333 ms, CPU 35.919 ms, GPU -

```
Frame  total 35.918 ms, self 35.880 ms
```

### Frame 0: interval 35.891 ms, CPU 35.701 ms, GPU -

```
Frame  total 35.701 ms, self 35.674 ms
```

### Frame 0: interval 35.799 ms, CPU 35.878 ms, GPU -

```
Frame  total 35.878 ms, self 35.848 ms
```

### Frame 0: interval 35.713 ms, CPU 35.446 ms, GPU -

```
Frame  total 35.446 ms, self 35.422 ms
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
