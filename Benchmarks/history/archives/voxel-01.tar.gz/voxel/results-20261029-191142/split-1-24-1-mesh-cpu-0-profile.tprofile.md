# Tessera Profiler report

Frames 0 to 0 (40 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.662 ms | 1.648 ms | 1.801 ms | 1.855 ms | 1.855 ms | 1.424 ms |
| CPU main thread | 1.659 ms | 1.645 ms | 1.798 ms | 1.853 ms | 1.853 ms | 1.422 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Other: 1.484 ms
- Scripts: 0.160 ms
- Physics: 0.014 ms
- Rendering: 0.001 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- AI: 0.000 ms
- Networking: 0.000 ms

## Thread 'Voxel Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Frame | Other | 1.484 ms | 1.659 ms | 1 | 1.853 ms | 40/40 |
| Start | Scripts | 0.121 ms | 0.121 ms | 3 | 0.161 ms | 40/40 |
| Destroy | Scripts | 0.036 ms | 0.036 ms | 2 | 0.054 ms | 40/40 |
| Physics.Step | Physics | 0.013 ms | 0.013 ms | 1 | 0.029 ms | 40/40 |
| OnFrame (every component) | Scripts | 0.001 ms | 0.001 ms | 2 | 0.010 ms | 40/40 |
| LateUpdate (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.001 ms | 40/40 |
| Update (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.001 ms | 40/40 |
| FixedUpdate (every component) | Scripts | 0.000 ms | 0.001 ms | 1 | 0.001 ms | 40/40 |
| IK | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.OnFrame() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.Update() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| MeshRenderer.OnFrame() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| MeshRenderer.LateUpdate() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| MeshRenderer.Update() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.LateUpdate() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| ConvexCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Rigidbody.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshRenderer.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Rigidbody.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| ConvexCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Rigidbody.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| ConvexCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| MeshCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| ConvexCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Rigidbody.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 0: interval 1.855 ms, CPU 1.645 ms, GPU -

```
Frame  total 1.645 ms, self 1.472 ms
  Start  total 0.123 ms, self 0.123 ms, 3 calls
```

### Frame 0: interval 1.703 ms, CPU 1.853 ms, GPU -

```
Frame  total 1.853 ms, self 1.676 ms
  Start  total 0.122 ms, self 0.122 ms, 3 calls
```

### Frame 0: interval 1.833 ms, CPU 1.712 ms, GPU -

```
Frame  total 1.712 ms, self 1.517 ms
  Start  total 0.129 ms, self 0.129 ms, 3 calls
```

### Frame 0: interval 1.647 ms, CPU 1.830 ms, GPU -

```
Frame  total 1.830 ms, self 1.598 ms
  Start  total 0.161 ms, self 0.161 ms, 3 calls
```

### Frame 0: interval 1.801 ms, CPU 1.671 ms, GPU -

```
Frame  total 1.671 ms, self 1.490 ms
  Start  total 0.124 ms, self 0.124 ms, 3 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
