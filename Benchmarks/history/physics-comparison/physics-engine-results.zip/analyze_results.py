from pathlib import Path
import csv,json,collections,statistics,itertools
ROOT=Path(__file__).resolve().parent
NAMES={0:'Jolt',1:'Box3D',2:'Rapier',3:'Bullet'}
SCENES={0:'Aligned cubes',1:'Falling rotated cubes',2:'Spheres',3:'Separated cubes',4:'Mixed shapes / mesh'}
KEYS=['profile','suite','engine','scene','bodies','threads','substeps','sleep','ccd']
METRICS=['mean_ms','p95_ms','max_ms','first120_ms','last120_ms','setup_ms','active','escaped','nonfinite','min_y','max_y','rms_v','rms_w','checksum','errors']
def read(p):
 with open(ROOT/p) as f:return list(csv.DictReader(f))
def main():
 rows=read('results/simulations.csv');groups=collections.defaultdict(list)
 for r in rows:groups[tuple(r[k] for k in KEYS)].append(r)
 summaries=[]
 for key,rs in sorted(groups.items()):
  d=dict(zip(KEYS,key));d['engine_name']=NAMES[int(d['engine'])];d['scene_name']=SCENES[int(d['scene'])];d['runs']=len(rs);d['valid_runs']=sum(r['valid']=='1' for r in rs)
  for f in METRICS:d[f]=statistics.median(float(r[f]) for r in rs)
  d['min_mean_ms']=min(float(r['mean_ms']) for r in rs);d['max_mean_ms']=max(float(r['mean_ms']) for r in rs)
  d['max_escaped']=max(int(r['escaped']) for r in rs);d['any_errors']=any(int(r['errors']) or int(r['nonfinite']) for r in rs)
  summaries.append(d)
 with open(ROOT/'results/summary.csv','w') as f:
  w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
 (ROOT/'results/summary.json').write_text(json.dumps(summaries,indent=2))
 g={tuple(d[k] for k in KEYS):d for d in summaries}
 def get(profile,e,scene,n,t,sub=None,suite='main',sleep=0,ccd=0):return g[(profile,suite,str(e),str(scene),str(n),str(t),str(({0:1,1:4,2:4,3:1}[e]) if sub is None else sub),str(sleep),str(ccd))]
 def cell(d):return f"FAIL ({d['valid_runs']}/{d['runs']} valid)" if d['valid_runs']!=d['runs'] else f"{d['mean_ms']:.3f} / {d['p95_ms']:.3f}"
 text='''# Four physics engines, benchmarked from Beef

This is a fresh standalone benchmark of **Jolt, Box3D, Rapier, and Bullet**, all driven by the same **Beef 0.43.6 Release executable** and the same small C ABI. No Tessera runtime or physics wrapper is involved. All workloads use shared Beef-generated inputs; engine-specific solver algorithms remain different.

**Findings:** Box3D was fastest in the four optimized 4,000-body, four-worker non-mesh workloads. Rapier beat Jolt there by about 1.1–2.0×, while Jolt was faster in the mixed-mesh workload and several query tests. Bullet generally trailed Jolt with four workers, but won some single-worker tests. Box3D lost two capsules through this mesh even with CCD enabled; Bullet's discrete mesh tests failed, while its corrected CCD controls passed. These are workload-specific results, not a universal ranking.

Machine: **AMD Ryzen 9 7900X, 12 physical / 24 logical cores, approximately 64 GiB RAM, Nobara Linux, GCC 16.2.1, Rust 1.99.1**. CPU governor performance, boost on. One-worker tests use CPU 0; four-worker tests use CPUs 0–3, distinct physical cores on one CCD/L3. Desktop software remained open. Native libraries are Release optimized, single precision, no LTO; Beef uses its Release GNU backend (`-O2`).

Versions: **Jolt 5.6.0; Box3D 0.1.0 development snapshot; Rapier 0.36.1 development snapshot; Bullet 3.26 development snapshot**. Exact clean upstream commits, compiler metadata, and binary hashes: [metadata](results/metadata.json).

## Simulation: optimized configuration

Each row is **dynamic body count + one static ground body**, 600 updates at **60 Hz / 16.667 ms**, ten simulated seconds, three fresh-process repeats. Values are **median mean / median p95 step milliseconds**; lower is better. Timings include the Beef→native call. Sleeping and CCD are off. Gravity −9.81, effective friction .5, restitution/damping zero, density 1,000 kg/m³.

**Solver settings:** Jolt one collision step, 10 velocity + 2 position iterations; Box3D four solver substeps; Rapier four solver substeps with 1 internal PGS and 1 stabilization iteration; Bullet one integration step with 10 iterations. Mesh uses Jolt 4+1 iterations and Bullet 5. Optimized Jolt/Box3D/Rapier use AVX2/eight-wide paths where supported; Bullet uses its CPU multithreaded solver. These are normal engine-specific configurations, not a claim of equal physical accuracy. Matching-count controls follow below.

| Workload | Dynamic + static bodies | Active worker budget | Jolt mean / p95 ms | Box3D mean / p95 ms | Rapier mean / p95 ms | Bullet mean / p95 ms |
|---|---:|---:|---:|---:|---:|---:|
'''
 for scene in range(5):
  for n in ([484] if scene==4 else [1000,4000]):
   for t in [1,4]:
    ds=[get('fast',e,scene,n,t) for e in range(4)]
    text+=f"| {SCENES[scene]} | {n} + 1 | {t} | "+' | '.join(cell(d) for d in ds)+' |\n'
 text+='''
A failure is retained but not ranked: escaped bodies, nonfinite state or explicit update errors invalidate the simulation. A passing run can still have different compression, jitter or contact behavior; see quality diagnostics below. Solver timings include initial impacts; first/last 120-frame means and repeat ranges are in the raw and aggregated CSVs.

## Four-wide / determinism-enabled comparison

Same 60 Hz, ten-second workload and default solver counts, sleeping/CCD off. Jolt uses its cross-platform-deterministic build, Box3D uses width 4, Rapier uses enhanced determinism and width 4 with parallelism. Bullet uses the baseline-CPU build and **is not certified cross-platform deterministic**. The thread budget is active workers, not every live OS thread; Rapier can have a waiting host thread and Bullet's scheduler retains dormant threads.

| Workload | Dynamic + static bodies | Active worker budget | Jolt mean / p95 ms | Box3D mean / p95 ms | Rapier mean / p95 ms | Bullet baseline mean / p95 ms |
|---|---:|---:|---:|---:|---:|---:|
'''
 for scene,t in itertools.product(range(5),[1,4]):
  n=484 if scene==4 else 4000
  text+=f"| {SCENES[scene]} | {n} + 1 | {t} | "+' | '.join(cell(get('deterministic',e,scene,n,t)) for e in range(4))+' |\n'
 text+='''
## Identical-count substep controls

4,000 dynamic sharp cubes + ground, optimized build, 60 Hz, sleeping/CCD off, three repetitions. Both counts are native engine API counts: Jolt collision steps, Box3D solver substeps, Rapier solver substeps/iterations, Bullet fixed integration steps. **Equal counts still do not match inner solver work or collision refreshes.** Jolt retains 10+2 iterations per collision step; Bullet retains 10 iterations per integration step.

| Engine | Worker budget | Count 1 mean / p95 ms | Count 4 mean / p95 ms | Highest center y at count 1 / 4 (m) | RMS linear speed count 1 / 4 (m/s) |
|---|---:|---:|---:|---:|---:|
'''
 for e,t in itertools.product(range(4),[1,4]):
  ds=[]
  for sub in [1,4]:
   suite='main' if sub=={0:1,1:4,2:4,3:1}[e] else 'substep_control'
   ds.append(get('fast',e,0,4000,t,sub,suite))
  a,b=ds;text+=f"| {NAMES[e]} | {t} | {cell(a)} | {cell(b)} | {a['max_y']:.4f} / {b['max_y']:.4f} | {a['rms_v']:.6f} / {b['rms_v']:.6f} |\n"
 text+='''
## Quality and sleep behavior

Optimized build, 4,000 dynamic aligned cubes + ground, four-worker budget, 60 Hz, default engine counts. Ideal uncompressed highest center is 15.5 m; lowest center .5 m. Residual linear/angular speed and active count are recorded after ten seconds. Engine-specific default tolerances and sleep policies are preserved, so sleep timings are not equally active workloads.

| Engine | Count | Sleeping | Mean ms | Last 120 frames ms | Active at end | Lowest / highest center y (m) | RMS linear m/s | RMS angular rad/s |
|---|---:|---|---:|---:|---:|---:|---:|---:|
'''
 for sleep,e in itertools.product([0,1],range(4)):
  d=get('fast',e,0,4000,4,suite='sleep' if sleep else 'main',sleep=sleep)
  text+=f"| {NAMES[e]} | {d['substeps']} | {'On' if sleep else 'Off'} | {d['mean_ms']:.3f} | {d['last120_ms']:.6f} | {d['active']:.0f} | {d['min_y']:.4f} / {d['max_y']:.4f} | {d['rms_v']:.6f} | {d['rms_w']:.6f} |\n"
 if (ROOT/'quality-table.md').exists():text+='\nAdditional final-state captures (one extra run per configuration, not timing repetitions) measure the whole stack distribution. Ideal mean center height is 7.82 m, with 256 bottom-layer cubes. These diagnostics help distinguish residual motion from actual collapse.\n\n'+(ROOT/'quality-table.md').read_text()+'\n![Final height distributions](stack-quality.png)\n'
 text+='''
## Mixed shapes on a triangle mesh, including CCD

484 dynamic boxes/spheres/capsules/pyramid hulls + one static mesh body, 2,000 triangles, optimized build, four-worker budget, 60 Hz. Jolt uses 4 velocity + 1 position iterations, Bullet 5; Box3D/Rapier retain defaults. This resembles the old Jolt-versus-Bullet comparison's workload and iteration choices, but does not reproduce its historical geometry, versions or hardware. It checks a modern trend rather than validating every claim in the old document.

| Engine | CCD | Native count | Mean / p95 ms or status | Escaped centers, maximum across repeats |
|---|---|---:|---:|---:|
'''
 for suite,ccd in [('main',0),('mesh_ccd',1),('mesh_four_steps',1)]:
  for e in range(4):
   sub=4 if suite=='mesh_four_steps' else None;d=get('fast',e,4,484,4,sub,suite,ccd=ccd)
   text+=f"| {NAMES[e]} | {'On' if ccd else 'Off'} | {d['substeps']} | {cell(d)} | {d['max_escaped']} |\n"
 text+='''
CCD differs by engine: Jolt linear shape casts, Box3D continuous collision, Rapier body CCD/one CCD pass, Bullet a swept-sphere approximation (threshold .01 m, radius half the smallest shape half-extent). Turning CCD on does not establish identical collision handling or guarantee that every setup passes. Failed mesh timings are available in CSV but excluded from speed claims. The zero-margin sharp-geometry choice and engine-specific mesh edge handling are material to these failures; this is not proof that an engine fails all mesh scenes.

## Closest-hit queries from Beef

Frozen, identical initial geometry; one active caller on CPU 0, no simulation steps. All layers and static/dynamic bodies included, no ignored bodies/predicates. Every backend returns hit, fraction, world point and world normal. Five batches of 20,000 calls after a discarded warmup batch; median ns/query. Values include common Beef query generation, loop, native call and result accumulation.

Down ray and sphere sweep: from y=100 downward 200 m; sweep radius .25 m. Across ray: sampled height, horizontal length 16.24 m for 1,000 boxes/spheres or 23.584 m for 4,000. Miss ray: from y=100 upward 100 m. No initial overlaps. Sweeps request zero separation and closest-hit clipping; detailed engine flags, sample footprints and mesh query lengths are in [methodology](METHODOLOGY.md).

'''
 if (ROOT/'results/queries.csv').exists():
  qg=collections.defaultdict(list)
  for r in read('results/queries.csv'):qg[tuple(r[k] for k in ['profile','engine','scene','bodies','query'])].append(r)
  for profile in ['fast','deterministic']:
   text+=f"### {'Optimized' if profile=='fast' else 'Four-wide / determinism-enabled'} queries\n\n| Geometry | Dynamic + static bodies | Query | Jolt ns | Box3D ns | Rapier ns | Bullet ns | Hit counts J / Box / R / B (of 20,000) |\n|---|---:|---|---:|---:|---:|---:|---|\n"
   for scene in [0,2,4]:
    for n in ([484] if scene==4 else [1000,4000]):
     for mode in range(4):
      vals=[qg.get((profile,str(e),str(scene),str(n),str(mode)),[]) for e in range(4)]
      if not all(vals):continue
      ns=[statistics.median(float(x['ns']) for x in v) for v in vals];hits=[v[0]['hits'] for v in vals]
      text+=f"| {SCENES[scene]} | {n} + 1 | {['Ray down','Ray across','Ray miss','Sphere sweep'][mode]} | "+' | '.join(f'{v:.1f}' for v in ns)+' | '+' / '.join(hits)+' |\n'
   text+='\n'
 text+='''Query hit/fraction/normal differences are saved instead of assuming identical numerical answers. The timing comparison does not establish equal grazing-hit tolerance or identical mesh backface/internal-edge behavior. These are whole-world closest queries, not a general claim about character controllers, all-hit enumeration, or overlap contact extraction.

## Beef/native overhead controls

Each simulation pair uses fresh worlds, 1,000 aligned cubes + ground, optimized profile, 60 Hz, ten simulated seconds, no sleep/CCD, default engine counts. One run has Beef call each step; the other makes one call into a C++ loop doing the same steps. Order alternates across three repetitions. Most paired median ratios are within about 1.3% of one. Rapier's four-worker control is noisier: paired ratios span roughly 0.865–1.161, with a median about 1.057. That spread does not establish a consistent 5.7% language-boundary penalty. Ratios should be interpreted with repeat-to-repeat desktop/scheduler noise; they are not precise nanosecond interop estimates.

'''
 if (ROOT/'results/native-controls.csv').exists():
  cg=collections.defaultdict(list)
  for r in read('results/native-controls.csv'):cg[(int(r['engine']),int(r['threads']))].append(r)
  text+='| Engine | Worker budget | Beef-loop mean ms | C++-loop mean ms | Median paired Beef / C++ |\n|---|---:|---:|---:|---:|\n'
  for (e,t),rs in sorted(cg.items()):text+=f"| {NAMES[e]} | {t} | {statistics.median(float(r['beef_ms']) for r in rs):.4f} | {statistics.median(float(r['native_ms']) for r in rs):.4f} | {statistics.median(float(r['beef_over_native']) for r in rs):.3f}× |\n"
 if (ROOT/'results/noop.csv').exists():
  rs=read('results/noop.csv');text+=f"\nThe one-million-call no-op control measures **{statistics.median(float(r['ns_per_call']) for r in rs):.2f} ns per Beef→native call plus loop/dependency work**, median of five runs. This does not include each engine's own internal wrapper or locking work.\n"
 text+='''
## Interpretation and reproduction

Read each workload separately. Faster times can accompany more compression, different residual motion, or a failed collision test. Default solver counts and equal-count controls answer different questions; neither proves equal accuracy. These results concern the named engine revisions and this workstation, not Tessera's full frame, a platform-independent ranking, or validated networking determinism.

The mesh workload provides a direct contemporary Jolt/Bullet check, with failures and solver settings visible. It must not be presented as a repeat of the 2022/2023 Jolt paper or as proof of universal superiority. Original document: [Jolt multicore comparison](https://jrouwe.nl/jolt/JoltPhysicsMulticoreScaling.pdf).

Re-run with `./rerun.sh`. It rebuilds native libraries and the Beef driver, validates ABI/free-fall motion, runs the randomized suite, and regenerates tables. A local Rust toolchain is under `toolchain/`; the scripts do not change the user's default toolchain. Source revisions must remain pinned for reproduction. Results and scripts are all local and reviewable:

- [Detailed methodology](METHODOLOGY.md), [machine/build metadata](results/metadata.json).
- [Raw simulations](results/simulations.csv), [summary with repeat ranges](results/summary.csv), [query batches](results/queries.csv).
- [Native-loop controls](results/native-controls.csv), [no-op controls](results/noop.csv), [validation log](results/smoke.log), [run log](results/run-log.jsonl).
- [Beef source](driver/src/Program.bf), [common C ABI](backend.h), [engine adapters](backend.cpp), [CMake configuration](CMakeLists.txt).

Joint constraints, character controllers, 2D, WebAssembly, networking, cross-platform replay, memory usage and energy consumption are outside this suite.
'''
 (ROOT/'REPORT.md').write_text(text)
 try:plot(summaries)
 except ImportError:pass
 print('Summarized',len(rows),'runs,',len(summaries),'configurations')
def plot(ds):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
 for ax,t in zip(axes,['1','4']):
  for e,color in zip(range(4),['#ad5849','#2c817c','#6384be','#a5863c']):
   vals=[]
   for scene in range(4):
    d=next(x for x in ds if x['profile']=='fast' and x['suite']=='main' and x['engine']==str(e) and x['scene']==str(scene) and x['bodies']=='4000' and x['threads']==t)
    vals.append(d['mean_ms'] if d['valid_runs']==d['runs'] else float('nan'))
   ax.bar([i+(e-1.5)*.2 for i in range(4)],vals,.19,label=NAMES[e],color=color)
  ax.set_xticks(range(4),['Aligned cubes','Rotated cubes','Spheres','Separated']);ax.set_title(f'{t} active physics worker'+('s' if t=='4' else ''));ax.set_ylabel('Mean step time (ms), lower is better');ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
 axes[0].legend(fontsize=9);fig.suptitle('Same Beef host · Ryzen 9 7900X · 4,000 dynamic + 1 static body · 60 Hz\nOptimized builds · median of three 600-frame runs · default engine-specific solver counts',fontsize=11)
 fig.savefig(ROOT/'comparison.png',dpi=170)
if __name__=='__main__':main()
