#pragma once
#include <stdint.h>
struct V{float x,y,z;};
struct Q{float x,y,z,w;};
struct BodyDesc {V p; Q q; V half; int32_t shape,dynamic; float friction,restitution,linearDamping,angularDamping,density; int32_t sleep;};
struct State {V p; Q q; V v,w; int32_t active;};
struct Query {V origin,delta; float radius; int32_t kind;};
struct Hit {V point,normal; float fraction; int32_t hit;};
