#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
export CARGO_HOME="$PWD/toolchain/cargo"
export RUSTUP_HOME="$PWD/toolchain/rustup"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_BUILD_JOBS=8
export RUSTFLAGS="-C target-cpu=x86-64-v3 -C opt-level=3"
cmake -S . -B build/fast -DCMAKE_BUILD_TYPE=Release -DBENCH_DETERMINISTIC=OFF
cmake --build build/fast --target physicsbench -j 10
export RUSTFLAGS="-C target-cpu=x86-64 -C opt-level=3"
cmake -S . -B build/deterministic -DCMAKE_BUILD_TYPE=Release -DBENCH_DETERMINISTIC=ON
cmake --build build/deterministic --target physicsbench -j 10
