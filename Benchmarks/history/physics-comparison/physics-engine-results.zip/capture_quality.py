from pathlib import Path
import subprocess,time,os,csv,json,hashlib,sys
root=Path(__file__).resolve().parent;os.chdir(root)
while '--now' not in sys.argv and (not Path('correction-progress.log').exists() or 'CCD CORRECTION DONE' not in Path('correction-progress.log').read_text()):
 if subprocess.run(['pgrep','-f','^python correct_ccd_threshold.py$'],capture_output=True).returncode!=0:raise RuntimeError('correction did not finish')
 time.sleep(2)
p=Path('driver/src/Program.bf');s=p.read_text();Path('results/Program-before-snapshot.bf').write_text(s)
old='bench_state(world,ids[i],&s);if(!Fin'
assert old in s or 'BODY,{i}' in s
s=s.replace(old,'bench_state(world,ids[i],&s);if(mode==5)Console.WriteLine(scope $"BODY,{i},{s.p.x},{s.p.y},{s.p.z},{s.q.x},{s.q.y},{s.q.z},{s.q.w},{s.v.x},{s.v.y},{s.v.z},{s.w.x},{s.w.y},{s.w.z}");if(!Fin')
p.write_text(s)
subprocess.run(['/home/zerker24/Beef/IDE/dist/BeefBuild','-workspace=driver','-config=Release'],check=True,stdout=open('quality-beef-build.log','w'),stderr=subprocess.STDOUT)
from run_suite import call,DEFAULT
with open('results/final-states.csv','w') as out:
 w=csv.writer(out);w.writerow(['engine','substeps','kind','body','x','y','z','qx','qy','qz','qw','vx','vy','vz','wx','wy','wz'])
 for e in range(4):
  for sub in [1,4]:
   p,_,args=call('fast',e,0,4000,4,sub,mode=5)
   if p.returncode:raise RuntimeError((args,p.stdout[-1000:],p.stderr))
   lines=[line for line in p.stdout.splitlines() if line.startswith('BODY,')];assert len(lines)==4000
   w.writerows([[e,sub]+next(csv.reader([line])) for line in lines]);out.flush()
   print('snapshot',e,sub,flush=True)
p=Path('results/metadata.json');m=json.loads(p.read_text());m['snapshot_driver_sha256']=hashlib.sha256(Path('driver/src/Program.bf').read_bytes()).hexdigest();m['snapshot_executable_sha256']=hashlib.sha256(Path('driver/build/Release_Linux64/PhysicsBench/PhysicsBench').read_bytes()).hexdigest();p.write_text(json.dumps(m,indent=2))
print('SNAPSHOTS DONE',flush=True)
