from pathlib import Path
import os,time,subprocess,csv,json,hashlib,datetime
root=Path(__file__).resolve().parent;os.chdir(root)
while subprocess.run(['pgrep','-f','^python run_suite.py$'],capture_output=True).returncode==0:time.sleep(2)
if 'ALL DONE' not in Path('progress.log').read_text():raise RuntimeError('suite did not finish')
# A .25 m activation threshold would not activate Bullet CCD for many of these impacts.
# Lower it before accepting the CCD-specific controls. No non-CCD branch changes.
p=Path('backend.cpp');original=p.read_text();old='b->setCcdMotionThreshold(.25f);';assert old in original
Path('results/backend-before-ccd-threshold.cpp').write_text(original)
updated=original.replace(old,'b->setCcdMotionThreshold(.01f);')
updated=updated.replace('d.friction=.5f;r3InsertColliderWithoutParent(w,&d);','d.friction=.5f;auto fixed=r3FixedRigidBodyDesc();auto ground=r3InsertRigidBody(w,&fixed);r3InsertCollider(ground,&d);')
p.write_text(updated)
subprocess.run(['./build_native.sh'],check=True,stdout=open('ccd-correction-build.log','w'),stderr=subprocess.STDOUT)
from run_suite import call
with open('results/simulations.csv') as f:reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
oldrows=[];changes=[]
for i,r in enumerate(rows):
 if (r['engine']=='3' and r['ccd']=='1') or (r['engine']=='2' and r['scene']=='4'):
  oldrows.append(r.copy());p,elapsed,args=call(r['profile'],int(r['engine']),int(r['scene']),int(r['bodies']),int(r['threads']),int(r['substeps']),int(r['sleep']),ccd=int(r['ccd']))
  if p.returncode not in [0,4]:raise RuntimeError((args,p.stdout,p.stderr))
  vals=next(csv.reader([next(x for x in p.stdout.splitlines() if x.startswith('SIM,'))]))
  prefix=[r[k] for k in ['profile','suite','repeat','ccd']]+[str(int(p.returncode==0))]
  rows[i]=dict(zip(fields,prefix+vals));changes.append({'args':args,'returncode':p.returncode,'stderr':p.stderr,'seconds':elapsed})
with open('results/superseded-mesh-controls.csv','w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(oldrows)
with open('results/simulations.csv','w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
with open('results/queries.csv') as f:reader=csv.DictReader(f);qfields=reader.fieldnames;qrows=list(reader)
qrows=[r for r in qrows if not (r['engine']=='2' and r['scene']=='4')]
for profile in ['fast','deterministic']:
 p,_,args=call(profile,2,4,484,1,4,mode=1)
 if p.returncode:raise RuntimeError((args,p.stdout,p.stderr))
 qrows += [dict(zip(qfields,[profile]+next(csv.reader([line])))) for line in p.stdout.splitlines() if line.startswith('QUERY,')]
with open('results/queries.csv','w') as f:w=csv.DictWriter(f,fieldnames=qfields);w.writeheader();w.writerows(qrows)
Path('results/ccd-correction-log.json').write_text(json.dumps(changes,indent=2))
p=Path('results/metadata.json');m=json.loads(p.read_text());m['bullet_ccd_activation_threshold_m']=.01;m['ccd_control_correction']='Bullet CCD controls rerun at .01 m activation threshold. Rapier mesh trials/queries rerun with an explicit fixed ground body matching the other engines; superseded controls retained separately.';m['sha256_after_ccd_control_correction']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ['backend.cpp','build/fast/libphysicsbench.so','build/deterministic/libphysicsbench.so']};m['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(m,indent=2))
print('CCD CORRECTION DONE',flush=True)
