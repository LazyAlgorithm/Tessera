from pathlib import Path
import subprocess,time,os,csv,json,hashlib,datetime
root=Path(__file__).resolve().parent;os.chdir(root)
while not Path('quality-progress.log').exists() or 'SNAPSHOTS DONE' not in Path('quality-progress.log').read_text():
 if subprocess.run(['pgrep','-f','^python capture_quality.py$'],capture_output=True).returncode!=0:raise RuntimeError('quality captures did not finish')
 time.sleep(2)
p=Path('backend.cpp');s=p.read_text();old='void bench_ready(void*p,int queryOnly,int engine){if(engine!=2||queryOnly)((Backend*)p)->ready();}'
assert old in s
p.write_text(s.replace(old,'void bench_ready(void*p,int queryOnly,int engine){if(engine!=2||queryOnly)((Backend*)p)->ready();if(engine==3&&queryOnly)static_cast<BulletBackend*>(p)->broad.optimize();}'))
subprocess.run(['./build_native.sh'],check=True,stdout=open('query-optimization-build.log','w'),stderr=subprocess.STDOUT)
from run_suite import call,DEFAULT
with open('results/queries.csv') as f:reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
oldrows=[r for r in rows if r['engine']=='3'];rows=[r for r in rows if r['engine']!='3']
with open('results/superseded-bullet-unbalanced-queries.csv','w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(oldrows)
for profile in ['fast','deterministic']:
 for scene in [0,2,4]:
  for n in ([484] if scene==4 else [1000,4000]):
   p,_,args=call(profile,3,scene,n,1,DEFAULT[3],mode=1)
   if p.returncode:raise RuntimeError((args,p.stdout,p.stderr))
   rows += [dict(zip(fields,[profile]+next(csv.reader([line])))) for line in p.stdout.splitlines() if line.startswith('QUERY,')]
with open('results/queries.csv','w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
p=Path('results/metadata.json');m=json.loads(p.read_text());m['bullet_query_preparation']='DBVT optimize() outside timed frozen queries; insertion-built-tree queries retained separately for audit. Simulation ready() is unchanged.';m['sha256_final']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ['backend.cpp','driver/src/Program.bf','build/fast/libphysicsbench.so','build/deterministic/libphysicsbench.so','driver/build/Release_Linux64/PhysicsBench/PhysicsBench']};m['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(m,indent=2))
print('QUERY OPTIMIZATION DONE',flush=True)
