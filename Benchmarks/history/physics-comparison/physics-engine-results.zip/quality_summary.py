import csv,collections,statistics,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analyze_results import NAMES
root=pathlib.Path(__file__).resolve().parent
g=collections.defaultdict(list)
for r in csv.DictReader(open(root/'results/final-states.csv')):g[(int(r['engine']),int(r['substeps']))].append(r)
fig,axes=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
lines=['| Engine | Native count | Mean center height (m) | Bodies with centers below 0.6 m | RMS linear speed (m/s) |','|---|---:|---:|---:|---:|']
with open(root/'results/quality-summary.csv','w') as out:
 w=csv.writer(out);w.writerow(['engine','substeps','mean_y','floor_count','rms_v'])
 for (e,sub),rs in sorted(g.items()):
  ys=sorted(float(x['y']) for x in rs);rms=(sum(sum(float(x[k])**2 for k in ['vx','vy','vz']) for x in rs)/len(rs))**.5;floor=sum(y<.6 for y in ys);my=statistics.mean(ys)
  w.writerow([NAMES[e],sub,my,floor,rms]);lines.append(f'| {NAMES[e]} | {sub} | {my:.4f} | {floor} / 4,000 | {rms:.6f} |')
  axes[0 if sub==1 else 1].plot(ys,[(i+1)/len(ys) for i in range(len(ys))],label=NAMES[e],linewidth=1.6)
ideal=sorted([i//256+.5 for i in range(4000)])
for ax,sub in zip(axes,[1,4]):
 ax.plot(ideal,[(i+1)/4000 for i in range(4000)],'k--',alpha=.65,label='Ideal uncompressed');ax.set_title(f'Native count {sub}');ax.set_xlabel('Body center height (m)');ax.set_ylabel('Fraction of bodies at or below height');ax.grid(alpha=.2);ax.set_xlim(0,17)
axes[0].legend(fontsize=8);fig.suptitle('Stack settling diagnostic · 4,000 cubes + ground · 60 Hz · 10 seconds\nSame Beef host, optimized build, four-worker budget, sleep/CCD off; one extra run per configuration',fontsize=10)
fig.savefig(root/'stack-quality.png',dpi=170)
(root/'quality-table.md').write_text('\n'.join(lines)+'\n')
print('quality summarized')
