#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
./build_native.sh
/home/zerker24/Beef/IDE/dist/BeefBuild -workspace=driver -config=Release
python smoke.py
python run_suite.py
python capture_quality.py --now
python quality_summary.py
python analyze_results.py
