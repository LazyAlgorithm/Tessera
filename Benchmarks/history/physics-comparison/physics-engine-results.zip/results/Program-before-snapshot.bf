using System;
using System.Collections;
namespace PhysicsBench;
[CRepr] struct V {public float x,y,z;public this(float a,float b,float c){x=a;y=b;z=c;}}
[CRepr] struct Q {public float x,y,z,w;public this(float a,float b,float c,float d){x=a;y=b;z=c;w=d;}}
[CRepr] struct BodyDesc {public V p;public Q q;public V half;public int32 shape,dynamic;public float friction,restitution,linearDamping,angularDamping,density;public int32 sleep;}
[CRepr] struct State {public V p;public Q q;public V v,w;public int32 active;}
[CRepr] struct Query {public V origin,delta;public float radius;public int32 kind;}
[CRepr] struct Hit {public V point,normal;public float fraction;public int32 hit;}
class Program {
 [CLink] static extern void* bench_create(int32 engine,int32 threads,int32 ccd,int32 doc);
 [CLink] static extern void bench_destroy(void* world);
 [CLink] static extern int32 bench_add(void* world,BodyDesc* desc);
 [CLink] static extern void bench_mesh(void* world,V* vertices,int32 nv,uint32* indices,int32 nt);
 [CLink] static extern void bench_ready(void* world,int32 queryOnly,int32 engine);
 [CLink] static extern int32 bench_step(void* world,float dt,int32 substeps);
 [CLink] static extern void bench_state(void* world,int32 index,State* state);
 [CLink] static extern void bench_query(void* world,Query* query,Hit* hit);
 [CLink] static extern uint64 bench_clock_ns();
 [CLink] static extern int32 bench_abi(int32 i);
 [CLink] static extern int32 bench_profile();
 [CLink] static extern uint64 bench_steps_native(void* world,float dt,int32 sub,int32 count);
 [CLink] static extern uint64 bench_noop(uint64 x);
 static float Sq(V v)=>v.x*v.x+v.y*v.y+v.z*v.z;
 static bool Fin(float f)=>!f.IsNaN&&!f.IsInfinity;
 static bool Fin(V v)=>Fin(v.x)&&Fin(v.y)&&Fin(v.z);
 public static int Main(String[] args){
  if(args.Count<8){Console.WriteLine("engine scene count threads substeps sleep frames mode(0=simulation,1=queries,2=noop)");return 2;}
  int32 engine=(.)int.Parse(args[0]).GetValueOrDefault(),scene=(.)int.Parse(args[1]).GetValueOrDefault(),n=(.)int.Parse(args[2]).GetValueOrDefault(),threads=(.)int.Parse(args[3]).GetValueOrDefault(),sub=(.)int.Parse(args[4]).GetValueOrDefault(),sleep=(.)int.Parse(args[5]).GetValueOrDefault(),frames=(.)int.Parse(args[6]).GetValueOrDefault(),mode=(.)int.Parse(args[7]).GetValueOrDefault();
  if(mode==2){uint64 sum=1;let t=bench_clock_ns();for(int i=0;i<1000000;i++)sum=bench_noop(sum);double ns=(double)(bench_clock_ns()-t)/1000000;Console.WriteLine(scope $"NOOP,{ns},{sum}");return 0;}
  int[6] sizes=.(sizeof(V),sizeof(Q),sizeof(BodyDesc),sizeof(State),sizeof(Query),sizeof(Hit));for(int32 i=0;i<6;i++){if(sizes[i]!=bench_abi(i)){Console.WriteLine("ABI mismatch");return 5;}}
  Console.Error.WriteLine(scope $"PROFILE,{bench_profile()}");
  int32 ccd=args.Count>8?(.)int.Parse(args[8]).GetValueOrDefault():0;
  let start=bench_clock_ns();let world=bench_create(engine,threads,ccd,scene==4?1:0);defer bench_destroy(world);
  var ids=scope List<int32>();
  BodyDesc d=default;d.q=.(0,0,0,1);d.friction=0.5f;d.density=1000;d.sleep=sleep;d.linearDamping=0;d.angularDamping=0;
  if(mode==4){d.dynamic=1;d.p=.(0,10,0);d.half=.(0.5f,0.5f,0.5f);let id=bench_add(world,&d);int32 errors=0;for(int i=0;i<120;i++)errors|=bench_step(world,1f/60,sub);State s=default;bench_state(world,id,&s);Console.WriteLine(scope $"VALIDATE,{engine},{threads},{sub},{bench_profile()},{s.p.y},{s.v.y},{errors}");return errors==0&&s.p.y> -10.2f&&s.p.y< -9.0f&&Math.Abs(s.v.y+19.62f)<0.1f?0:6;}
  if(scene==4){
   var verts=scope List<V>();var indices=scope List<uint32>();
   for(int z=0;z<=25;z++)for(int x=0;x<=40;x++){float px=(x-20)*5f,pz=(z-12.5f)*5f;verts.Add(.(px,1.5f*Math.Sin(px*0.08f)*Math.Cos(pz*0.08f),pz));}
   for(int z=0;z<25;z++)for(int x=0;x<40;x++){uint32 a=(.)(z*41+x);indices.Add(a);indices.Add(a+41);indices.Add(a+1);indices.Add(a+1);indices.Add(a+41);indices.Add(a+42);}
   bench_mesh(world,verts.Ptr,(.)verts.Count,indices.Ptr,(.)(indices.Count/3));
  }else{d.p=.(0,-0.5f,0);d.half=.(1000,0.5f,1000);bench_add(world,&d);}
  int32 width=scene==3||scene==4?(.)Math.Ceiling(Math.Sqrt((double)n)):(.)Math.Ceiling(Math.Pow((double)n,1.0/3.0));
  for(int32 i=0;i<n;i++){
   int32 x=i%width,z=(i/width)%width,y=i/(width*width);
   float spacing=scene==3?3f:scene==4?4f:scene==1?1.8f:1.02f;
   d.p=.((x-(width-1)*0.5f)*spacing,scene==4?8f:(scene==1?1f:0.55f)+y*(scene==1?1.8f:1.02f),(z-(width-1)*0.5f)*spacing);
   d.q=.(0,0,0,1);if(scene==1){uint32 a=(uint32)i &* 747796405u &+ 2891336453u;float angle=(a&65535)/65535f*6.2831853f;float sn=Math.Sin(angle*0.5f)*0.577350269f;d.q=.(sn,sn,sn,Math.Cos(angle*0.5f));}
   d.half=.(0.5f,0.5f,0.5f);d.shape=scene==2?1:scene==4?i%4:0;
   if(scene==4){if(d.shape==0)d.half=.(0.5f,0.75f,1);if(d.shape==2)d.half=.(0.5f,0.75f,0.5f);}
   d.dynamic=1;ids.Add(bench_add(world,&d));
  }
  bench_ready(world,mode==1?1:0,engine);double setup=(bench_clock_ns()-start)/1000000.0;
  if(mode==1){
   for(int32 kind=0;kind<4;kind++)for(int pass=0;pass<6;pass++){
    int hits=0;double fractions=0,normals=0;int32 count=20000;
    float extent=width*(scene==4?4f:1.02f)*0.6f;
    let t=bench_clock_ns();
    for(int32 i=0;i<count;i++){
     uint32 a=(uint32)i &* 747796405u &+ 2891336453u,b=a &* 277803737u &+ 1013904223u;
     float x=((a&65535)/65535f*2-1)*extent,z=((b&65535)/65535f*2-1)*extent;
     Query q=default;q.origin=.(x,100,z);q.delta=.(0,-200,0);q.radius=0.25f;q.kind=kind==3?1:0;
     if(kind==1){q.origin=.(-extent-2,0.05f+(a&65535)/65535f*(width*1.02f+2),z);q.delta=.(2*extent+4,0,0);}
     if(kind==2)q.delta=.(0,100,0);
     Hit h=default;bench_query(world,&q,&h);hits+=h.hit;if(h.hit!=0){fractions+=h.fraction;normals+=h.normal.x+3*h.normal.y+7*h.normal.z;}
    }
    double ns=(bench_clock_ns()-t)/(double)count;
    if(pass>0)Console.WriteLine(scope $"QUERY,{engine},{scene},{n},{threads},{sub},{kind},{pass},{ns},{hits},{fractions},{normals}");
   }
   return 0;
  }
  if(mode==3){let elapsed=bench_steps_native(world,1f/60,sub,frames);Console.WriteLine(scope $"NATIVE,{engine},{scene},{n},{threads},{sub},{frames},{elapsed/1000000.0/frames}");return 0;}
  var times=scope List<double>();int32 errors=0;double mean=0,early=0,late=0;
  for(int32 f=0;f<frames;f++){let t=bench_clock_ns();errors|=bench_step(world,1f/60,sub);double elapsed=(bench_clock_ns()-t)/1000000.0;times.Add(elapsed);mean+=elapsed;if(f<120)early+=elapsed;if(f>=frames-120)late+=elapsed;}
  double miny=1e30,maxy=-1e30,vel=0,ang=0,checksum=0;int32 invalid=0,escaped=0,active=0;
  for(int32 i=0;i<n;i++){State s=default;bench_state(world,ids[i],&s);if(!Fin(s.p)||!Fin(s.v)||!Fin(s.w)||!Fin(s.q.x)||!Fin(s.q.y)||!Fin(s.q.z)||!Fin(s.q.w))invalid++;if(s.p.y<(scene==4?-5:0)||Math.Abs(s.p.x)>999||Math.Abs(s.p.z)>999){escaped++;Console.Error.WriteLine(scope $"ESCAPED,{i},{scene==4?i%4:0},{s.p.x},{s.p.y},{s.p.z}");}active+=s.active;miny=Math.Min(miny,s.p.y);maxy=Math.Max(maxy,s.p.y);vel+=Sq(s.v);ang+=Sq(s.w);checksum+=(i+1)*(s.p.x+3*s.p.y+7*s.p.z);}
  times.Sort();double p95=times[(frames*95)/100],maximum=times[frames-1];
  Console.WriteLine(scope $"SIM,{engine},{scene},{n},{threads},{sub},{sleep},{frames},{mean/frames},{p95},{maximum},{early/120},{late/120},{setup},{active},{escaped},{invalid},{miny},{maxy},{Math.Sqrt(vel/n)},{Math.Sqrt(ang/n)},{checksum},{errors}");
  return errors!=0||invalid!=0||escaped!=0?4:0;
 }
}
