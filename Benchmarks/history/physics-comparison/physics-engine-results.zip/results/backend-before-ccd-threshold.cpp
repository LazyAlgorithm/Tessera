#include <Jolt/Jolt.h>
#include <Jolt/RegisterTypes.h>
#include <Jolt/Core/Factory.h>
#include <Jolt/Core/TempAllocator.h>
#include <Jolt/Core/JobSystemThreadPool.h>
#include <Jolt/Physics/PhysicsSystem.h>
#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/ConvexHullShape.h>
#include <Jolt/Physics/Collision/Shape/MeshShape.h>
#include <Jolt/Physics/Collision/RayCast.h>
#include <Jolt/Physics/Collision/CastResult.h>
#include <Jolt/Physics/Collision/ShapeCast.h>
#include <Jolt/Physics/Collision/CollisionCollectorImpl.h>
#include <box3d/box3d.h>
#include <btBulletDynamicsCommon.h>
#include <BulletDynamics/Dynamics/btDiscreteDynamicsWorldMt.h>
#include <BulletDynamics/ConstraintSolver/btSequentialImpulseConstraintSolverMt.h>
#include <BulletCollision/CollisionDispatch/btCollisionDispatcherMt.h>
#include <LinearMath/btThreads.h>
#include <rapier.h>
#include <rapier_math.h>
#include <vector>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include "backend.h"
extern "C" void b3SetSIMDWidth(int);
struct Backend {virtual ~Backend(){};virtual int add(const BodyDesc&)=0;virtual void mesh(const V*,int,const uint32_t*,int)=0;virtual void ready()=0;virtual int step(float,int)=0;virtual State state(int)=0;virtual Hit query(const Query&)=0;};
struct BP: JPH::BroadPhaseLayerInterface {JPH::uint GetNumBroadPhaseLayers()const override{return 2;}JPH::BroadPhaseLayer GetBroadPhaseLayer(JPH::ObjectLayer l)const override{return JPH::BroadPhaseLayer(l);} };
struct Pair:JPH::ObjectLayerPairFilter{bool ShouldCollide(JPH::ObjectLayer a,JPH::ObjectLayer b)const override{return a||b;}};
struct OB:JPH::ObjectVsBroadPhaseLayerFilter{bool ShouldCollide(JPH::ObjectLayer a,JPH::BroadPhaseLayer b)const override{return a||b.GetValue();}};
JPH::Vec3 jv(V v){return {v.x,v.y,v.z};} V vv(JPH::Vec3 v){return {v.GetX(),v.GetY(),v.GetZ()};}
struct JoltBackend:Backend {
 bool ccd;BP bp;Pair pair;OB ob;JPH::PhysicsSystem world;JPH::TempAllocatorImpl temp{64*1024*1024};JPH::JobSystemThreadPool jobs;std::vector<JPH::BodyID> ids;JPH::Ref<JPH::Shape> sphere=new JPH::SphereShape(.25f);
 JoltBackend(int t,bool ccd,bool doc):ccd(ccd),jobs(2048,8,t-1){world.Init(16384,0,262144,131072,bp,ob,pair);world.SetGravity({0,-9.81f,0});if(doc){auto p=world.GetPhysicsSettings();p.mNumVelocitySteps=4;p.mNumPositionSteps=1;world.SetPhysicsSettings(p);}}
 int add(const BodyDesc&d)override{
  JPH::Ref<JPH::Shape> sh;
  if(d.shape==1)sh=new JPH::SphereShape(d.half.x);else if(d.shape==2)sh=new JPH::CapsuleShape(d.half.y,d.half.x);else if(d.shape==3){JPH::ConvexHullShapeSettings s({{0,.75f,0},{1,-.25f,0},{-1,-.25f,0},{0,-.25f,1},{0,-.25f,-1}},0);sh=s.Create().Get();}else sh=new JPH::BoxShape(jv(d.half),0);
  static_cast<JPH::ConvexShape*>(sh.GetPtr())->SetDensity(d.density);
  JPH::BodyCreationSettings s(sh,JPH::RVec3(d.p.x,d.p.y,d.p.z),{d.q.x,d.q.y,d.q.z,d.q.w},d.dynamic?JPH::EMotionType::Dynamic:JPH::EMotionType::Static,d.dynamic?1:0);
  s.mFriction=d.friction;s.mRestitution=d.restitution;s.mLinearDamping=d.linearDamping;s.mAngularDamping=d.angularDamping;s.mAllowSleeping=d.sleep;s.mMotionQuality=ccd?JPH::EMotionQuality::LinearCast:JPH::EMotionQuality::Discrete;
  auto id=world.GetBodyInterface().CreateAndAddBody(s,JPH::EActivation::Activate);if(id.IsInvalid())abort();ids.push_back(id);return ids.size()-1;
 }
 void mesh(const V*v,int nv,const uint32_t*i,int nt)override{JPH::VertexList verts;for(int k=0;k<nv;k++)verts.push_back({v[k].x,v[k].y,v[k].z});JPH::IndexedTriangleList tris;for(int k=0;k<nt;k++)tris.push_back({i[3*k],i[3*k+1],i[3*k+2]});JPH::MeshShapeSettings settings(verts,tris);auto sh=settings.Create().Get();JPH::BodyCreationSettings d(sh,JPH::RVec3::sZero(),JPH::Quat::sIdentity(),JPH::EMotionType::Static,0);d.mFriction=.5f;world.GetBodyInterface().CreateAndAddBody(d,JPH::EActivation::DontActivate);}
 void ready()override{world.OptimizeBroadPhase();}
 int step(float dt,int sub)override{return (int)world.Update(dt,sub,&temp,&jobs);}
 State state(int i)override{auto&b=world.GetBodyInterface();auto p=b.GetPosition(ids[i]);auto q=b.GetRotation(ids[i]);return {{(float)p.GetX(),(float)p.GetY(),(float)p.GetZ()},{q.GetX(),q.GetY(),q.GetZ(),q.GetW()},vv(b.GetLinearVelocity(ids[i])),vv(b.GetAngularVelocity(ids[i])),b.IsActive(ids[i])};}
 Hit query(const Query&q)override{Hit h={};h.fraction=1;auto&n=world.GetNarrowPhaseQuery();JPH::RVec3 o(q.origin.x,q.origin.y,q.origin.z);auto d=jv(q.delta);
  if(q.kind==0){JPH::RRayCast ray(o,d);JPH::RayCastResult r;if(n.CastRay(ray,r)){h.hit=1;h.fraction=r.mFraction;auto p=ray.GetPointOnRay(r.mFraction);h.point={(float)p.GetX(),(float)p.GetY(),(float)p.GetZ()};JPH::BodyLockRead lock(world.GetBodyLockInterface(),r.mBodyID);if(lock.Succeeded())h.normal=vv(lock.GetBody().GetWorldSpaceSurfaceNormal(r.mSubShapeID2,p));}}
  else{JPH::RShapeCast cast(sphere,{1,1,1},JPH::RMat44::sTranslation(o),d);JPH::ShapeCastSettings s;s.mReturnDeepestPoint=true;JPH::ClosestHitCollisionCollector<JPH::CastShapeCollector> c;n.CastShape(cast,s,JPH::RVec3::sZero(),c);if(c.HadHit()){h.hit=1;h.fraction=c.mHit.mFraction;h.point=vv(c.mHit.mContactPointOn2);h.normal=vv(-c.mHit.mPenetrationAxis.NormalizedOr(JPH::Vec3::sAxisY()));}}
  return h;}
};
struct BoxBackend:Backend{
 bool ccd;b3WorldId world;std::vector<b3BodyId> ids;std::vector<b3MeshData*> meshes;
 BoxBackend(int t,bool ccd):ccd(ccd){
#ifdef BENCH_DETERMINISTIC
 b3SetSIMDWidth(4);
#endif
 auto d=b3DefaultWorldDef();d.workerCount=t;d.gravity={0,-9.81f,0};d.enableContinuous=ccd;world=b3CreateWorld(&d);}
 ~BoxBackend(){b3DestroyWorld(world);for(auto m:meshes)b3DestroyMesh(m);}
 int add(const BodyDesc&d)override{auto b=b3DefaultBodyDef();b.type=d.dynamic?b3_dynamicBody:b3_staticBody;b.position={d.p.x,d.p.y,d.p.z};b.rotation={d.q.x,d.q.y,d.q.z,d.q.w};b.linearDamping=d.linearDamping;b.angularDamping=d.angularDamping;b.enableSleep=d.sleep;auto id=b3CreateBody(world,&b);auto s=b3DefaultShapeDef();s.baseMaterial.friction=d.friction;s.baseMaterial.restitution=d.restitution;s.density=d.density;
 if(d.shape==1){b3Sphere sh={{0,0,0},d.half.x};b3CreateSphereShape(id,&s,&sh);}else if(d.shape==2){b3Capsule sh={{0,-d.half.y,0},{0,d.half.y,0},d.half.x};b3CreateCapsuleShape(id,&s,&sh);}else if(d.shape==3){b3Vec3 pts[]={{0,.75f,0},{1,-.25f,0},{-1,-.25f,0},{0,-.25f,1},{0,-.25f,-1}};auto hull=b3CreateHull(pts,5,64);b3CreateHullShape(id,&s,hull);b3DestroyHull(hull);}else{auto sh=b3MakeBoxHull(d.half.x,d.half.y,d.half.z);b3CreateHullShape(id,&s,&sh.base);}ids.push_back(id);return ids.size()-1;}
 void mesh(const V*,int,const uint32_t*,int)override;
 void ready()override{}
 int step(float dt,int sub)override{b3World_Step(world,dt,sub);return 0;}
 State state(int i)override{auto p=b3Body_GetPosition(ids[i]);auto q=b3Body_GetRotation(ids[i]);auto v=b3Body_GetLinearVelocity(ids[i]);auto w=b3Body_GetAngularVelocity(ids[i]);return {{p.x,p.y,p.z},{q.v.x,q.v.y,q.v.z,q.s},{v.x,v.y,v.z},{w.x,w.y,w.z},b3Body_IsAwake(ids[i])};}
 Hit query(const Query&q)override{Hit h={};h.fraction=1;if(q.kind==0){auto r=b3World_CastRayClosest(world,{q.origin.x,q.origin.y,q.origin.z},{q.delta.x,q.delta.y,q.delta.z},b3DefaultQueryFilter());if(r.hit)h={{(float)r.point.x,(float)r.point.y,(float)r.point.z},{r.normal.x,r.normal.y,r.normal.z},r.fraction,1};}else{b3Vec3 c={0,0,0};b3ShapeProxy p={&c,1,q.radius};b3World_CastShape(world,{q.origin.x,q.origin.y,q.origin.z},&p,{q.delta.x,q.delta.y,q.delta.z},b3DefaultQueryFilter(),[](b3ShapeId,b3Pos p,b3Vec3 n,float f,uint64_t,int,int,void*ctx){auto&h=*(Hit*)ctx;if(f<h.fraction)h={{(float)p.x,(float)p.y,(float)p.z},{n.x,n.y,n.z},f,1};return h.fraction;},&h);}return h;}
};
struct RapierBackend:Backend{
 bool ccd;R3World*w;std::vector<R3RigidBodyHandle>ids;R3SharedShape*sphere;
 RapierBackend(int t,bool ccd):ccd(ccd){R3ErrorHandler e={[](R3Status s,const char*m,void*){fprintf(stderr,"Rapier error %u: %s\n",s,m);abort();},nullptr};r3SetErrorHandler(e);w=r3NewWorld();r3SetNumThreads(w,t);r3SetGravity(w,{0,-9.81f,0});sphere=r3BallSharedShape(.25f);}
 ~RapierBackend(){r3FreeSharedShape(sphere);r3FreeWorld(w);}
 int add(const BodyDesc&d)override{auto b=d.dynamic?r3DynamicRigidBodyDesc():r3FixedRigidBodyDesc();b.position.translation={d.p.x,d.p.y,d.p.z};b.position.rotation={d.q.x,d.q.y,d.q.z,d.q.w};b.linearDamping=d.linearDamping;b.angularDamping=d.angularDamping;b.canSleep=d.sleep;b.ccdEnabled=ccd;auto id=r3InsertRigidBody(w,&b);auto s=d.shape==1?r3BallColliderDesc(d.half.x):d.shape==2?r3CapsuleYColliderDesc(d.half.y,d.half.x):r3CuboidColliderDesc({d.half.x,d.half.y,d.half.z});R3SharedShape*hull=nullptr;if(d.shape==3){R3Vector pts[]={{0,.75f,0},{1,-.25f,0},{-1,-.25f,0},{0,-.25f,1},{0,-.25f,-1}};hull=r3ConvexHullSharedShape({pts,5});s.shape.kind=R3_SHAPE_DESC_SHARED;s.shape.sharedShape=hull;}s.density=d.density;s.friction=d.friction;s.restitution=d.restitution;r3InsertCollider(id,&s);if(hull)r3FreeSharedShape(hull);ids.push_back(id);return ids.size()-1;}
 void mesh(const V*,int,const uint32_t*,int)override;
 void ready()override{r3DetectCollisions(w,nullptr,nullptr);}
 int step(float dt,int sub)override{auto p=r3IntegrationParameters(w);p.dt=dt;p.numSolverIterations=sub;p.maxCcdSubsteps=ccd?1:0;r3SetIntegrationParameters(w,&p);return r3Step(w,nullptr,nullptr);}
 State state(int i)override{auto p=r3RigidBody_Position(ids[i]);auto v=r3RigidBody_Linvel(ids[i]);auto a=r3RigidBody_Angvel(ids[i]);return {{p.translation.x,p.translation.y,p.translation.z},{p.rotation.x,p.rotation.y,p.rotation.z,p.rotation.w},{v.x,v.y,v.z},{a.x,a.y,a.z},!r3RigidBody_IsSleeping(ids[i])};}
 Hit query(const Query&q)override{Hit h={};h.fraction=1;if(q.kind==0){auto r=r3TryCastRay(w,nullptr,{q.origin.x,q.origin.y,q.origin.z},{q.delta.x,q.delta.y,q.delta.z},1,0);if(r.found){h.hit=1;h.fraction=r.hit.time_of_impact;h.normal={r.hit.normal.x,r.hit.normal.y,r.hit.normal.z};h.point={q.origin.x+q.delta.x*h.fraction,q.origin.y+q.delta.y*h.fraction,q.origin.z+q.delta.z*h.fraction};}}else{auto s=r3DefaultShapeCastOptions();s.max_time_of_impact=1;s.target_distance=0;s.stop_at_penetration=1;s.compute_impact_geometry_on_penetration=1;R3Pose p={{q.origin.x,q.origin.y,q.origin.z},{0,0,0,1}};auto r=r3TryCastShape(w,nullptr,p,{q.delta.x,q.delta.y,q.delta.z},sphere,s);if(r.found){h.hit=1;h.fraction=r.hit.time_of_impact;h.point={r.hit.witness1.x,r.hit.witness1.y,r.hit.witness1.z};h.normal={r.hit.normal1.x,r.hit.normal1.y,r.hit.normal1.z};}}return h;}
};
struct BulletBackend:Backend{
 bool ccd;btDefaultCollisionConfiguration cfg;btDispatcher*dispatcher;btDbvtBroadphase broad;btConstraintSolver*solver;btConstraintSolverPoolMt*pool=nullptr;btDiscreteDynamicsWorld*world;btITaskScheduler*scheduler=nullptr;std::vector<btRigidBody*>ids;std::vector<btCollisionShape*>shapes;std::vector<btTriangleMesh*>meshes;
 BulletBackend(int t,bool ccd,bool doc):ccd(ccd){if(t>1){scheduler=btCreateDefaultTaskScheduler();if(!scheduler){fprintf(stderr,"Bullet MT scheduler missing\n");abort();}scheduler->setNumThreads(t);btSetTaskScheduler(scheduler);dispatcher=new btCollisionDispatcherMt(&cfg);pool=new btConstraintSolverPoolMt(t);solver=new btSequentialImpulseConstraintSolverMt();world=new btDiscreteDynamicsWorldMt(dispatcher,&broad,pool,solver,&cfg);}else{btSetTaskScheduler(btGetSequentialTaskScheduler());dispatcher=new btCollisionDispatcher(&cfg);solver=new btSequentialImpulseConstraintSolver();world=new btDiscreteDynamicsWorld(dispatcher,&broad,solver,&cfg);}world->setGravity({0,-9.81f,0});if(doc)world->getSolverInfo().m_numIterations=5;}
 ~BulletBackend(){for(auto b:ids){world->removeRigidBody(b);delete b;}for(auto s:shapes)delete s;for(auto m:meshes)delete m;delete world;delete solver;delete pool;delete dispatcher;if(scheduler){btSetTaskScheduler(btGetSequentialTaskScheduler());delete scheduler;}}
 int add(const BodyDesc&d)override{btCollisionShape*sh;float volume=8*d.half.x*d.half.y*d.half.z;
 if(d.shape==1){sh=new btSphereShape(d.half.x);volume=4.f/3*3.141592653589793f*d.half.x*d.half.x*d.half.x;}else if(d.shape==2){sh=new btCapsuleShape(d.half.x,2*d.half.y);volume=3.141592653589793f*d.half.x*d.half.x*(2*d.half.y+4.f/3*d.half.x);}else if(d.shape==3){auto h=new btConvexHullShape();for(auto p:std::vector<btVector3>{{0,.75f,0},{1,-.25f,0},{-1,-.25f,0},{0,-.25f,1},{0,-.25f,-1}})h->addPoint(p);h->setMargin(0);sh=h;volume=2.f/3;}else{sh=new btBoxShape({d.half.x,d.half.y,d.half.z});sh->setMargin(0);}shapes.push_back(sh);float mass=d.dynamic?d.density*volume:0;btVector3 inertia(0,0,0);if(mass){sh->calculateLocalInertia(mass,inertia);if(d.shape==3)inertia={mass*.1375f,mass*.2f,mass*.1375f};if(d.shape==2){float r=d.half.x,h=d.half.y,mc=d.density*3.141592653589793f*r*r*2*h,ms=d.density*4.f/3*3.141592653589793f*r*r*r;float ix=mc*(r*r/4+h*h/3)+ms*(.4f*r*r+h*h+.75f*h*r);inertia={ix,.5f*mc*r*r+.4f*ms*r*r,ix};}}btRigidBody::btRigidBodyConstructionInfo ci(mass,nullptr,sh,inertia);ci.m_startWorldTransform=btTransform({d.q.x,d.q.y,d.q.z,d.q.w},{d.p.x,d.p.y,d.p.z});ci.m_friction=std::sqrt(d.friction);ci.m_restitution=d.restitution;ci.m_linearDamping=d.linearDamping;ci.m_angularDamping=d.angularDamping;auto b=new btRigidBody(ci);if(ccd&&d.dynamic){b->setCcdMotionThreshold(.25f);b->setCcdSweptSphereRadius(std::min({d.half.x,d.half.y,d.half.z})*.5f);}if(!d.sleep&&d.dynamic)b->setActivationState(DISABLE_DEACTIVATION);world->addRigidBody(b);ids.push_back(b);return ids.size()-1;}
 void mesh(const V*v,int nv,const uint32_t*i,int nt)override{auto m=new btTriangleMesh();for(int k=0;k<nt;k++)m->addTriangle({v[i[3*k]].x,v[i[3*k]].y,v[i[3*k]].z},{v[i[3*k+1]].x,v[i[3*k+1]].y,v[i[3*k+1]].z},{v[i[3*k+2]].x,v[i[3*k+2]].y,v[i[3*k+2]].z});meshes.push_back(m);auto s=new btBvhTriangleMeshShape(m,true);s->setMargin(0);shapes.push_back(s);btRigidBody::btRigidBodyConstructionInfo ci(0,nullptr,s);ci.m_friction=std::sqrt(.5f);auto b=new btRigidBody(ci);world->addRigidBody(b);ids.push_back(b);}
 void ready()override{world->updateAabbs();world->computeOverlappingPairs();}
 int step(float dt,int sub)override{world->stepSimulation(dt,sub,dt/sub);return 0;}
 State state(int i)override{auto b=ids[i];auto p=b->getWorldTransform().getOrigin();auto q=b->getWorldTransform().getRotation();auto v=b->getLinearVelocity();auto a=b->getAngularVelocity();return {{p.x(),p.y(),p.z()},{q.x(),q.y(),q.z(),q.w()},{v.x(),v.y(),v.z()},{a.x(),a.y(),a.z()},b->isActive()};}
 Hit query(const Query&q)override{Hit h={};h.fraction=1;btVector3 o(q.origin.x,q.origin.y,q.origin.z),to=o+btVector3(q.delta.x,q.delta.y,q.delta.z);if(q.kind==0){btCollisionWorld::ClosestRayResultCallback r(o,to);world->rayTest(o,to,r);if(r.hasHit())h={{r.m_hitPointWorld.x(),r.m_hitPointWorld.y(),r.m_hitPointWorld.z()},{r.m_hitNormalWorld.x(),r.m_hitNormalWorld.y(),r.m_hitNormalWorld.z()},r.m_closestHitFraction,1};}else{btSphereShape shape(q.radius);btCollisionWorld::ClosestConvexResultCallback r(o,to);world->convexSweepTest(&shape,btTransform(btQuaternion::getIdentity(),o),btTransform(btQuaternion::getIdentity(),to),r);if(r.hasHit())h={{r.m_hitPointWorld.x(),r.m_hitPointWorld.y(),r.m_hitPointWorld.z()},{r.m_hitNormalWorld.x(),r.m_hitNormalWorld.y(),r.m_hitNormalWorld.z()},r.m_closestHitFraction,1};}return h;}
};
extern "C"{
void* bench_create(int engine,int threads,int ccd,int doc){if(engine==0){JPH::RegisterDefaultAllocator();JPH::Factory::sInstance=new JPH::Factory();JPH::RegisterTypes();return new JoltBackend(threads,ccd,doc);}if(engine==1)return new BoxBackend(threads,ccd);if(engine==2)return new RapierBackend(threads,ccd);return new BulletBackend(threads,ccd,doc);}
void bench_destroy(void*p){delete (Backend*)p;}
int bench_add(void*p,const BodyDesc*d){return ((Backend*)p)->add(*d);}
void bench_mesh(void*p,const V*v,int nv,const uint32_t*i,int nt){((Backend*)p)->mesh(v,nv,i,nt);}
void bench_ready(void*p,int queryOnly,int engine){if(engine!=2||queryOnly)((Backend*)p)->ready();}
int bench_step(void*p,float dt,int sub){return ((Backend*)p)->step(dt,sub);}
void bench_state(void*p,int i,State*s){*s=((Backend*)p)->state(i);}
void bench_query(void*p,const Query*q,Hit*h){*h=((Backend*)p)->query(*q);}
int bench_profile(){
#ifdef BENCH_DETERMINISTIC
return 1;
#else
return 0;
#endif
}
int bench_abi(int i){int sizes[]={sizeof(V),sizeof(Q),sizeof(BodyDesc),sizeof(State),sizeof(Query),sizeof(Hit)};return sizes[i];}
uint64_t bench_steps_native(void*p,float dt,int sub,int count){auto start=std::chrono::steady_clock::now();int errors=0;for(int k=0;k<count;k++)errors|=((Backend*)p)->step(dt,sub);if(errors)abort();return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count();}
uint64_t bench_clock_ns(){return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
uint64_t bench_noop(uint64_t x){return x*6364136223846793005ull+1442695040888963407ull;}
}
void BoxBackend::mesh(const V*v,int nv,const uint32_t*i,int nt){b3MeshDef md={};md.identifyEdges=true;md.vertices=(b3Vec3*)v;md.vertexCount=nv;md.indices=(int32_t*)i;md.triangleCount=nt;auto data=b3CreateMesh(&md,nullptr,0);auto bd=b3DefaultBodyDef();auto id=b3CreateBody(world,&bd);auto sd=b3DefaultShapeDef();sd.baseMaterial.friction=.5f;b3CreateMeshShape(id,&sd,data,{1,1,1});meshes.push_back(data);}
void RapierBackend::mesh(const V*v,int nv,const uint32_t*i,int nt){auto d=r3DefaultColliderDesc();r3ShapeDesc_SetTrimesh(&d.shape,{(R3Vector*)v,(size_t)nv},{(R3Triangle*)i,(size_t)nt},0);d.friction=.5f;r3InsertColliderWithoutParent(w,&d);}
