import subprocess,os,itertools,pathlib,csv,random,time,json,datetime
root=pathlib.Path(__file__).resolve().parent;exe=root/'driver/build/Release_Linux64/PhysicsBench/PhysicsBench';os.chdir(root)
DEFAULT={0:1,1:4,2:4,3:1}
HEADER='kind,engine,scene,bodies,threads,substeps,sleep,frames,mean_ms,p95_ms,max_ms,first120_ms,last120_ms,setup_ms,active,escaped,nonfinite,min_y,max_y,rms_v,rms_w,checksum,errors'.split(',')
QHEADER='kind,engine,scene,bodies,threads,substeps,query,pass,ns,hits,fraction_sum,normal_sum'.split(',')
def call(profile,e,scene,n,t,sub,sleep=0,frames=600,mode=0,ccd=0):
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/'build'/profile))
 args=['taskset','-c','0' if t==1 else '0-3',str(exe),str(e),str(scene),str(n),str(t),str(sub),str(sleep),str(frames),str(mode),str(ccd)]
 began=time.monotonic();p=subprocess.run(args,env=env,capture_output=True,text=True,timeout=180)
 if mode!=2 and f'PROFILE,{int(profile=="deterministic")}' not in p.stderr:raise RuntimeError(('wrong loaded library',args,p.stderr))
 return p,time.monotonic()-began,args

def main():
 cases=[]
 for rep,e,t,scene in itertools.product(range(3),range(4),[1,4],range(5)):
  for n in ([484] if scene==4 else [1000,4000]):cases.append(('fast','main',rep,e,scene,n,t,DEFAULT[e],0,0))
 for rep,e,t,scene in itertools.product(range(3),range(4),[1,4],range(5)):
  cases.append(('deterministic','main',rep,e,scene,484 if scene==4 else 4000,t,DEFAULT[e],0,0))
 # Both low-substep and four-substep controls on the dense 4,000-box stack.
 for rep,e,t in itertools.product(range(3),range(4),[1,4]):
  cases.append(('fast','substep_control',rep,e,0,4000,t,4 if e in [0,3] else 1,0,0))
 for rep,e in itertools.product(range(3),range(4)):
  cases.append(('fast','sleep',rep,e,0,4000,4,DEFAULT[e],1,0))
  cases.append(('fast','mesh_ccd',rep,e,4,484,4,DEFAULT[e],0,1))
  cases.append(('fast','mesh_four_steps',rep,e,4,484,4,4,0,1))
 random.Random(20261028).shuffle(cases)
 with open('results/simulations.csv','w') as out,open('results/run-log.jsonl','w') as log:
  w=csv.writer(out);w.writerow(['profile','suite','repeat','ccd','valid']+HEADER)
  for k,(profile,suite,rep,e,scene,n,t,sub,sleep,ccd) in enumerate(cases):
   p,elapsed,args=call(profile,e,scene,n,t,sub,sleep,ccd=ccd)
   lines=[x for x in p.stdout.splitlines() if x.startswith('SIM,')]
   if p.returncode not in [0,4] or len(lines)!=1:raise RuntimeError((args,p.returncode,p.stdout,p.stderr))
   row=next(csv.reader(lines));valid=p.returncode==0
   w.writerow([profile,suite,rep,ccd,int(valid)]+row);out.flush()
   log.write(json.dumps({'profile':profile,'suite':suite,'repeat':rep,'args':args,'returncode':p.returncode,'seconds':elapsed,'stderr':p.stderr})+'\n');log.flush()
   print(f'{k+1}/{len(cases)} {profile} e={e} scene={scene} n={n} t={t} sub={sub} valid={valid}',flush=True)
 with open('results/queries.csv','w') as out:
  w=csv.writer(out);w.writerow(['profile']+QHEADER)
  for profile,e,scene in itertools.product(['fast','deterministic'],range(4),[0,2,4]):
   for n in ([484] if scene==4 else [1000,4000]):
    p,_,args=call(profile,e,scene,n,1,DEFAULT[e],mode=1)
    if p.returncode:raise RuntimeError((args,p.stdout,p.stderr))
    lines=[x for x in p.stdout.splitlines() if x.startswith('QUERY,')];assert len(lines)==20
    w.writerows([[profile]+next(csv.reader([line])) for line in lines]);out.flush()
 print('queries done',flush=True)
 with open('results/native-controls.csv','w') as out:
  w=csv.writer(out);w.writerow(['repeat','engine','threads','beef_ms','native_ms','beef_over_native'])
  for rep,e,t in itertools.product(range(3),range(4),[1,4]):
   pair={}
   for mode in ([0,3] if rep%2 else [3,0]):
    p,_,args=call('fast',e,0,1000,t,DEFAULT[e],mode=mode)
    if p.returncode:raise RuntimeError((args,p.stdout,p.stderr))
    row=next(csv.reader([next(x for x in p.stdout.splitlines() if x.startswith('SIM,' if mode==0 else 'NATIVE,'))]));pair[mode]=float(row[8] if mode==0 else row[7])
   w.writerow([rep,e,t,pair[0],pair[3],pair[0]/pair[3]]);out.flush()
 with open('results/noop.csv','w') as out:
  out.write('repeat,ns_per_call,checksum\n')
  for rep in range(5):
   p,_,_=call('fast',0,0,1,1,1,mode=2);out.write(str(rep)+','+p.stdout.strip().split(',',1)[1]+'\n')
 print('ALL DONE',flush=True)
if __name__=='__main__':main()
