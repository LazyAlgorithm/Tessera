import subprocess,os,itertools,pathlib,json
root=pathlib.Path.cwd();exe=root/'driver/build/Release_Linux64/PhysicsBench/PhysicsBench'
def run(profile,e,scene,n,t,sub,frames,mode,ccd=0):
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/'build'/profile));p=subprocess.run(['taskset','-c','0' if t==1 else '0-3',str(exe),str(e),str(scene),str(n),str(t),str(sub),'0',str(frames),str(mode),str(ccd)],env=env,capture_output=True,text=True,timeout=120)
 if mode!=2:assert f'PROFILE,{int(profile=="deterministic")}' in p.stderr,(profile,p.stderr)
 return p
with open('results/smoke.log','w') as out:
 for profile,e,t in itertools.product(['fast','deterministic'],range(4),[1,4]):
  p=run(profile,e,0,1,t,1 if e in [0,3] else 4,120,4);out.write(p.stdout+p.stderr);out.flush();assert p.returncode==0,(profile,e,t,p.stdout,p.stderr)
 for e,scene in itertools.product(range(4),range(5)):
  p=run('fast',e,scene,1000 if scene!=4 else 484,4,1 if e in [0,3] else 4,120,0);out.write(p.stdout+p.stderr);out.flush();assert p.returncode in [0,4],(e,scene,p.stdout,p.stderr)
print('smoke completed')
