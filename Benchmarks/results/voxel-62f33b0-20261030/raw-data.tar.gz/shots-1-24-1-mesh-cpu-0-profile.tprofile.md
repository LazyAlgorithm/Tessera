# Tessera Profiler report

Frames 0 to 0 (40 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 2.164 ms | 2.164 ms | 2.182 ms | 2.206 ms | 2.206 ms | 2.147 ms |
| CPU main thread | 2.162 ms | 2.161 ms | 2.180 ms | 2.204 ms | 2.204 ms | 2.145 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Other: 2.158 ms
- Physics: 0.001 ms
- Scripts: 0.001 ms
- Rendering: 0.000 ms
- Audio: 0.000 ms
- Animation: 0.000 ms
- AI: 0.000 ms
- Networking: 0.000 ms

## Thread 'Voxel Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Frame | Other | 2.158 ms | 2.162 ms | 1 | 2.204 ms | 40/40 |
| Physics.Step | Physics | 0.001 ms | 0.001 ms | 1 | 0.001 ms | 40/40 |
| OnFrame (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.008 ms | 40/40 |
| Update (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.001 ms | 40/40 |
| LateUpdate (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.001 ms | 40/40 |
| FixedUpdate (every component) | Scripts | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Start | Scripts | 0.000 ms | 0.000 ms | 3 | 0.000 ms | 40/40 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| IK | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.OnFrame() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshRenderer.LateUpdate() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshRenderer.Update() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.LateUpdate() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshRenderer.OnFrame() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.Update() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Destroy | Scripts | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| MeshCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| VoxelObject.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| MeshRenderer.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 0: interval 2.206 ms, CPU 2.163 ms, GPU -

```
Frame  total 2.163 ms, self 2.159 ms
```

### Frame 0: interval 2.166 ms, CPU 2.204 ms, GPU -

```
Frame  total 2.204 ms, self 2.200 ms
```

### Frame 0: interval 2.184 ms, CPU 2.157 ms, GPU -

```
Frame  total 2.156 ms, self 2.153 ms
```

### Frame 0: interval 2.166 ms, CPU 2.182 ms, GPU -

```
Frame  total 2.182 ms, self 2.179 ms
```

### Frame 0: interval 2.182 ms, CPU 2.160 ms, GPU -

```
Frame  total 2.160 ms, self 2.156 ms
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
