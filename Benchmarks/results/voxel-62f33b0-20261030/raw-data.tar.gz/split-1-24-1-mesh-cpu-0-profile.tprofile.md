# Tessera Profiler report

Frames 0 to 0 (40 recorded). Times are on the recording machine; GPU times lag the CPU by a frame or two.
Self time = time in a marker less the markers inside it. 'Present (waiting for the GPU)' and 'Sleep' are idle waits, not work.

## Frame times

| | average | median | 95% | 99% | worst | best |
|---|---|---|---|---|---|---|
| Frame interval (what players see) | 1.623 ms | 1.612 ms | 1.639 ms | 1.826 ms | 1.826 ms | 1.592 ms |
| CPU main thread | 1.620 ms | 1.610 ms | 1.636 ms | 1.823 ms | 1.823 ms | 1.590 ms |
| GPU | not recorded | | | | | |

Spikes (frames taking over twice the median interval): 0.

## Main thread by category (average self time per frame)

- Other: 1.449 ms
- Scripts: 0.157 ms
- Physics: 0.013 ms
- Rendering: 0.001 ms
- Animation: 0.000 ms
- Audio: 0.000 ms
- AI: 0.000 ms
- Networking: 0.000 ms

## Thread 'Voxel Benchmark': markers by average self time per frame

| marker | category | self/frame | total/frame | calls/frame | worst frame total | in frames |
|---|---|---|---|---|---|---|
| Frame | Other | 1.449 ms | 1.620 ms | 1 | 1.823 ms | 40/40 |
| Start | Scripts | 0.117 ms | 0.117 ms | 3 | 0.126 ms | 40/40 |
| Destroy | Scripts | 0.037 ms | 0.037 ms | 2 | 0.072 ms | 40/40 |
| Physics.Step | Physics | 0.012 ms | 0.012 ms | 1 | 0.026 ms | 40/40 |
| OnFrame (every component) | Scripts | 0.001 ms | 0.001 ms | 2 | 0.010 ms | 40/40 |
| LateUpdate (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.001 ms | 40/40 |
| Update (every component) | Scripts | 0.000 ms | 0.001 ms | 2 | 0.001 ms | 40/40 |
| FixedUpdate (every component) | Scripts | 0.000 ms | 0.001 ms | 1 | 0.001 ms | 40/40 |
| IK | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.OnFrame() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| Skinning | Animation | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.LateUpdate() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| VoxelObject.Update() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| MeshRenderer.LateUpdate() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| MeshRenderer.OnFrame() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| MeshRenderer.Update() | Rendering | 0.000 ms | 0.000 ms | 4 | 0.000 ms | 40/40 |
| Audio.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoiceChat.Update | Audio | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Navigation Paths | AI | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Rigidbody.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| ConvexCollider.OnFrame() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Rigidbody.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| BoxCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Rigidbody.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| ConvexCollider.LateUpdate() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| ConvexCollider.Update() | Physics | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| MeshRenderer.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| VoxelObject.FixedUpdate() | Rendering | 0.000 ms | 0.000 ms | 2 | 0.000 ms | 40/40 |
| Network Post-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Network Pre-Tick | Networking | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| BoxCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| Rigidbody.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| MeshCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |
| ConvexCollider.FixedUpdate() | Physics | 0.000 ms | 0.000 ms | 1 | 0.000 ms | 40/40 |

## The 5 slowest frames (main thread call tree, rows over 0.05 ms)

### Frame 0: interval 1.826 ms, CPU 1.636 ms, GPU -

```
Frame  total 1.636 ms, self 1.456 ms
  Start  total 0.123 ms, self 0.123 ms, 3 calls
```

### Frame 0: interval 1.620 ms, CPU 1.823 ms, GPU -

```
Frame  total 1.823 ms, self 1.620 ms
  Start  total 0.126 ms, self 0.126 ms, 3 calls
  Destroy  total 0.058 ms, self 0.058 ms, 2 calls
```

### Frame 0: interval 1.819 ms, CPU 1.626 ms, GPU -

```
Frame  total 1.625 ms, self 1.451 ms
  Start  total 0.122 ms, self 0.122 ms, 3 calls
```

### Frame 0: interval 1.626 ms, CPU 1.816 ms, GPU -

```
Frame  total 1.816 ms, self 1.599 ms
  Start  total 0.126 ms, self 0.126 ms, 3 calls
  Destroy  total 0.072 ms, self 0.072 ms, 2 calls
```

### Frame 0: interval 1.639 ms, CPU 1.622 ms, GPU -

```
Frame  total 1.622 ms, self 1.452 ms
  Start  total 0.120 ms, self 0.120 ms, 3 calls
```

## Counters (first, lowest, average, highest, last)


Counters in bytes are plain byte counts. Memory that grows from first to last without coming down can be a leak.
